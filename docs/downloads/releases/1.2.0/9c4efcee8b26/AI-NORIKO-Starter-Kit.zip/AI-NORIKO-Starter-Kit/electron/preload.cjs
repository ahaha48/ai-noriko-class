const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("hayato", {
  getStarterProfile: () => ipcRenderer.invoke("starter:profile"),
  initializeStarter: () => ipcRenderer.invoke("starter:initialize"),
  getState: () => ipcRenderer.invoke("state:get"),
  saveState: (state) => ipcRenderer.invoke("state:save", state),
  getConfigStatus: () => ipcRenderer.invoke("config:status"),
  getLocalStatus: () => ipcRenderer.invoke("local:status"),
  getKnowledgeStatus: () => ipcRenderer.invoke("knowledge:status"),
  selectKnowledgeFolder: () => ipcRenderer.invoke("knowledge:selectFolder"),
  searchKnowledge: (query) => ipcRenderer.invoke("knowledge:search", query),
  saveKnowledge: (request) => ipcRenderer.invoke("knowledge:save", request),
  getAgentStatus: () => ipcRenderer.invoke("agent:status"),
  listAgentJobs: () => ipcRenderer.invoke("agent:list"),
  startAgentJob: (request) => ipcRenderer.invoke("agent:start", request),
  cancelAgentJob: (jobId) => ipcRenderer.invoke("agent:cancel", jobId),
  selectAgentProject: () => ipcRenderer.invoke("agent:selectProject"),
  openAgentResult: (filePath) => ipcRenderer.invoke("agent:openResult", filePath),
  openAgentTerminal: (request) => ipcRenderer.invoke("agent:openTerminal", request),
  onAgentJobUpdated: (callback) => {
    const listener = (_event, job) => callback(job);
    ipcRenderer.on("agent:jobUpdated", listener);
    return () => ipcRenderer.removeListener("agent:jobUpdated", listener);
  },
  saveSecrets: (patch) => ipcRenderer.invoke("config:save", patch),
  listFishVoices: (apiKey) => ipcRenderer.invoke("fish:listVoices", apiKey),
  makeFishVoicePrivate: () => ipcRenderer.invoke("fish:makeVoicePrivate"),
  importGoogleCredentials: () => ipcRenderer.invoke("google:credentials:import"),
  importLatestGoogleCredentials: () => ipcRenderer.invoke("google:credentials:importLatestDownload"),
  getGoogleStatus: () => ipcRenderer.invoke("google:status"),
  connectGoogle: () => ipcRenderer.invoke("google:connect"),
  beginGoogleConnect: () => ipcRenderer.invoke("google:connect:begin"),
  completeGoogleConnect: () => ipcRenderer.invoke("google:connect:complete"),
  syncGoogleToday: (date) => ipcRenderer.invoke("google:syncToday", date),
  syncGoogleWeek: (date) => ipcRenderer.invoke("google:syncWeek", date),
  listGoogleTasks: () => ipcRenderer.invoke("google:tasks:list"),
  createGoogleTask: (request) => ipcRenderer.invoke("google:tasks:create", request),
  completeGoogleTask: (request) => ipcRenderer.invoke("google:tasks:complete", request),
  searchGoogleCalendar: (request) => ipcRenderer.invoke("google:searchCalendar", request),
  disconnectGoogle: () => ipcRenderer.invoke("google:disconnect"),
  selectProject: () => ipcRenderer.invoke("dialog:selectProject"),
  scanProject: (projectPath) => ipcRenderer.invoke("project:scan", projectPath),
  importRevenueCsv: () => ipcRenderer.invoke("revenue:import"),
  searchYouTubeLive: (query) => ipcRenderer.invoke("youtube:searchLive", query),
  researchWeb: (query) => ipcRenderer.invoke("web:research", query),
  getLatestNews: (topic) => ipcRenderer.invoke("news:latest", topic),
  getWeather: (location) => ipcRenderer.invoke("weather:get", location),
  askAI: (request) => ipcRenderer.invoke("openai:respond", request),
  transcribeAudio: (request) => ipcRenderer.invoke("openai:transcribe", request),
  speak: (text) => ipcRenderer.invoke("fish:speak", text),
  showNotification: (request) => ipcRenderer.invoke("notification:show", request),
  openExternal: (url) => ipcRenderer.invoke("shell:openExternal", url),
  openInChrome: (url) => ipcRenderer.invoke("shell:openChrome", url),
  onAssistantFocus: (callback) => {
    const listener = () => callback();
    ipcRenderer.on("assistant:focus", listener);
    return () => ipcRenderer.removeListener("assistant:focus", listener);
  },
});
