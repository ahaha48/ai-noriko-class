const path = require("node:path");
const { createHash } = require("node:crypto");

// Pure calculation: callers resolve symlinks before supplying the kit root.
// No legacy profile is inspected or migrated, even if one already exists.
function createInstanceProfile({ kitRoot, appDataPath, documentsPath, platform = process.platform, pathApi = path }) {
  for (const [name, value] of Object.entries({ kitRoot, appDataPath, documentsPath })) {
    if (typeof value !== "string" || !pathApi.isAbsolute(value)) {
      throw new TypeError(`${name} must be an absolute path`);
    }
  }
  const normalized = pathApi.normalize(kitRoot);
  const normalizedRoot = normalized === pathApi.parse(normalized).root
    ? normalized : normalized.replace(/[\\/]+$/, "");
  const identity = platform === "win32" ? normalizedRoot.toLowerCase() : normalizedRoot;
  const instanceId = createHash("sha256").update(identity, "utf8").digest("hex").slice(0, 20);
  const userDataPath = pathApi.join(appDataPath, "AI NORIKO Starter", "instances", instanceId);
  const documentsRoot = pathApi.join(documentsPath, "AI-NORIKO-Instances", instanceId);
  return Object.freeze({
    instanceId,
    kitRoot: normalizedRoot,
    userDataPath,
    sessionDataPath: pathApi.join(userDataPath, "session"),
    knowledgePath: pathApi.join(documentsRoot, "Knowledge"),
    agentWorkspacePath: pathApi.join(documentsRoot, "Workspaces"),
  });
}

module.exports = { createInstanceProfile };
