# AI NORIKO 共通スターターキット

講座改訂：2026年9月19日／本体v1.2.0。共通導入の後、個人のAI秘書または会社のAI相談役へ発展させるための教材付きElectronアプリです。

## 最初の一歩

[START_HERE.md](START_HERE.md)を読み、[Codexへの依頼文](CODEX_SETUP_PROMPT.md)を送ってください。Mac・Windows用起動ファイルを同梱。個々のOS・PC・外部サービスの動作は各受講者の環境で確認します。

Node.js 24 LTSを推奨します（24.14.0で検証、最低22.12.0以上）。資料専用のLearning-Guideではなく、package.jsonのある本体フォルダで実行します。

最新版の未使用ZIPを別フォルダへ展開すると、設定・標準ナレッジ・作業先も別環境になります。同じ本体フォルダの再起動では保存を維持します。本体フォルダの後からの移動・名前変更、旧v1.1からの更新は [別環境の導入ガイド](docs/MULTIPLE_INSTALLS.md) を確認してください。旧データの自動移行・削除はしません。

```text
npm install
npm run setup
npm run start
```

確認：npm run doctor、npm run check、npm run build、npm run smoke

## 機能の区分

- 基本：名前設定、手動タスク、音量・ミュート、登録済み公開ライブなど
- 準備後：ローカルAI相談、Obsidian参照・記録、Google予定・Tasks、Fish Audio、Codex／Claude Code連携
- 設定で任意追加：売上管理（初期非表示）
- 追加開発：複数AIプロジェクトの統合監視、社員ログイン・閲覧権限・承認依頼など

[実装状況](docs/FEATURE_CATALOG.md)を確認してください。教材のプロンプトは実装済み機能の証明ではありません。

## 教材

- [共通導入ガイド](docs/COURSE_GUIDE.md)
- [個人向け](docs/PERSONAL_PLAYBOOK.md)／[企業向け](docs/TEAM_PLAYBOOK.md)
- [プロンプト集](docs/PROMPTS.md)／[カスタマイズ](docs/CUSTOMIZATION.md)
- [サービス化・収益試算](docs/SERVICE_DESIGN.md)
- [Mac](docs/MAC_SETUP.md)／[Windows](docs/WINDOWS_SETUP.md)／[困ったとき](docs/TROUBLESHOOTING.md)
- [講師用進行資料](docs/INSTRUCTOR_GUIDE.md)／[記入テンプレート](templates/README.md)
- [NORIKOナレッジの導入](docs/NORIKO_KNOWLEDGE_SETUP.md)／P21：主催者から受け取る別配布の思考パックを、安全に追加・確認・解除する手順
- [複数の環境・保存先・移動と更新](docs/MULTIPLE_INSTALLS.md)

自分のナレッジと、講師の思考パックは別物です。現思考パックは本人確認用の先行版で、利用人数・再配布・商用利用等は主催者の案内を確認します。本体に講師の私的ノートや音声を同梱しません。

## 情報と費用

教材には架空のサンプルだけを使います。本人のナレッジやキーを配布ZIPへ追加しないでください。認証は利用者本人が設定し、OSの暗号化保存を使います。暗号化方式を確認できない端末では機密キーを保存せず、講師が確認します。

ローカル会話でも、明示的なCodex／Claude Codeへの作業依頼は関連資料をそのサービスへ渡す場合があります。Fish Audioの読み上げ本文も外部へ送られます。機密相談では外部連携・音声を止め、承認済みの経路だけを使います。

Codex等の契約・利用枠、Fish Audio API、通信・端末・運用費は講座代と別です。「すべて無料」「無制限」「社長と同じ判断」を保証しません。

## 会社での利用

現状は1人用のローカルアプリです。社員へ展開する前に、別保管庫、認証、閲覧権限、ログと保存期間、根拠表示、社長確認への引き継ぎを設計・実装・検証します。フォルダを分けるだけでは権限制御になりません。

ソースはsrc/、electron/。教材データはcourse/、説明はdocs/。設定・認証等はOSのappData内 `AI NORIKO Starter/instances/<環境ID>`、標準のナレッジと作業先はDocuments内 `AI-NORIKO-Instances/<環境ID>/Knowledge` と `Workspaces` です。本人データをソースへ混ぜません。

顧客へは設定済みのフォルダではなく最新版の未使用ZIPを渡し、本人のアカウント・キーで接続します。同じGoogleやObsidianを指定すれば外部データの共有は残ります。別フォルダ化は顧客間のOSアクセス制御ではありません。
