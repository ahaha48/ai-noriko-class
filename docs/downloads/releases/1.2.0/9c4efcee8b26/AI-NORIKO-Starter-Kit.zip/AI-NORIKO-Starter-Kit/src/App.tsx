import {
  FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  buildBriefing,
  dailyRevenue,
  extractYouTubeId,
  formatCurrency,
  formatShortDate,
  japanToday,
  monthlyRevenue,
  parseRevenueCsv,
  uid,
} from "./lib";
import { directAgentRequest, isDiscussionRequest, isKnowledgeRecordRequest } from "./command-intent";
import type {
  AgentAvailability,
  AgentJob,
  AgentJobMode,
  AgentProvider,
  AgentStartRequest,
  AppState,
  AssistantMode,
  CameraItem,
  ChatEntry,
  FishVoiceModel,
  GoogleAccountStatus,
  GoogleCalendarEvent,
  GoogleCalendarSearchResult,
  GoogleTaskCollection,
  GoogleTaskCreateRequest,
  GoogleTaskItem,
  GoogleTodaySchedule,
  GoogleWeekSchedule,
  LocalSystemStatus,
  ObsidianKnowledgeStatus,
  Priority,
  ResearchResult,
  RevenueEntry,
  SecretStatus,
  TaskItem,
  ViewName,
  WeatherResult,
  YouTubeLiveResult,
} from "./types";

const coreNavItems: { id: ViewName; label: string; icon: string }[] = [
  { id: "dashboard", label: "司令室", icon: "⌁" },
  { id: "schedule", label: "予定", icon: "▦" },
  { id: "week", label: "今週", icon: "▤" },
  { id: "tasks", label: "タスク", icon: "✓" },
  { id: "cameras", label: "ライブ", icon: "◉" },
  { id: "agents", label: "AI作業", icon: "◆" },
  { id: "settings", label: "設定", icon: "⚙" },
];

function navigationItems(revenueEnabled: boolean) {
  if (!revenueEnabled) return coreNavItems;
  const cameraIndex = coreNavItems.findIndex((item) => item.id === "cameras");
  return [
    ...coreNavItems.slice(0, cameraIndex),
    { id: "revenue" as ViewName, label: "売上", icon: "¥" },
    ...coreNavItems.slice(cameraIndex),
  ];
}

const cameraRegions = [
  { key: "福岡", search: "福岡 天神", aliases: ["福岡", "天神", "博多"] },
  { key: "東京", search: "東京", aliases: ["東京", "渋谷", "新宿", "東京ドーム"] },
  { key: "大阪", search: "大阪 道頓堀", aliases: ["大阪", "道頓堀", "梅田"] },
] as const;

function cameraRegionFromPrompt(prompt: string) {
  return cameraRegions.find((region) => region.aliases.some((alias) => prompt.includes(alias)));
}

function cameraForRegion(cameras: CameraItem[], region: (typeof cameraRegions)[number]) {
  return cameras.find((camera) => region.aliases.some((alias) => `${camera.name}${camera.location}`.includes(alias)));
}

function weatherBriefing(weather: WeatherResult, tomorrow: boolean) {
  const round = (value?: number) => value == null ? "不明" : String(Math.round(value));
  if (tomorrow) {
    const forecast = weather.daily[1] || weather.daily[0];
    return `明日の${weather.location}は${forecast.condition}の予報です。最高気温は${round(forecast.high)}度、最低気温は${round(forecast.low)}度、降水確率は${round(forecast.precipitationProbability)}パーセントです。`;
  }
  const today = weather.daily[0];
  return `${weather.location}の現在の天気は${weather.current.condition}、気温は${round(weather.current.temperature)}度です。今日の最高気温は${round(today?.high)}度、最低気温は${round(today?.low)}度、降水確率は${round(today?.precipitationProbability)}パーセントです。`;
}

const emptyStatus: SecretStatus = {
  openai: false,
  fish: false,
  fishVoice: false,
  youtube: false,
  googleClient: false,
};

const emptyGoogleStatus: GoogleAccountStatus = {
  configured: false,
  connected: false,
  tasksWritable: false,
};

const emptyLocalStatus: LocalSystemStatus = {
  ollama: false,
  model: false,
  whisper: false,
  modelName: "qwen3.5:9b",
};

const emptyKnowledgeStatus: ObsidianKnowledgeStatus = {
  configured: false,
  available: false,
  path: "",
  noteCount: 0,
  checkedAt: "",
};

const emptyAgentAvailability: AgentAvailability = {
  codex: { installed: false, loggedIn: false },
  claude: { installed: false, loggedIn: false },
  defaultWorkspacePath: "",
  checkedAt: "",
};

function agentModeFromPrompt(prompt: string): AgentJobMode {
  return /作って|作り込|実装|修正|直して|落とし込|制作|完成させ/.test(prompt) ? "implement" : "brainstorm";
}

function agentTitleFromPrompt(prompt: string) {
  return prompt
    .replace(/(?:Claude\s*Code|クロードコード|クラウドコード|Codex|コーデックス)/gi, "")
    .replace(/(?:で|を)?(?:開いて|起動して|呼んで|読んできて|作って|作り込んで|実装して|壁打ちして|考えて)/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 70) || "新しいアイデア";
}

const priorityLabel: Record<Priority, string> = {
  high: "最優先",
  medium: "通常",
  low: "低",
};

function modeLabel(mode: AssistantMode) {
  if (mode === "listening") return "LISTENING";
  if (mode === "thinking") return "ANALYZING";
  if (mode === "speaking") return "REPORTING";
  return "STANDBY";
}

function voiceOutputLevel(preferences: AppState["preferences"]) {
  if (preferences.voiceMuted === true) return 0;
  const saved = Number(preferences.voiceVolume);
  if (!Number.isFinite(saved)) return 0.8;
  return Math.min(1, Math.max(0, saved));
}

function eventTimeLabel(event: GoogleCalendarEvent) {
  if (event.allDay) return "終日";
  const start = new Date(event.start);
  const end = new Date(event.end);
  const format = new Intl.DateTimeFormat("ja-JP", {
    timeZone: "Asia/Tokyo",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
  return `${format.format(start)}–${format.format(end)}`;
}

function googleScheduleBriefing(schedule: GoogleTodaySchedule | null) {
  if (!schedule) return "Googleの予定と期限タスクは未確認です。取得できていないため、予定なしとは判断できません。";
  const dateLabel = scheduleDateLabel(schedule.date);
  const eventSummary = schedule.events.length
    ? `${dateLabel}のGoogleカレンダー予定は${schedule.events.length}件です。${schedule.events.slice(0, 3).map((event) => `${eventTimeLabel(event)} ${event.title}`).join("、")}。`
    : `${dateLabel}のGoogleカレンダー予定はありません。`;
  const overdue = schedule.tasks.filter((task) => task.overdue).length;
  const taskSummary = schedule.tasks.length
    ? `Google Tasksは${dateLabel}までの期限分が${schedule.tasks.length}件です。${overdue ? `うち期限超過は${overdue}件です。` : ""}`
    : `Google Tasksに${dateLabel}までの期限分はありません。`;
  return `${eventSummary}${taskSummary}`;
}

function morningBriefing(state: AppState, schedule: GoogleTodaySchedule | null) {
  const today = japanToday();
  const todayAmount = dailyRevenue(state, today);
  const monthAmount = monthlyRevenue(state, today.slice(0, 7));
  const followUps = schedule?.tasks.filter((task) => /顧客|お客様|フォロー|連絡|返信|架電|電話/.test(`${task.listTitle}${task.title}`)) || [];
  const sections = [
    `${state.preferences.userName}、おはようございます。${scheduleDateLabel(today)}の朝の報告です。`,
    googleScheduleBriefing(schedule),
    state.preferences.revenueEnabled
      ? `本日の登録売上は${formatCurrency(todayAmount)}、今月の累計は${formatCurrency(monthAmount)}です。`
      : "",
    followUps.length
      ? `本日までの顧客フォローは${followUps.length}件です。${followUps.slice(0, 3).map((task) => task.title).join("、")}。`
      : schedule ? "本日までの顧客フォローはありません。" : "顧客フォローは未確認です。",
  ];
  return sections.filter(Boolean).join("");
}

function shiftJapanDate(date: string, days: number) {
  const value = new Date(`${date}T12:00:00+09:00`);
  value.setUTCDate(value.getUTCDate() + days);
  return new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Tokyo", year: "numeric", month: "2-digit", day: "2-digit",
  }).format(value);
}

function scheduleDateLabel(date: string) {
  const today = japanToday();
  const relative = date === today ? "今日" : date === shiftJapanDate(today, 1) ? "明日" : date === shiftJapanDate(today, 2) ? "明後日" : "";
  const formatted = new Intl.DateTimeFormat("ja-JP", {
    timeZone: "Asia/Tokyo", month: "long", day: "numeric", weekday: "short",
  }).format(new Date(`${date}T12:00:00+09:00`));
  return relative ? `${relative}（${formatted}）` : formatted;
}

function validScheduleDate(year: number, month: number, day: number) {
  const candidate = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  const parsed = new Date(`${candidate}T12:00:00+09:00`);
  return Number.isNaN(parsed.getTime()) || shiftJapanDate(candidate, 0) !== candidate ? null : candidate;
}

function scheduleDateFromPrompt(prompt: string) {
  const today = japanToday();
  const normalized = prompt.replace(/\s/g, "");
  if (/明後日|あさって/.test(normalized)) return shiftJapanDate(today, 2);
  if (/明日|あした/.test(normalized)) return shiftJapanDate(today, 1);
  if (/昨日|きのう/.test(normalized)) return shiftJapanDate(today, -1);
  const daysLater = normalized.match(/(\d{1,3})日後/);
  if (daysLater) return shiftJapanDate(today, Number(daysLater[1]));
  const japaneseDate = normalized.match(/(?:(\d{4})年)?(\d{1,2})月(\d{1,2})日/);
  if (japaneseDate) return validScheduleDate(Number(japaneseDate[1] || today.slice(0, 4)), Number(japaneseDate[2]), Number(japaneseDate[3])) || today;
  const slashDate = normalized.match(/(?:(\d{4})\/)?(\d{1,2})\/(\d{1,2})/);
  if (slashDate) return validScheduleDate(Number(slashDate[1] || today.slice(0, 4)), Number(slashDate[2]), Number(slashDate[3])) || today;
  return today;
}

const weekdayIndex: Record<string, number> = {
  日: 0, 月: 1, 火: 2, 水: 3, 木: 4, 金: 5, 土: 6,
};

function taskDueDateFromPrompt(prompt: string) {
  const normalized = prompt.replace(/\s/g, "");
  if (/明後日|あさって|明日|あした|今日|本日|\d{1,3}日後|(?:\d{4}年)?\d{1,2}月\d{1,2}日|(?:\d{4}\/)?\d{1,2}\/\d{1,2}/.test(normalized)) {
    return scheduleDateFromPrompt(prompt);
  }
  const weekdayMatch = normalized.match(/(来週)?([月火水木金土日])曜(?:日)?/);
  if (!weekdayMatch) return japanToday();
  const today = japanToday();
  const todayWeekday = new Date(`${today}T12:00:00+09:00`).getUTCDay();
  const target = weekdayIndex[weekdayMatch[2]];
  if (weekdayMatch[1]) {
    const nextWeekStart = shiftJapanDate(japanWeekStart(today), 7);
    return shiftJapanDate(nextWeekStart, target === 0 ? 6 : target - 1);
  }
  let distance = (target - todayWeekday + 7) % 7;
  if (distance === 0) distance = 7;
  return shiftJapanDate(today, distance);
}

function taskTitleFromPrompt(prompt: string) {
  return prompt
    .replace(/Google\s*Tasks?|Googleタスク|グーグルタスク/gi, " ")
    .replace(/(?:\d{4}年)?\d{1,2}月\d{1,2}日/g, " ")
    .replace(/(?:\d{4}\/)?\d{1,2}\/\d{1,2}/g, " ")
    .replace(/明後日|あさって|明日|あした|今日|本日|来週|\d{1,3}日後|[月火水木金土日]曜(?:日)?/g, " ")
    .replace(/(?:の)?(?:タスク|リマインダー|リマインド)(?:に|へ|として|を)?/g, " ")
    .replace(/(?:を)?(?:追加|登録)(?:して)?|(?:を)?入れ(?:て|といて|ておいて)|覚え(?:て|といて)|設定して|リマインドして/g, " ")
    .replace(/(?:して|しといて)(?=[。！？!\s?]*$)/g, " ")
    .replace(/(?:ください|下さい|ほしい|欲しい|お願い)(?:です)?/g, " ")
    .replace(/[「」『』？?。、，,！!]/g, " ")
    .replace(/^[\sにへをで]+|[\sにへをで]+$/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function completionQueryFromPrompt(prompt: string) {
  return prompt
    .replace(/Google\s*Tasks?|Googleタスク|グーグルタスク/gi, " ")
    .replace(/(?:の)?タスク/g, " ")
    .replace(/(?:を)?(?:完了(?:にして)?|終了(?:にして)?|終わった|終わりました|済み(?:にして)?)/g, " ")
    .replace(/(?:ください|下さい|お願い)(?:です)?/g, " ")
    .replace(/[「」『』？?。！!]/g, " ")
    .replace(/^[\sにへをで]+|[\sにへをで]+$/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizedTaskText(value: string) {
  return value.normalize("NFKC").toLocaleLowerCase("ja").replace(/[\s\p{P}\p{S}]/gu, "");
}

const customerDeadlinePattern = /納品|提出|締切|〆切|顧客|お客様|クライアント/;

function deadlineRiskMessage(
  googleTasks: GoogleTaskItem[],
  localTasks: TaskItem[],
  today: string,
) {
  const riskyGoogleTasks = googleTasks.filter((task) => (
    Boolean(task.due)
    && task.due! <= today
    && customerDeadlinePattern.test(`${task.listTitle}${task.title}${task.notes || ""}`)
  ));
  const riskyLocalTasks = localTasks.filter((task) => (
    !task.completed
    && Boolean(task.dueDate)
    && task.dueDate! <= today
    && customerDeadlinePattern.test(`${task.projectName || ""}${task.title}`)
  ));
  const items = [
    ...riskyGoogleTasks.map((task) => ({ id: `google:${task.taskListId}:${task.id}`, title: task.title, due: task.due! })),
    ...riskyLocalTasks.map((task) => ({ id: `local:${task.id}`, title: task.title, due: task.dueDate! })),
  ].sort((left, right) => left.due.localeCompare(right.due) || left.title.localeCompare(right.title));
  if (!items.length) return null;
  const overdueCount = items.filter((item) => item.due < today).length;
  const summary = items.slice(0, 3).map((item) => `「${item.title}」（${scheduleDateLabel(item.due)}期限）`).join("、");
  return {
    key: `${today}:${items.map((item) => `${item.id}:${item.due}`).join("|")}`,
    text: `納品期日の遅延リスクがあります。対象は${items.length}件です。${summary}。${overdueCount ? `このうち${overdueCount}件は期限を過ぎています。` : "本日期限です。"}まず最優先の作業を確認してください。`,
  };
}

function monthKeyFromOffset(offset: number) {
  const today = japanToday();
  const index = Number(today.slice(0, 4)) * 12 + Number(today.slice(5, 7)) - 1 + offset;
  return `${Math.floor(index / 12)}-${String((index % 12) + 1).padStart(2, "0")}`;
}

function revenueBriefing(state: AppState, period: "today" | "month" | "lastMonth") {
  if (!state.revenue.length) return "売上データが未登録です。CSVを読み込むか、売上を手入力してください。";
  if (period === "today") {
    const date = japanToday();
    const entries = state.revenue.filter((entry) => entry.date === date);
    const bySource = [...new Set(entries.map((entry) => entry.source))].map((source) => {
      const amount = entries.filter((entry) => entry.source === source).reduce((sum, entry) => sum + entry.amount, 0);
      return `${source} ${formatCurrency(amount)}`;
    });
    return `本日の登録売上は${formatCurrency(dailyRevenue(state, date))}、明細は${entries.length}件です。${bySource.length ? `内訳は${bySource.join("、")}です。` : ""}`;
  }
  const month = monthKeyFromOffset(period === "lastMonth" ? -1 : 0);
  const entries = state.revenue.filter((entry) => entry.date.startsWith(`${month}-`));
  const label = `${Number(month.slice(5, 7))}月`;
  const bySource = [...new Set(entries.map((entry) => entry.source))].map((source) => {
    const amount = entries.filter((entry) => entry.source === source).reduce((sum, entry) => sum + entry.amount, 0);
    return `${source} ${formatCurrency(amount)}`;
  });
  return `${label}の登録売上は${formatCurrency(monthlyRevenue(state, month))}、明細は${entries.length}件です。${bySource.length ? `内訳は${bySource.join("、")}です。` : ""}`;
}

interface CalendarSearchIntent {
  query: string;
  startDate: string;
  endDate: string;
  order: "asc" | "desc" | "nearest";
}

function japanWeekStart(date: string) {
  const day = new Date(`${date}T12:00:00+09:00`).getUTCDay();
  return shiftJapanDate(date, -((day + 6) % 7));
}

function calendarMonthRange(year: number, month: number) {
  const startDate = `${year}-${String(month).padStart(2, "0")}-01`;
  const nextYear = month === 12 ? year + 1 : year;
  const nextMonth = month === 12 ? 1 : month + 1;
  const nextStart = `${nextYear}-${String(nextMonth).padStart(2, "0")}-01`;
  return { startDate, endDate: shiftJapanDate(nextStart, -1) };
}

function calendarQueryFromPrompt(prompt: string) {
  return prompt
    .replace(/Google\s*Calendar|Googleカレンダー|グーグルカレンダー/gi, " ")
    .replace(/(?:\d{4}年)?\d{1,2}月\d{1,2}日/g, " ")
    .replace(/(?:\d{4}\/)?\d{1,2}\/\d{1,2}/g, " ")
    .replace(/明後日|あさって|明日|あした|今日|本日|昨日|きのう|来週|今週|先週|来月|今月|先月|\d{1,3}日後/g, " ")
    .replace(/(?:(?:\d{4})年)?\d{1,2}月/g, " ")
    .replace(/^\s*(?:に)?(?:入って(?:い)?る|登録されている|ある)\s*/g, " ")
    .replace(/(?:次|前回|最後|今後|直近)(?:の)?/g, " ")
    .replace(/(?:の)?(?:予定日?|スケジュール|カレンダー|予約|アポ)(?:も)?/g, " ")
    .replace(/(?:は)?いつ(?:入って(?:い)?る|入っていますか|入ってますか|ある|ですか)?/g, " ")
    .replace(/(?:は)?何時(?:ですか|から)?/g, " ")
    .replace(/(?:も)?(?:入って(?:い)?る|入っていますか|入ってますか|ありますか|ある)(?:んですか|ですか|よね|ね)?/g, " ")
    .replace(/(?:も)?(?:探しきれない|探しきらない|探しきらん|探せない|見つからない|見つけられない|出てこない)(?:です|ですね|ね)?/g, " ")
    .replace(/(?:を)?(?:教えて|見せて|確認して|調べて|検索して)(?:ください|下さい)?/g, " ")
    .replace(/(?:でしょうか|ですか|ですよね|ですね|です|よね|ね)$/g, " ")
    .replace(/[？?。！!「」『』]/g, " ")
    .replace(/^[\sのはをがにで]+|[\sのはをがにで]+$/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function calendarSearchIntentFromPrompt(prompt: string): CalendarSearchIntent | null {
  const normalized = prompt.replace(/\s/g, "");
  if (!/予定|スケジュール|カレンダー|予約|アポ|面談|会議|ミーティング|打ち合わせ|コンサル|イベント/.test(normalized)) return null;

  const today = japanToday();
  const query = calendarQueryFromPrompt(prompt);
  const asksPast = /前回|最後|先週|先月|過去/.test(normalized);
  const asksFuture = /次(?:の)?|今後/.test(normalized);
  const order = asksPast ? "desc" : "asc";
  const explicitDay = /明後日|あさって|明日|あした|今日|本日|昨日|きのう|\d{1,3}日後|(?:\d{4}年)?\d{1,2}月\d{1,2}日|(?:\d{4}\/)?\d{1,2}\/\d{1,2}/.test(normalized);
  if (explicitDay) {
    const date = scheduleDateFromPrompt(prompt);
    return { query, startDate: date, endDate: date, order };
  }

  if (/来週|今週|先週/.test(normalized)) {
    const offset = normalized.includes("来週") ? 7 : normalized.includes("先週") ? -7 : 0;
    const startDate = shiftJapanDate(japanWeekStart(today), offset);
    return { query, startDate, endDate: shiftJapanDate(startDate, 6), order };
  }

  const namedMonth = normalized.match(/(?:(\d{4})年)?(\d{1,2})月/);
  if (namedMonth) {
    const range = calendarMonthRange(Number(namedMonth[1] || today.slice(0, 4)), Number(namedMonth[2]));
    return { query, ...range, order };
  }
  if (/来月|今月|先月/.test(normalized)) {
    const currentYear = Number(today.slice(0, 4));
    const currentMonth = Number(today.slice(5, 7));
    const delta = normalized.includes("来月") ? 1 : normalized.includes("先月") ? -1 : 0;
    const monthIndex = currentYear * 12 + currentMonth - 1 + delta;
    const range = calendarMonthRange(Math.floor(monthIndex / 12), (monthIndex % 12) + 1);
    return { query, ...range, order };
  }

  if (query) {
    if (asksPast) {
      return { query, startDate: shiftJapanDate(today, -730), endDate: today, order: "desc" };
    }
    if (asksFuture) {
      return { query, startDate: today, endDate: shiftJapanDate(today, 730), order: "asc" };
    }
    return {
      query,
      startDate: shiftJapanDate(today, -730),
      endDate: shiftJapanDate(today, 730),
      order: "nearest",
    };
  }
  return { query: "", startDate: today, endDate: today, order };
}

function calendarSearchDateLabel(date: string) {
  return new Intl.DateTimeFormat("ja-JP", {
    timeZone: "Asia/Tokyo", year: "numeric", month: "long", day: "numeric", weekday: "short",
  }).format(new Date(`${date}T12:00:00+09:00`));
}

function calendarSearchEventLabel(event: GoogleCalendarEvent) {
  const date = calendarSearchDateLabel(event.start.slice(0, 10));
  return `${date} ${eventTimeLabel(event)}「${event.title}」${event.calendarName ? `（${event.calendarName}）` : ""}`;
}

function googleCalendarSearchBriefing(result: GoogleCalendarSearchResult, order: "asc" | "desc" | "nearest") {
  const range = result.startDate === result.endDate
    ? calendarSearchDateLabel(result.startDate)
    : `${calendarSearchDateLabel(result.startDate)}から${calendarSearchDateLabel(result.endDate)}まで`;
  const subject = result.query ? `「${result.query}」を` : "予定を";
  const scope = `${result.calendarCount}個の閲覧可能なGoogleカレンダーで、${range}の${subject}検索しました。`;
  if (!result.events.length) return `${scope}該当する予定は見つかりませんでした。検索した期間外にある場合は、年や月を指定して聞いてください。`;
  const firstEventIsPast = result.events[0].start.slice(0, 10) < japanToday();
  const first = order === "desc" || (order === "nearest" && firstEventIsPast) ? "最も新しい過去の予定" : "最も近い予定";
  const details = result.events.slice(0, 5).map(calendarSearchEventLabel).join("、");
  return `${scope}${result.events.length}件見つかりました。${first}は${calendarSearchEventLabel(result.events[0])}です。${result.events.length > 1 ? `ほかの候補は、${details}です。` : ""}`;
}

function mediaSearchQuery(prompt: string, service: "youtube" | "amazon") {
  const withoutService = service === "youtube"
    ? prompt.replace(/YouTube|ユーチューブ/gi, " ")
    : prompt.replace(/Amazon\s*Music|Amazonミュージック|アマゾンミュージック/gi, " ");
  return withoutService
    .replace(/(?:で)?(?:検索|探して|見せて|開いて|かけて|流して|再生して|聴かせて|聞かせて)(?:ください|下さい)?[。！!]?/g, " ")
    .replace(/(?:の)?(?:動画|音楽|曲|楽曲|BGM|ミュージック)(?:を)?/gi, " ")
    .replace(/[「」『』]/g, " ")
    .replace(/^[でをに]+|[でをに]+$/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function researchQuery(prompt: string) {
  return prompt
    .replace(/(?:について)?(?:を)?(?:調べてきて|調べて|調査して|リサーチして|検索してきて)(?:ください|下さい)?[。！!]?/g, " ")
    .replace(/[「」『』]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function latestNewsTopic(prompt: string) {
  return prompt
    .replace(/最新(?:の)?|今日(?:の)?/g, " ")
    .replace(/ニュース/g, " ")
    .replace(/(?:を)?(?:画面に)?(?:表示して|見せて|教えて)(?:ください|下さい)?[。！!]?/g, " ")
    .replace(/[「」『』]/g, " ")
    .replace(/の\s*$/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function AssistantOrb({ mode, name }: { mode: AssistantMode; name: string }) {
  return (
    <div className={`assistant-orb mode-${mode}`} aria-label={`${name} ${modeLabel(mode)}`}>
      <div className="orb-ring ring-one" />
      <div className="orb-ring ring-two" />
      <div className="orb-ring ring-three" />
      <div className="orb-core">
        <span className="orb-mark">N</span>
      </div>
      <div className="orb-label">
        <strong>{name}</strong>
        <span>{modeLabel(mode)}</span>
      </div>
    </div>
  );
}

function HayatoCharacter({ mode, name }: { mode: AssistantMode; name: string }) {
  return (
    <div className={`hayato-avatar mode-${mode}`} aria-label={`${name} ${modeLabel(mode)}`}>
      <div className="hayato-avatar-stage" aria-hidden="true">
        <div className="hayato-ring hayato-ring-one" />
        <div className="hayato-ring hayato-ring-two" />
        <div className="hayato-floor-glow" />
        <div className="noriko-character-stack">
          <img
            className="noriko-character-image noriko-character-closed"
            src="./assets/noriko-character-closed.png"
            alt=""
          />
          <img
            className="noriko-character-image noriko-character-open"
            src="./assets/noriko-character-open.png"
            alt=""
          />
        </div>
      </div>
      <div className="hayato-avatar-label">
        <strong>{name}</strong>
        <span>{modeLabel(mode)}</span>
      </div>
    </div>
  );
}

function MetricCard({
  label,
  value,
  detail,
  accent = "cyan",
  onClick,
}: {
  label: string;
  value: string;
  detail: string;
  accent?: "cyan" | "gold" | "violet";
  onClick?: () => void;
}) {
  return (
    <button className={`metric-card accent-${accent}`} onClick={onClick} type="button">
      <span className="metric-label">{label}</span>
      <strong>{value}</strong>
      <span className="metric-detail">{detail}</span>
      <span className="metric-line" />
    </button>
  );
}

function TaskRow({
  task,
  onToggle,
  onDelete,
}: {
  task: TaskItem;
  onToggle: () => void;
  onDelete?: () => void;
}) {
  return (
    <div className={`task-row ${task.completed ? "is-complete" : ""}`}>
      <button className="task-check" onClick={onToggle} type="button" aria-label="完了状態を変更">
        {task.completed ? "✓" : ""}
      </button>
      <div className="task-copy">
        <strong>{task.title}</strong>
        <span>
          {task.projectName || "個人"} · {formatShortDate(task.dueDate)}
          {task.sourceFile ? ` · ${task.sourceFile}` : ""}
        </span>
      </div>
      <span className={`priority priority-${task.priority}`}>{priorityLabel[task.priority]}</span>
      {onDelete ? (
        <button className="icon-button danger" onClick={onDelete} type="button" aria-label="削除">
          ×
        </button>
      ) : null}
    </div>
  );
}

function GoogleTaskRow({
  task,
  onComplete,
  compact = false,
}: {
  task: GoogleTaskItem;
  onComplete: () => void;
  compact?: boolean;
}) {
  return (
    <div className={`task-row google-task-row ${task.overdue ? "is-overdue" : ""} ${compact ? "is-compact" : ""}`}>
      <button className="task-check" onClick={onComplete} type="button" aria-label="Google Taskを完了">
        ✓
      </button>
      <div className="task-copy">
        <strong>{task.title}</strong>
        <span>{task.listTitle} · {task.overdue ? `期限超過 ${formatShortDate(task.due)}` : formatShortDate(task.due)}</span>
        {!compact && task.notes ? <small>{task.notes}</small> : null}
      </div>
      <span className={`priority ${task.overdue ? "priority-high" : "priority-medium"}`}>{task.overdue ? "期限超過" : "Google"}</span>
      {task.url ? <button className="text-button" onClick={() => void window.hayato.openExternal(task.url!)} type="button">開く</button> : null}
    </div>
  );
}

function CameraPlayer({
  camera,
  onRemove,
  onOpen,
}: {
  camera: CameraItem;
  onRemove?: () => void;
  onOpen: () => void;
}) {
  return (
    <article className="camera-card">
      <div className="camera-frame">
        <iframe
          src={`https://www.youtube-nocookie.com/embed/${camera.videoId}?autoplay=1&mute=1&playsinline=1`}
          title={`${camera.name} ライブカメラ`}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          referrerPolicy="strict-origin-when-cross-origin"
          allowFullScreen
        />
        <span className="live-badge"><i /> LIVE</span>
      </div>
      <div className="camera-meta">
        <div>
          <strong>{camera.name}</strong>
          <span>{camera.location}{camera.channelTitle ? ` · ${camera.channelTitle}` : ""}</span>
        </div>
        <div className="camera-actions">
          <button className="text-button" onClick={onOpen} type="button">YouTube</button>
          {onRemove ? <button className="icon-button danger" onClick={onRemove} type="button">×</button> : null}
        </div>
      </div>
    </article>
  );
}

function EmptyCamera({ onSearch }: { onSearch: () => void }) {
  return (
    <button className="camera-empty" onClick={onSearch} type="button">
      <span className="radar-mini"><i /><b /></span>
      <strong>ライブ地点を追加</strong>
      <small>YouTubeライブURL、または地域検索</small>
    </button>
  );
}

function StarterOnboarding({
  state,
  complete,
}: {
  state: AppState;
  complete: (settings: { userName: string; assistantName: string; autoSpeak: boolean; morningReportEnabled: boolean }) => Promise<void>;
}) {
  const [userName, setUserName] = useState(state.preferences.userName === "あなた" ? "" : state.preferences.userName);
  const [assistantName, setAssistantName] = useState(state.preferences.assistantName || "NORIKO");
  const [autoSpeak, setAutoSpeak] = useState(state.preferences.autoSpeak);
  const [morningReportEnabled, setMorningReportEnabled] = useState(state.preferences.morningReportEnabled);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const platform = /Windows/i.test(navigator.userAgent) ? "Windows" : /Mac/i.test(navigator.userAgent) ? "Mac" : "このパソコン";

  async function submit(event: FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await complete({
        userName: userName.trim() || "あなた",
        assistantName: assistantName.trim() || "NORIKO",
        autoSpeak,
        morningReportEnabled,
      });
    } catch (setupError) {
      setError(String(setupError));
      setSubmitting(false);
    }
  }

  return (
    <main className="onboarding-screen">
      <section className="onboarding-card panel">
        <header>
          <span className="brand-emblem">N</span>
          <div><small>AI NORIKO STARTER KIT</small><h1>あなた専用のAI秘書を準備します</h1><p>{platform}用の保存先を自動で作成します。APIキーやGoogle認証は、あとから必要な機能だけ設定できます。</p></div>
        </header>
        <div className="onboarding-features">
          <article><b>01</b><strong>予定・タスク</strong><span>Google Calendar / Tasks</span></article>
          <article><b>02</b><strong>会話・ナレッジ</strong><span>Ollama / Obsidian</span></article>
          <article><b>03</b><strong>AI作業</strong><span>Codex / Claude Code</span></article>
        </div>
        <form className="onboarding-form" onSubmit={submit}>
          <label>あなたの呼び名<input autoFocus value={userName} onChange={(event) => setUserName(event.target.value)} placeholder="例：石橋さん" /></label>
          <label>AI秘書の名前<input value={assistantName} onChange={(event) => setAssistantName(event.target.value)} placeholder="NORIKO" /></label>
          <label className="toggle-row"><span><strong>回答を自動で読み上げる</strong><small>端末の標準音声。Fish Audioは後から追加できます。</small></span><input type="checkbox" checked={autoSpeak} onChange={(event) => setAutoSpeak(event.target.checked)} /></label>
          <label className="toggle-row"><span><strong>毎朝の予定・タスク報告</strong><small>初期時刻は8:00。設定画面で変更できます。</small></span><input type="checkbox" checked={morningReportEnabled} onChange={(event) => setMorningReportEnabled(event.target.checked)} /></label>
          {error ? <p className="onboarding-error">初期設定に失敗しました：{error}</p> : null}
          <button className="primary-button onboarding-submit" disabled={submitting} type="submit">{submitting ? "準備しています…" : "AI秘書をはじめる"}</button>
        </form>
        <footer>認証情報はスターターキットには含まれません。各自の端末の暗号化ストレージに保存されます。</footer>
      </section>
    </main>
  );
}

function App() {
  const [state, setState] = useState<AppState | null>(null);
  const [activeView, setActiveView] = useState<ViewName>("dashboard");
  const [mode, setMode] = useState<AssistantMode>("idle");
  const [clock, setClock] = useState(new Date());
  const [command, setCommand] = useState("");
  const [chat, setChat] = useState<ChatEntry[]>([]);
  const [consultationMode, setConsultationMode] = useState(false);
  const [commandBusy, setCommandBusy] = useState(false);
  const [pendingAction, setPendingAction] = useState<{
    kind: "job" | "terminal";
    request: Omit<AgentStartRequest, "confirmed">;
  } | null>(null);
  const [pendingNote, setPendingNote] = useState<{ title: string; userText: string; assistantText: string } | null>(null);
  const [confirmationBusy, setConfirmationBusy] = useState(false);
  const [confirmationError, setConfirmationError] = useState("");
  const [notice, setNotice] = useState("");
  const [secretStatus, setSecretStatus] = useState<SecretStatus>(emptyStatus);
  const [cameraQuery, setCameraQuery] = useState("羽田空港 ライブカメラ");
  const [cameraResults, setCameraResults] = useState<YouTubeLiveResult[]>([]);
  const [cameraSearching, setCameraSearching] = useState(false);
  const [googleStatus, setGoogleStatus] = useState<GoogleAccountStatus>(emptyGoogleStatus);
  const [googleSchedule, setGoogleSchedule] = useState<GoogleTodaySchedule | null>(null);
  const [googleTodaySchedule, setGoogleTodaySchedule] = useState<GoogleTodaySchedule | null>(null);
  const [googleSyncing, setGoogleSyncing] = useState(false);
  const [googleTasks, setGoogleTasks] = useState<GoogleTaskCollection | null>(null);
  const [googleTasksSyncing, setGoogleTasksSyncing] = useState(false);
  const [googleWeek, setGoogleWeek] = useState<GoogleWeekSchedule | null>(null);
  const [googleWeekSyncing, setGoogleWeekSyncing] = useState(false);
  const [localStatus, setLocalStatus] = useState<LocalSystemStatus>(emptyLocalStatus);
  const [knowledgeStatus, setKnowledgeStatus] = useState<ObsidianKnowledgeStatus>(emptyKnowledgeStatus);
  const [agentAvailability, setAgentAvailability] = useState<AgentAvailability>(emptyAgentAvailability);
  const [agentJobs, setAgentJobs] = useState<AgentJob[]>([]);
  const [researchResult, setResearchResult] = useState<ResearchResult | null>(null);

  const commandRef = useRef<HTMLInputElement>(null);
  const commandBusyRef = useRef(false);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const activeAudioRef = useRef<HTMLAudioElement | null>(null);
  const speechRequestIdRef = useRef(0);
  const voiceLevelRef = useRef(0.8);
  const recognitionRef = useRef<InstanceType<NonNullable<typeof window.SpeechRecognition>> | null>(null);
  const morningReportStartedRef = useRef("");
  const dailySyncStartedRef = useRef("");
  const lastGoogleRefreshRef = useRef(0);
  const googleGenerationRef = useRef(0);
  const googleScheduleRequestRef = useRef(0);
  const googleTodayRequestRef = useRef(0);
  const googleTasksRequestRef = useRef(0);
  const googleWeekRequestRef = useRef(0);
  const googleStatusRef = useRef(googleStatus);
  googleStatusRef.current = googleStatus;
  const selectedGoogleDateRef = useRef(japanToday());
  const lastTodayRef = useRef(japanToday());
  const deadlineRiskAlertStartedRef = useRef("");
  const agentJobStatusesRef = useRef<Record<string, AgentJob["status"]>>({});

  useEffect(() => {
    Promise.all([
      window.hayato.getState(),
      window.hayato.getConfigStatus(),
      window.hayato.getGoogleStatus(),
      window.hayato.getLocalStatus(),
      window.hayato.getKnowledgeStatus(),
      window.hayato.getAgentStatus(),
      window.hayato.listAgentJobs(),
    ])
      .then(([savedState, status, accountStatus, local, knowledge, agents, jobs]) => {
        setState(savedState);
        setSecretStatus(status);
        setGoogleStatus(accountStatus);
        setLocalStatus(local);
        setKnowledgeStatus(knowledge);
        setAgentAvailability(agents);
        setAgentJobs(jobs);
        agentJobStatusesRef.current = Object.fromEntries(jobs.map((job) => [job.id, job.status]));
        setChat([
          {
            id: uid("chat"),
            role: "assistant",
            text: `${savedState.preferences.userName}、システムを起動しました。今日の状況を報告できます。`,
            createdAt: new Date().toISOString(),
          },
        ]);
      })
      .catch((error) => setNotice(String(error)));
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => setClock(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => window.hayato.onAssistantFocus(() => commandRef.current?.focus()), []);

  useEffect(() => window.hayato.onAgentJobUpdated((job) => {
    const previous = agentJobStatusesRef.current[job.id];
    agentJobStatusesRef.current[job.id] = job.status;
    setAgentJobs((jobs) => [job, ...jobs.filter((item) => item.id !== job.id)]);
    if (previous === job.status || !["completed", "failed", "cancelled"].includes(job.status)) return;
    const provider = job.provider === "claude" ? "Claude Code" : "Codex";
    const message = job.status === "completed"
      ? `${provider}の「${job.title}」が完了しました。AI作業画面で結果を確認できます。`
      : job.status === "cancelled"
        ? `${provider}の「${job.title}」を中止しました。`
        : `${provider}の「${job.title}」で問題が発生しました。AI作業画面を確認してください。`;
    setNotice(message);
    void window.hayato.showNotification({ title: "AI NORIKO AI作業", body: message, silent: true });
  }), []);

  useEffect(() => () => {
    speechRequestIdRef.current += 1;
    stopCurrentPlayback();
  }, []);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(""), 5000);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const commit = useCallback((updater: (current: AppState) => AppState) => {
    setState((current) => {
      if (!current) return current;
      const next = updater(current);
      void window.hayato.saveState(next).catch((error) => setNotice(String(error)));
      return next;
    });
  }, []);

  const today = japanToday();
  const incompleteTasks = useMemo(
    () => (state ? state.tasks.filter((task) => !task.completed) : []),
    [state],
  );
  const todayTasks = useMemo(
    () => incompleteTasks.filter((task) => !task.dueDate || task.dueDate === today),
    [incompleteTasks, today],
  );
  const todaySales = state ? dailyRevenue(state) : 0;

  function handleGoogleError(error: unknown, label: string) {
    const message = String(error);
    if (/GOOGLE_REAUTH_REQUIRED|invalid_grant|再認証/.test(message)) {
      googleGenerationRef.current += 1;
      setGoogleStatus((current) => ({ ...current, connected: false, reauthRequired: true }));
      setGoogleTodaySchedule(null);
      setGoogleSchedule(null);
      setGoogleTasks(null);
      setGoogleWeek(null);
      dailySyncStartedRef.current = "";
    }
    setNotice(`${label}を取得できませんでした。未確認として表示します。${message}`);
  }

  async function syncGoogleSchedule(targetDate = japanToday(), display = true) {
    const generation = googleGenerationRef.current;
    const request = display ? ++googleScheduleRequestRef.current : googleScheduleRequestRef.current;
    const isToday = targetDate === japanToday();
    const todayRequest = isToday ? ++googleTodayRequestRef.current : 0;
    if (display) {
      selectedGoogleDateRef.current = targetDate;
      setGoogleSchedule(null);
      setGoogleSyncing(true);
    }
    try {
      const next = await window.hayato.syncGoogleToday(targetDate);
      if (generation !== googleGenerationRef.current || next.date !== targetDate) return null;
      if (display && request === googleScheduleRequestRef.current) setGoogleSchedule(next);
      if (isToday && targetDate === japanToday() && todayRequest === googleTodayRequestRef.current) {
        setGoogleTodaySchedule(next);
        dailySyncStartedRef.current = targetDate;
        if (!display && selectedGoogleDateRef.current === targetDate) setGoogleSchedule(next);
      }
      return next;
    } catch (error) {
      if (generation !== googleGenerationRef.current) return null;
      if (!(display && request === googleScheduleRequestRef.current) && !(isToday && todayRequest === googleTodayRequestRef.current)) return null;
      if (display && request === googleScheduleRequestRef.current) setGoogleSchedule(null);
      if (isToday && todayRequest === googleTodayRequestRef.current) {
        setGoogleTodaySchedule(null);
        if (selectedGoogleDateRef.current === targetDate) setGoogleSchedule(null);
        dailySyncStartedRef.current = "";
      }
      handleGoogleError(error, "Googleの予定");
      return null;
    } finally {
      if (display && request === googleScheduleRequestRef.current) setGoogleSyncing(false);
    }
  }

  async function syncGoogleTasks() {
    const generation = googleGenerationRef.current;
    const request = ++googleTasksRequestRef.current;
    setGoogleTasksSyncing(true);
    try {
      const next = await window.hayato.listGoogleTasks();
      if (generation !== googleGenerationRef.current || request !== googleTasksRequestRef.current) return null;
      setGoogleTasks(next);
      return next;
    } catch (error) {
      if (generation !== googleGenerationRef.current || request !== googleTasksRequestRef.current) return null;
      setGoogleTasks(null);
      handleGoogleError(error, "Google Tasks");
      return null;
    } finally {
      if (request === googleTasksRequestRef.current) setGoogleTasksSyncing(false);
    }
  }

  async function syncGoogleWeek(targetDate = today) {
    const generation = googleGenerationRef.current;
    const request = ++googleWeekRequestRef.current;
    setGoogleWeekSyncing(true);
    setGoogleWeek(null);
    try {
      const next = await window.hayato.syncGoogleWeek(targetDate);
      if (generation !== googleGenerationRef.current || request !== googleWeekRequestRef.current) return null;
      setGoogleWeek(next);
      return next;
    } catch (error) {
      if (generation !== googleGenerationRef.current || request !== googleWeekRequestRef.current) return null;
      setGoogleWeek(null);
      handleGoogleError(error, "週間スケジュール");
      return null;
    } finally {
      if (request === googleWeekRequestRef.current) setGoogleWeekSyncing(false);
    }
  }

  async function refreshGoogleTaskViews() {
    await Promise.all([
      syncGoogleSchedule(googleSchedule?.date || today),
      ...(googleSchedule?.date && googleSchedule.date !== today ? [syncGoogleSchedule(today, false)] : []),
      syncGoogleTasks(),
      syncGoogleWeek(googleWeek?.startDate || today),
    ]);
  }

  async function createTask(request: GoogleTaskCreateRequest) {
    const task = await window.hayato.createGoogleTask(request);
    await refreshGoogleTaskViews();
    return task;
  }

  async function completeTask(task: GoogleTaskItem) {
    if (!googleStatus.tasksWritable) {
      const error = new Error("Google Tasksの完了権限を一度だけ追加してください。");
      setActiveView("settings");
      setNotice(error.message);
      throw error;
    }
    try {
      await window.hayato.completeGoogleTask({ taskListId: task.taskListId, taskId: task.id });
      await refreshGoogleTaskViews();
    } catch (error) {
      setNotice(String(error));
      throw error;
    }
  }

  async function connectGoogle() {
    try {
      googleGenerationRef.current += 1;
      const result = await window.hayato.connectGoogle();
      if (result.needsConfig) {
        setActiveView("settings");
        setNotice("先に設定画面でGoogle OAuthクライアントJSONを読み込んでください。");
        return;
      }
      if (result.status) setGoogleStatus(result.status);
      const [schedule] = await Promise.all([syncGoogleSchedule(), syncGoogleTasks(), syncGoogleWeek()]);
      if (schedule) setNotice(`${schedule.email}と接続し、今日の予定を同期しました。`);
    } catch (error) {
      setNotice(`Google連携に失敗しました: ${String(error)}`);
    }
  }

  async function disconnectGoogle() {
    try {
      googleGenerationRef.current += 1;
      const next = await window.hayato.disconnectGoogle();
      setGoogleStatus(next);
      setGoogleSchedule(null);
      setGoogleTodaySchedule(null);
      setGoogleTasks(null);
      setGoogleWeek(null);
      dailySyncStartedRef.current = "";
      setNotice("Googleアカウントとの連携を解除しました。");
    } catch (error) {
      setNotice(String(error));
    }
  }

  function addChat(role: ChatEntry["role"], text: string, sources?: string[]) {
    setChat((entries) => [
      ...entries.slice(-19),
      { id: uid("chat"), role, text, createdAt: new Date().toISOString(), sources },
    ]);
  }

  function stopCurrentPlayback() {
    if (activeAudioRef.current) {
      activeAudioRef.current.pause();
      activeAudioRef.current.removeAttribute("src");
      activeAudioRef.current.load();
      activeAudioRef.current = null;
    }
    window.speechSynthesis?.cancel();
  }

  function beginSpeechRequest() {
    const requestId = speechRequestIdRef.current + 1;
    speechRequestIdRef.current = requestId;
    stopCurrentPlayback();
    return requestId;
  }

  function cancelSpeech() {
    speechRequestIdRef.current += 1;
    stopCurrentPlayback();
    setMode("idle");
  }

  function systemSpeak(text: string, requestId: number) {
    if (requestId !== speechRequestIdRef.current) return;
    if (!("speechSynthesis" in window)) {
      setMode("idle");
      return;
    }
    const volume = voiceLevelRef.current;
    if (volume <= 0) {
      setMode("idle");
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "ja-JP";
    utterance.rate = 1.05;
    utterance.pitch = 0.92;
    utterance.volume = volume;
    utterance.onend = () => {
      if (requestId === speechRequestIdRef.current) setMode("idle");
    };
    utterance.onerror = () => {
      if (requestId === speechRequestIdRef.current) setMode("idle");
    };
    window.speechSynthesis.speak(utterance);
  }

  async function speak(text: string) {
    const volume = state ? voiceOutputLevel(state.preferences) : 0;
    if (!state?.preferences.autoSpeak || volume <= 0) {
      setMode("idle");
      return;
    }
    const requestId = beginSpeechRequest();
    setMode("speaking");
    try {
      const result = await window.hayato.speak(text);
      if (requestId !== speechRequestIdRef.current) return;
      if (!result.audio) {
        systemSpeak(text, requestId);
        return;
      }
      const audio = new Audio(`data:${result.mimeType || "audio/mpeg"};base64,${result.audio}`);
      audio.volume = voiceLevelRef.current;
      activeAudioRef.current = audio;
      audio.onended = () => {
        if (activeAudioRef.current === audio) activeAudioRef.current = null;
        if (requestId === speechRequestIdRef.current) setMode("idle");
      };
      let fallbackStarted = false;
      const fallback = () => {
        if (fallbackStarted || requestId !== speechRequestIdRef.current) return;
        fallbackStarted = true;
        if (activeAudioRef.current === audio) activeAudioRef.current = null;
        systemSpeak(text, requestId);
      };
      audio.onerror = fallback;
      try {
        await audio.play();
      } catch {
        fallback();
      }
    } catch (error) {
      if (requestId !== speechRequestIdRef.current) return;
      setNotice(`Fish Audioを利用できないため端末音声で再生します: ${String(error)}`);
      systemSpeak(text, requestId);
    }
  }

  async function playFishVoiceTest() {
    const requestId = beginSpeechRequest();
    setMode("speaking");
    try {
      const result = await window.hayato.speak("こんにちは。AI秘書の音声接続テストです。今日もよろしくお願いします。");
      if (requestId !== speechRequestIdRef.current) return { ...result, cancelled: true };
      if (!result.audio) {
        setMode("idle");
        return result;
      }
      const audio = new Audio(`data:${result.mimeType || "audio/mpeg"};base64,${result.audio}`);
      audio.volume = voiceLevelRef.current;
      activeAudioRef.current = audio;
      audio.onended = () => {
        if (activeAudioRef.current === audio) activeAudioRef.current = null;
        if (requestId === speechRequestIdRef.current) setMode("idle");
      };
      audio.onerror = () => {
        if (activeAudioRef.current === audio) activeAudioRef.current = null;
        if (requestId === speechRequestIdRef.current) setMode("idle");
      };
      await audio.play();
      return result;
    } catch (error) {
      if (requestId === speechRequestIdRef.current) setMode("idle");
      throw error;
    }
  }

  useEffect(() => {
    if (!state) return;
    const volume = voiceOutputLevel(state.preferences);
    voiceLevelRef.current = volume;
    if (activeAudioRef.current) activeAudioRef.current.volume = volume;
    if (volume > 0 && state.preferences.autoSpeak) return;
    speechRequestIdRef.current += 1;
    stopCurrentPlayback();
    setMode("idle");
  }, [state?.preferences.autoSpeak, state?.preferences.voiceMuted, state?.preferences.voiceVolume]);

  useEffect(() => {
    if (lastTodayRef.current !== today) {
      const oldToday = lastTodayRef.current;
      lastTodayRef.current = today;
      googleGenerationRef.current += 1;
      setGoogleTodaySchedule(null);
      setGoogleTasks(null);
      setGoogleWeek(null);
      dailySyncStartedRef.current = "";
      if (selectedGoogleDateRef.current === oldToday) {
        selectedGoogleDateRef.current = today;
        setGoogleSchedule(null);
      }
    }
    if (!googleStatus.connected) {
      googleGenerationRef.current += 1;
      setGoogleTodaySchedule(null);
      setGoogleSchedule(null);
      setGoogleTasks(null);
      setGoogleWeek(null);
      dailySyncStartedRef.current = "";
      return;
    }
    const refresh = () => {
      if (!googleStatusRef.current.connected) return;
      lastGoogleRefreshRef.current = Date.now();
      void syncGoogleSchedule(japanToday(), false);
      if (selectedGoogleDateRef.current !== japanToday()) void syncGoogleSchedule(selectedGoogleDateRef.current);
      void syncGoogleTasks();
      void syncGoogleWeek(japanToday());
    };
    refresh();
    const resume = () => {
      setClock(new Date());
      refresh();
    };
    const visible = () => { if (document.visibilityState === "visible") resume(); };
    const timer = window.setInterval(() => {
      const interval = dailySyncStartedRef.current === japanToday() ? 300_000 : 60_000;
      if (Date.now() - lastGoogleRefreshRef.current >= interval) refresh();
    }, 15_000);
    window.addEventListener("focus", resume);
    window.addEventListener("online", resume);
    document.addEventListener("visibilitychange", visible);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener("focus", resume);
      window.removeEventListener("online", resume);
      document.removeEventListener("visibilitychange", visible);
    };
  }, [today, googleStatus.connected]);

  useEffect(() => {
    if (!state?.preferences.morningReportEnabled) return;
    if (googleStatus.connected && (!googleTodaySchedule || googleTodaySchedule.date !== japanToday())) return;
    const checkMorningReport = () => {
      const now = new Date();
      const currentTime = new Intl.DateTimeFormat("sv-SE", {
        timeZone: "Asia/Tokyo", hour: "2-digit", minute: "2-digit", hour12: false,
      }).format(now);
      const scheduledTime = /^\d{2}:\d{2}$/.test(state.preferences.morningReportTime || "")
        ? state.preferences.morningReportTime
        : "08:00";
      const todayKey = japanToday();
      if (
        currentTime < scheduledTime
        || state.preferences.lastMorningReportDate === todayKey
        || morningReportStartedRef.current === todayKey
      ) return;
      morningReportStartedRef.current = todayKey;
      const report = morningBriefing(state, googleTodaySchedule?.date === today ? googleTodaySchedule : null);
      commit((current) => ({
        ...current,
        preferences: { ...current.preferences, lastMorningReportDate: todayKey },
      }));
      setActiveView("dashboard");
      addChat("assistant", report);
      void window.hayato.showNotification({ title: "AI NORIKO 朝の報告", body: report, silent: true });
      void speak(report);
    };
    checkMorningReport();
    const timer = window.setInterval(checkMorningReport, 60_000);
    return () => window.clearInterval(timer);
  }, [state, googleTodaySchedule, googleStatus.connected, commit]);

  useEffect(() => {
    if (!state || !googleTasks) return;
    const alert = deadlineRiskMessage(googleTasks.tasks, state.tasks, today);
    if (
      !alert
      || state.preferences.lastDeadlineRiskAlertKey === alert.key
      || deadlineRiskAlertStartedRef.current === alert.key
    ) return;
    deadlineRiskAlertStartedRef.current = alert.key;
    commit((current) => ({
      ...current,
      preferences: { ...current.preferences, lastDeadlineRiskAlertKey: alert.key },
    }));
    addChat("assistant", alert.text);
    setNotice(alert.text);
    void window.hayato.showNotification({ title: "AI NORIKO 納品期限アラート", body: alert.text, silent: true });
    void speak(alert.text);
  }, [state, googleTasks, today, commit]);

  function assistantContext(current: AppState) {
    return {
      date: today,
      tasks: current.tasks.map(({ title, completed, priority, dueDate, projectName }) => ({
        title,
        completed,
        priority,
        dueDate,
        projectName,
      })),
      projects: current.projects.map(({ name, gitSummary, scannedAt }) => ({ name, gitSummary, scannedAt })),
      revenueToday: dailyRevenue(current),
      revenueEntriesToday: current.revenue.filter((entry) => entry.date === today),
      cameras: current.cameras.map(({ name, location }) => ({ name, location })),
      googleSchedule: googleTodaySchedule?.date === today ? googleTodaySchedule : null,
      googleTasks,
      googleWeek,
    };
  }

  function recentConversation() {
    return chat.slice(-12).map((entry) => `${entry.role === "user" ? "ユーザー" : "NORIKO（AI提案・未承認）"}: ${entry.text}`).join("\n");
  }

  function queueAction(kind: "job" | "terminal", request: Omit<AgentStartRequest, "confirmed">) {
    setConfirmationError("");
    setPendingNote(null);
    setPendingAction({ kind, request: { ...request, conversation: request.conversation ?? recentConversation() } });
  }

  async function startBackgroundAgentJob(request: Omit<AgentStartRequest, "confirmed">) {
    const job = await window.hayato.startAgentJob({
      ...request,
      conversation: request.conversation ?? recentConversation(),
      confirmed: true,
    });
    setAgentJobs((jobs) => [job, ...jobs.filter((item) => item.id !== job.id)]);
    agentJobStatusesRef.current[job.id] = job.status;
    setActiveView("agents");
    setNotice(`${job.provider === "claude" ? "Claude Code" : "Codex"}へ作業を渡しました。NORIKOはこのまま使えます。`);
    return job;
  }

  async function confirmAction() {
    if (!pendingAction || confirmationBusy) return;
    setConfirmationBusy(true);
    setConfirmationError("");
    try {
      const { request, kind } = pendingAction;
      if (kind === "job") {
        const job = await startBackgroundAgentJob(request);
        addChat("assistant", `${job.provider === "claude" ? "Claude Code" : "Codex"}へ、確認した内容を引き継ぎました。`);
      } else {
        const result = await window.hayato.openAgentTerminal({
          provider: request.provider,
          projectPath: request.projectPath,
          conversation: `${request.conversation || ""}\n\n今回の依頼: ${request.prompt}`,
          confirmed: true,
        });
        addChat("assistant", `${request.provider === "claude" ? "Claude Code" : "Codex"}を開きました。相談内容の引き継ぎファイル：${result.requestPath || result.projectPath}。ファイルを参照して続けてください。`);
      }
      setPendingAction(null);
    } catch (error) {
      setConfirmationError(String(error));
    } finally {
      setConfirmationBusy(false);
    }
  }

  function previewKnowledgeNote(prompt: string) {
    setConfirmationError("");
    setPendingAction(null);
    setPendingNote({
      title: `${japanToday()} 相談の記録`,
      userText: [...chat.filter((entry) => entry.role === "user").slice(-6).map((entry) => entry.text), prompt].join("\n\n"),
      assistantText: chat.filter((entry) => entry.role === "assistant").slice(-6).map((entry) => entry.text).join("\n\n"),
    });
  }

  async function confirmKnowledgeNote() {
    if (!pendingNote || confirmationBusy) return;
    setConfirmationBusy(true);
    setConfirmationError("");
    try {
      const result = await window.hayato.saveKnowledge({ ...pendingNote, confirmed: true });
      setKnowledgeStatus(await window.hayato.getKnowledgeStatus());
      addChat("assistant", `Obsidianのナレッジフォルダに新しい記録を保存しました。\n${result.path}\n本人の発言とAIの提案は区別しています。内容をご確認ください。`, [result.relativePath]);
      setPendingNote(null);
    } catch (error) {
      setConfirmationError(`保存できませんでした。${String(error)}`);
    } finally {
      setConfirmationBusy(false);
    }
  }

  async function askConsultation(prompt: string) {
    if (!state) return { text: "初期化をお待ちください。", sources: undefined };
    setConsultationMode(true);
    setActiveView("dashboard");
    const response = await window.hayato.askAI({
      prompt,
      context: assistantContext(state),
      history: chat.filter((entry) => entry.role !== "system").slice(-12).map((entry) => ({ role: entry.role as "user" | "assistant", content: entry.text })),
    });
    return {
      sources: response.knowledgeSources?.map((source) => source.relativePath),
      text: response.localUnavailable
        ? `無料のローカルAIを起動できませんでした。設定画面でLOCAL AIの状態を確認してください。${response.error ? ` ${response.error}` : ""}`
        : response.needsKey
          ? "有料APIモードを使うにはOpenAI APIキーが必要です。無料モードへ戻すとローカルAIを利用できます。"
          : response.text || "回答を取得できませんでした。",
    };
  }

  async function refreshAgentAvailability() {
    const next = await window.hayato.getAgentStatus();
    setAgentAvailability(next);
    return next;
  }

  async function runCommand(rawCommand: string) {
    const prompt = rawCommand.trim();
    if (!prompt || !state || commandBusyRef.current) return;
    if (pendingAction || pendingNote) {
      setNotice("先に確認画面で実行・保存するか、キャンセルしてください。");
      return;
    }
    commandBusyRef.current = true;
    setCommandBusy(true);
    setCommand("");
    addChat("user", prompt);
    setMode("thinking");

    const normalized = prompt.replace(/\s/g, "");
    const calendarIntent = calendarSearchIntentFromPrompt(prompt);
    const agentIntent = directAgentRequest(prompt);
    let reply = "";
    let replySources: string[] | undefined;
    let shouldSpeak = true;

    try {
      if (/^(?:中止|止めて|黙って|読み上げを止めて)[。！!]*$/.test(normalized)) {
        cancelSpeech();
        reply = "読み上げを停止しました。AI作業の中止はAI作業画面から操作してください。";
        shouldSpeak = false;
      } else if (isKnowledgeRecordRequest(prompt)) {
        previewKnowledgeNote(prompt);
        reply = "記録の下書きを表示しました。本人の発言とAIの提案、保存先を確認してから保存してください。まだファイルは作成していません。";
        shouldSpeak = false;
      } else if (isDiscussionRequest(prompt) || (consultationMode && !agentIntent)) {
        const response = await askConsultation(prompt);
        reply = response.text;
        replySources = response.sources;
      } else if (agentIntent) {
        queueAction(agentIntent.kind, {
          provider: agentIntent.provider,
          mode: agentModeFromPrompt(normalized),
          title: agentTitleFromPrompt(prompt),
          prompt,
          conversation: `${recentConversation()}\nユーザー: ${prompt}`,
        });
        reply = "引き継ぎ内容を表示しました。実行先と内容を確認し、開始ボタンを押すまでは起動・作業・外部送信は行いません。";
        shouldSpeak = false;
      } else if (/(今日|本日).*(状況|報告)|ブリーフィング/.test(normalized)) {
        setActiveView("dashboard");
        const latest = googleStatus.connected ? await syncGoogleSchedule(today, false) : null;
        reply = morningBriefing(state, latest);
      } else if (/(今週|一週間|1週間).*(予定|スケジュール|タスク|やること)/.test(normalized)) {
        setActiveView("week");
        if (!googleStatus.connected) {
          reply = "Googleアカウントが未接続です。予定画面から接続してください。";
        } else {
          const week = await syncGoogleWeek(today);
          reply = week
            ? `今週は、予定が${week.events.length}件、期限タスクが${week.tasks.filter((task) => task.due && task.due >= week.startDate).length}件、期限超過が${week.tasks.filter((task) => task.overdue).length}件です。週間画面に表示しました。`
            : "週間スケジュールを取得できませんでした。";
        }
      } else if (/(?:タスク)?.*(?:完了にして|完了した|終わった|終わりました|済みにして)|(?:完了|終了).*(?:タスク)/.test(normalized)) {
        setActiveView("tasks");
        if (!googleStatus.connected) {
          reply = "Googleアカウントが未接続です。予定画面から接続してください。";
        } else if (!googleStatus.tasksWritable) {
          setActiveView("settings");
          reply = "Google Tasksへ完了を書き込む権限を更新してください。設定画面の「Google権限を更新」を押すと、一度だけGoogle認証が開きます。";
        } else {
          const query = completionQueryFromPrompt(prompt);
          if (!query) {
            reply = "どのタスクを完了するか、タスク名を付けて話してください。";
          } else {
            const collection = await syncGoogleTasks();
            if (!collection) throw new Error("Google Tasksは未確認です。完了処理は行っていません。");
            const needle = normalizedTaskText(query);
            const matches = (collection?.tasks || []).filter((task) => normalizedTaskText(task.title).includes(needle));
            const exact = matches.find((task) => normalizedTaskText(task.title) === needle);
            const target = exact || (matches.length === 1 ? matches[0] : undefined);
            if (target) {
              await completeTask(target);
              reply = `「${target.title}」をGoogle Tasksで完了にしました。`;
            } else if (matches.length > 1) {
              reply = `候補が${matches.length}件あります。${matches.slice(0, 5).map((task) => `「${task.title}」`).join("、")}のように、もう少し詳しく指定してください。`;
            } else {
              reply = `「${query}」に一致する未完了のGoogle Taskが見つかりませんでした。`;
            }
          }
        }
      } else if (
        /(?:タスク|リマインド|リマインダー|フォロー).*(?:入れて|入れといて|追加|登録|設定|覚えて)/.test(normalized)
        || /(?:入れて|入れといて|追加|登録).*(?:タスク|リマインド|リマインダー)/.test(normalized)
        || /(?:リマインド|リマインダー)(?:して|お願い)/.test(normalized)
      ) {
        setActiveView("tasks");
        if (!googleStatus.connected) {
          reply = "Googleアカウントが未接続です。予定画面から接続してください。";
        } else if (!googleStatus.tasksWritable) {
          setActiveView("settings");
          reply = "Google Tasksへ登録する権限を更新してください。設定画面の「Google権限を更新」を押すと、一度だけGoogle認証が開きます。";
        } else {
          const title = taskTitleFromPrompt(prompt);
          const due = taskDueDateFromPrompt(prompt);
          const isFollowUp = /顧客|お客様|フォロー|連絡|返信|架電|電話/.test(normalized);
          if (!title) {
            reply = "登録するタスク名を指定してください。例として「明日、田中さんへ連絡をタスクに入れて」と話せます。";
          } else {
            const task = await createTask({
              title,
              due,
              listTitle: isFollowUp ? "顧客フォロー" : undefined,
              notes: "AI NORIKOから音声・会話で登録",
            });
            reply = `「${task.title}」を${scheduleDateLabel(due)}期限でGoogle Tasks${isFollowUp ? "の顧客フォロー" : ""}に登録しました。`;
          }
        }
      } else if (/顧客.*フォロー|フォロー.*(?:教えて|見せて|確認|一覧)/.test(normalized)) {
        setActiveView("tasks");
        if (!googleStatus.connected) {
          reply = "Googleアカウントが未接続です。予定画面から接続してください。";
        } else {
          const collection = await syncGoogleTasks();
          const followUps = (collection?.tasks || []).filter((task) => /顧客|お客様|フォロー|連絡|返信|架電|電話/.test(`${task.listTitle}${task.title}`));
          reply = !collection ? "顧客フォローは未確認です。Google Tasksの再取得が必要です。" : followUps.length
            ? `顧客フォローは${followUps.length}件です。${followUps.slice(0, 5).map((task) => `${task.title}${task.due ? `、期限は${scheduleDateLabel(task.due)}` : ""}`).join("。")}。`
            : "未完了の顧客フォローはありません。";
        }
      } else if (calendarIntent) {
        setActiveView("schedule");
        if (!googleStatus.connected) {
          reply = "Googleアカウントが未接続です。予定画面から接続してください。";
        } else if (!calendarIntent.query && calendarIntent.startDate === calendarIntent.endDate) {
          const latest = await syncGoogleSchedule(calendarIntent.startDate);
          reply = latest ? googleScheduleBriefing(latest) : "Googleカレンダーを取得できませんでした。予定は未確認です。";
        } else {
          const result = await window.hayato.searchGoogleCalendar({
            query: calendarIntent.query,
            startDate: calendarIntent.startDate,
            endDate: calendarIntent.endDate,
            order: calendarIntent.order,
            limit: 20,
          });
          reply = googleCalendarSearchBriefing(result, calendarIntent.order);
        }
      } else if (/タスク|やること/.test(normalized)) {
        setActiveView("tasks");
        if (googleStatus.connected) {
          const collection = await syncGoogleTasks();
          const dueToday = collection?.tasks.filter((task) => task.due && task.due <= today) || [];
          reply = !collection ? "Google Tasksは未確認です。再取得が必要です。" : collection.tasks.length
            ? `Google Tasksの未完了は${collection.tasks.length}件です。本日までの期限は${dueToday.length}件あります。`
            : "Google Tasksに未完了タスクはありません。";
        } else {
          reply = incompleteTasks.length
            ? `端末内の未完了タスクは${incompleteTasks.length}件です。${todayTasks.length ? `本日対応するものは${todayTasks.length}件あります。` : "本日期限のものはありません。"}`
            : "未完了タスクはありません。";
        }
      } else if (/売上|収益|入金/.test(normalized)) {
        if (!state.preferences.revenueEnabled) {
          setActiveView("settings");
          reply = "売上管理は事業者向けの追加機能です。設定の「機能を追加」から有効にできます。";
        } else {
          setActiveView("revenue");
          const period = /先月/.test(normalized) ? "lastMonth" : /今月|月次|月間/.test(normalized) ? "month" : "today";
          reply = revenueBriefing(state, period);
        }
      } else if (
        /(YouTubeMusic|YouTubeミュージック|ユーチューブミュージック)/i.test(normalized)
        && /(ライブラリ|マイミュージック|プレイリスト)/.test(normalized)
        && /(開いて|見せて|表示)/.test(normalized)
      ) {
        await window.hayato.openInChrome("https://music.youtube.com/library");
        reply = "YouTube Musicのライブラリを開きました。ログイン済みのGoogleアカウントの曲やプレイリストを選べます。";
      } else if (/(最新|今日).*(ニュース)|ニュース.*(画面|表示|見せて|教えて)/.test(normalized)) {
        const topic = latestNewsTopic(prompt);
        setActiveView("dashboard");
        const result = await window.hayato.getLatestNews(topic || undefined);
        setResearchResult(result);
        window.setTimeout(() => {
          const scroller = document.querySelector<HTMLElement>(".view-scroll");
          const panel = document.querySelector<HTMLElement>(".research-panel");
          if (scroller && panel) {
            const top = panel.getBoundingClientRect().top
              - scroller.getBoundingClientRect().top
              + scroller.scrollTop
              - 16;
            scroller.scrollTo({ top, behavior: "smooth" });
          }
        }, 120);
        reply = `${result.sources.length}件の${topic ? `${topic}関連の` : ""}最新ニュースを画面に表示しました。見出しを選ぶと元の記事を開けます。`;
      } else if (/(YouTube|ユーチューブ)/i.test(prompt) && /(検索|探して|見せて|開いて|動画)/.test(normalized)) {
        const query = mediaSearchQuery(prompt, "youtube") || "おすすめ動画";
        await window.hayato.openExternal(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);
        reply = `YouTubeで「${query}」を検索しました。検索結果をブラウザで開いています。`;
      } else if (
        /(AmazonMusic|Amazonミュージック|アマゾンミュージック)/i.test(normalized)
        || (/(音楽|曲|BGM|ミュージック)/i.test(prompt) && /(かけて|流して|再生して|聴かせて|聞かせて)/.test(normalized))
      ) {
        const query = mediaSearchQuery(prompt, "amazon") || "作業用BGM";
        await window.hayato.openExternal(`https://music.amazon.co.jp/search/${encodeURIComponent(query)}`);
        reply = `Amazon Musicで「${query}」を検索しました。曲またはプレイリストを選ぶと再生できます。`;
      } else if (/(調べてきて|調べて|調査して|リサーチして|検索してきて)/.test(normalized)) {
        const query = researchQuery(prompt);
        if (!query) {
          reply = "何について調べるか指定してください。例として『今日のAIニュースを調べてきて』と話せます。";
        } else {
          setActiveView("dashboard");
          const result = await window.hayato.researchWeb(query);
          setResearchResult(result);
          reply = `${result.summary}\n\n参照元${result.sources.length}件を調査レポートに表示しました。`;
        }
      } else if (/(天気|天候|気温|降水確率|雨降る|雨が降る)/.test(normalized)) {
        const region = cameraRegionFromPrompt(normalized) || cameraRegions[1];
        const saved = cameraForRegion(state.cameras, region);
        setActiveView("cameras");
        setCameraQuery(`${region.search} ライブカメラ`);
        if (saved) {
          commit((current) => ({
            ...current,
            cameras: [saved, ...current.cameras.filter((camera) => camera.id !== saved.id)],
          }));
        }
        const weather = await window.hayato.getWeather(region.key);
        reply = `${weatherBriefing(weather, /明日|あした/.test(normalized))}${saved ? `${saved.name}のライブカメラも表示しました。` : "ライブ画面も開きました。"}`;
      } else if (/カメラ|映して|現地|羽田|渋谷|札幌|新宿|東京|福岡|天神|博多|大阪|道頓堀|梅田|京都|沖縄|富士山/.test(normalized)) {
        setActiveView("cameras");
        const region = cameraRegionFromPrompt(normalized);
        const place = region?.key || ["羽田", "札幌", "京都", "沖縄", "富士山"].find((name) => normalized.includes(name));
        if (region) setCameraQuery(`${region.search} ライブカメラ`);
        else if (place) setCameraQuery(`${place} ライブカメラ`);
        const saved = region
          ? cameraForRegion(state.cameras, region)
          : state.cameras.find((camera) => place ? `${camera.name}${camera.location}`.includes(place) : false);
        if (saved) {
          commit((current) => ({
            ...current,
            cameras: [saved, ...current.cameras.filter((camera) => camera.id !== saved.id)],
          }));
        }
        reply = saved
          ? `${saved.location}のライブカメラを表示しました。`
          : `${place || "指定地域"}のライブ画面に移動しました。検索してお気に入りに追加できます。`;
      } else if (/プロジェクト|Git|進捗/.test(normalized)) {
        setActiveView("tasks");
        reply = state.projects.length
          ? `登録プロジェクトは${state.projects.length}件です。${state.projects.map((project) => `${project.name}は${project.gitSummary}`).join("、")}。`
          : "プロジェクトが未登録です。タスク画面からフォルダを登録してください。";
      } else {
        const response = await askConsultation(prompt);
        reply = response.text;
        replySources = response.sources;
      }
    } catch (error) {
      if (/GOOGLE_REAUTH_REQUIRED|invalid_grant/.test(String(error))) handleGoogleError(error, "Googleの情報");
      reply = `処理中に問題が発生しました。${String(error)}`;
    }

    addChat("assistant", reply, replySources);
    try {
      if (shouldSpeak) await speak(reply);
      else setMode("idle");
    } finally {
      commandBusyRef.current = false;
      setCommandBusy(false);
    }
  }

  async function startMediaRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const recorder = new MediaRecorder(stream);
      recorderRef.current = recorder;
      chunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size) chunksRef.current.push(event.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
        setMode("thinking");
        try {
          const buffer = await blob.arrayBuffer();
          const response = await window.hayato.transcribeAudio({
            bytes: Array.from(new Uint8Array(buffer)),
            mimeType: blob.type,
          });
          if (response.needsKey) {
            setNotice("音声認識にはOpenAI APIキーが必要です。設定画面から登録してください。");
            setActiveView("settings");
            setMode("idle");
          } else if (response.localUnavailable) {
            setNotice("無料の音声認識を準備できません。設定画面でLOCAL SPEECHの状態を確認してください。");
            setActiveView("settings");
            setMode("idle");
          } else if (response.text) {
            setCommand(response.text);
            await runCommand(response.text);
          } else setMode("idle");
        } catch (error) {
          setNotice(String(error));
          setMode("idle");
        }
      };
      recorder.start();
      setMode("listening");
    } catch (error) {
      setNotice(`マイクを開始できません: ${String(error)}`);
      setMode("idle");
    }
  }

  function startBrowserRecognition() {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) {
      setActiveView("settings");
      setNotice("音声認識を使うにはOpenAI APIキーを登録してください。");
      return;
    }
    const recognition = new Recognition();
    recognitionRef.current = recognition;
    recognition.lang = "ja-JP";
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onresult = (event) => {
      const text = event.results[0][0].transcript;
      setCommand(text);
      void runCommand(text);
    };
    recognition.onerror = (event) => {
      setNotice(`音声認識を開始できません: ${event.error || "unknown"}`);
      setMode("idle");
    };
    recognition.onend = () => {
      recognitionRef.current = null;
      setMode((current) => (current === "listening" ? "idle" : current));
    };
    recognition.start();
    setMode("listening");
  }

  function toggleMicrophone() {
    if (mode === "listening") {
      recorderRef.current?.stop();
      recognitionRef.current?.stop();
      return;
    }
    if (mode === "speaking") cancelSpeech();
    if (localStatus.whisper || secretStatus.openai) void startMediaRecording();
    else startBrowserRecognition();
  }

  async function addProject() {
    const selected = await window.hayato.selectProject();
    if (!selected) return;
    try {
      const project = await window.hayato.scanProject(selected);
      commit((current) => {
        const projects = [...current.projects.filter((item) => item.path !== project.path), project];
        const oldProjectTasks = new Set(
          current.tasks.filter((task) => task.source === "project" && task.projectName === project.name).map((task) => task.id),
        );
        const tasks = [...current.tasks.filter((task) => !oldProjectTasks.has(task.id)), ...project.tasks];
        return { ...current, projects, tasks };
      });
      setNotice(`${project.name}を登録し、タスク${project.tasks.length}件を読み取りました。`);
    } catch (error) {
      setNotice(`プロジェクトを読み取れません: ${String(error)}`);
    }
  }

  async function rescanProject(projectPath: string) {
    try {
      const project = await window.hayato.scanProject(projectPath);
      commit((current) => ({
        ...current,
        projects: current.projects.map((item) => (item.path === projectPath ? project : item)),
        tasks: [
          ...current.tasks.filter(
            (task) => !(task.source === "project" && task.projectName === project.name),
          ),
          ...project.tasks,
        ],
      }));
      setNotice(`${project.name}を再読込しました。`);
    } catch (error) {
      setNotice(String(error));
    }
  }

  function removeProject(projectId: string) {
    commit((current) => {
      const project = current.projects.find((item) => item.id === projectId);
      return {
        ...current,
        projects: current.projects.filter((item) => item.id !== projectId),
        tasks: project
          ? current.tasks.filter(
              (task) => !(task.source === "project" && task.projectName === project.name),
            )
          : current.tasks,
      };
    });
  }

  async function importRevenue() {
    const selected = await window.hayato.importRevenueCsv();
    if (!selected) return;
    const entries = parseRevenueCsv(selected.content, selected.filename);
    if (!entries.length) {
      setNotice("CSVから売上を読み取れませんでした。日付・項目・金額の列を確認してください。");
      return;
    }
    commit((current) => ({ ...current, revenue: [...entries, ...current.revenue] }));
    setNotice(`${selected.filename}から${entries.length}件を読み込みました。`);
  }

  async function searchCameras(query = cameraQuery) {
    if (!query.trim()) return;
    setCameraSearching(true);
    setCameraResults([]);
    try {
      const response = await window.hayato.searchYouTubeLive(query.trim());
      if (response.needsKey) {
        setNotice("自動検索にはYouTube Data APIキーが必要です。設定画面から登録できます。");
      } else {
        setCameraResults(response.items);
        if (!response.items.length) setNotice("現在埋め込み可能なライブ配信が見つかりませんでした。");
      }
    } catch (error) {
      setNotice(String(error));
    } finally {
      setCameraSearching(false);
    }
  }

  function addCameraFromResult(result: YouTubeLiveResult) {
    const camera: CameraItem = {
      id: uid("camera"),
      name: result.title,
      location: cameraQuery.replace(/ライブカメラ/g, "").trim() || "登録地点",
      url: result.url,
      videoId: result.id,
      channelTitle: result.channelTitle,
    };
    commit((current) => ({
      ...current,
      cameras: [camera, ...current.cameras.filter((item) => item.videoId !== camera.videoId)],
    }));
    setNotice(`${camera.location}のライブカメラを登録しました。`);
  }

  if (!state) {
    return (
      <div className="loading-screen">
        <AssistantOrb mode="thinking" name="NORIKO" />
        <p>LOCAL OPERATIONS SYSTEM 起動中</p>
      </div>
    );
  }

  if (!state.preferences.onboardingCompleted) {
    return (
      <StarterOnboarding
        state={state}
        complete={async (settings) => {
          const folders = await window.hayato.initializeStarter();
          const next: AppState = {
            ...state,
            preferences: {
              ...state.preferences,
              ...settings,
              onboardingCompleted: true,
              obsidianKnowledgePath: folders.knowledgePath,
            },
          };
          await window.hayato.saveState(next);
          setState(next);
          setKnowledgeStatus(await window.hayato.getKnowledgeStatus());
          setChat([{
            id: uid("chat"),
            role: "assistant",
            text: `${settings.userName || "あなた"}、準備ができました。設定画面から使いたい連携だけ追加できます。`,
            createdAt: new Date().toISOString(),
          }]);
        }}
      />
    );
  }

  const navItems = navigationItems(state.preferences.revenueEnabled === true);

  const clockText = new Intl.DateTimeFormat("ja-JP", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).format(clock);
  const dateText = new Intl.DateTimeFormat("ja-JP", {
    timeZone: "Asia/Tokyo",
    month: "long",
    day: "numeric",
    weekday: "short",
  }).format(clock);

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-block">
          <span className="brand-emblem">N</span>
          <div><strong>AI NORIKO</strong><span>PERSONAL OPS</span></div>
        </div>
        <nav>
          {navItems.map((item) => (
            <button
              className={activeView === item.id ? "active" : ""}
              key={item.id}
              onClick={() => {
                setActiveView(item.id);
                document.querySelector<HTMLElement>(".view-scroll")?.scrollTo({ top: 0 });
                if (item.id === "week" && googleStatus.connected) void syncGoogleWeek(googleWeek?.startDate || today);
                if (item.id === "tasks" && googleStatus.connected) void syncGoogleTasks();
                if (item.id === "agents") void refreshAgentAvailability();
              }}
              type="button"
            >
              <span>{item.icon}</span>{item.label}
            </button>
          ))}
        </nav>
        <div className="connection-panel">
          <span className={localStatus.ollama && localStatus.model || secretStatus.openai ? "online" : ""}><i /> AI CORE</span>
          <span className={secretStatus.fish && secretStatus.fishVoice && state.preferences.fishVoiceEnabled ? "online" : ""}><i /> VOICE</span>
          <span className={googleStatus.connected ? "online" : ""}><i /> GOOGLE</span>
          <span className={knowledgeStatus.available ? "online" : ""}><i /> OBSIDIAN</span>
          <span className={agentAvailability.codex.loggedIn && agentAvailability.claude.loggedIn ? "online" : ""}><i /> AI WORK</span>
          <span className={secretStatus.youtube ? "online" : ""}><i /> LIVE DATA</span>
        </div>
        <div className="shortcut-hint"><kbd>{/Mac/i.test(navigator.userAgent) ? "⌘" : "Ctrl"}</kbd><kbd>⇧</kbd><kbd>Space</kbd><span>呼び出し</span></div>
      </aside>

      <main className="main-stage">
        <header className="topbar">
          <div className="page-title">
            <span>LOCAL / {activeView.toUpperCase()}</span>
            <strong>{navItems.find((item) => item.id === activeView)?.label}</strong>
          </div>
          <div className="topbar-status">
            <button
              aria-label={voiceOutputLevel(state.preferences) > 0 ? "AI NORIKOの音声をミュート" : "AI NORIKOのミュートを解除"}
              className={`voice-quick-toggle ${voiceOutputLevel(state.preferences) <= 0 ? "muted" : ""}`}
              onClick={() => commit((current) => {
                const currentlyMuted = voiceOutputLevel(current.preferences) <= 0;
                return {
                  ...current,
                  preferences: {
                    ...current.preferences,
                    voiceMuted: !currentlyMuted,
                    voiceVolume: currentlyMuted && Number(current.preferences.voiceVolume) <= 0
                      ? 0.8
                      : current.preferences.voiceVolume,
                  },
                };
              })}
              title={voiceOutputLevel(state.preferences) > 0 ? "クリックでミュート" : "クリックで音声を再開"}
              type="button"
            >
              <span>{voiceOutputLevel(state.preferences) > 0 ? "🔊" : "🔇"}</span>
              <small>{voiceOutputLevel(state.preferences) > 0 ? `${Math.round(voiceOutputLevel(state.preferences) * 100)}%` : "ミュート"}</small>
            </button>
            <span className="secure-status"><i /> LOCAL SECURE</span>
            <div className="clock"><strong>{clockText}</strong><span>{dateText}</span></div>
          </div>
        </header>

        {googleStatus.reauthRequired ? (
          <div className="google-reauth-banner" role="alert"><span>Googleの認証が切れています。予定・タスクは未確認です。再接続してください。</span><button className="secondary-button" onClick={() => void connectGoogle()} type="button">Googleを再接続</button></div>
        ) : null}
        <div className="view-scroll">
          {activeView === "dashboard" ? (
            <Dashboard
              state={state}
              mode={mode}
              todayTasks={todayTasks}
              todaySales={todaySales}
              chat={chat}
              command={command}
              setCommand={setCommand}
              commandRef={commandRef}
              runCommand={runCommand}
              consultationMode={consultationMode}
              setConsultationMode={setConsultationMode}
              commandBusy={commandBusy}
              newConsultation={() => { setChat([]); setConsultationMode(true); setCommand(""); }}
              toggleMicrophone={toggleMicrophone}
              commit={commit}
              setActiveView={setActiveView}
              googleStatus={googleStatus}
              googleSchedule={googleTodaySchedule?.date === today ? googleTodaySchedule : null}
              googleSyncing={googleSyncing}
              syncGoogle={syncGoogleSchedule}
              completeGoogleTask={completeTask}
              researchResult={researchResult}
            />
          ) : null}

          {activeView === "schedule" ? (
            <ScheduleView
              status={googleStatus}
              schedule={googleSchedule}
              selectedDate={selectedGoogleDateRef.current}
              syncing={googleSyncing}
              connect={connectGoogle}
              sync={syncGoogleSchedule}
              disconnect={disconnectGoogle}
              openSettings={() => setActiveView("settings")}
            />
          ) : null}

          {activeView === "week" ? (
            <WeekView
              status={googleStatus}
              schedule={googleWeek}
              syncing={googleWeekSyncing}
              sync={syncGoogleWeek}
              completeTask={completeTask}
              openSettings={() => setActiveView("settings")}
            />
          ) : null}

          {activeView === "tasks" ? (
            <TasksView
              state={state}
              commit={commit}
              googleStatus={googleStatus}
              googleTasks={googleTasks}
              syncing={googleTasksSyncing}
              syncGoogleTasks={syncGoogleTasks}
              createGoogleTask={createTask}
              completeGoogleTask={completeTask}
              openSettings={() => setActiveView("settings")}
              addProject={addProject}
              rescanProject={rescanProject}
              removeProject={removeProject}
            />
          ) : null}

          {activeView === "revenue" && state.preferences.revenueEnabled ? (
            <RevenueView state={state} commit={commit} importRevenue={importRevenue} />
          ) : null}

          {activeView === "cameras" ? (
            <CamerasView
              state={state}
              commit={commit}
              query={cameraQuery}
              setQuery={setCameraQuery}
              results={cameraResults}
              searching={cameraSearching}
              search={searchCameras}
              addResult={addCameraFromResult}
            />
          ) : null}

          {activeView === "agents" ? (
            <AgentWorkView
              availability={agentAvailability}
              jobs={agentJobs}
              startJob={async (request) => queueAction("job", request)}
              openTerminal={(job) => queueAction("terminal", { provider: job.provider, mode: job.mode, title: job.title, prompt: `「${job.title}」の続きを行います。`, projectPath: job.projectPath, conversation: recentConversation() })}
              cancelJob={async (jobId) => {
                const job = await window.hayato.cancelAgentJob(jobId);
                setAgentJobs((jobs) => [job, ...jobs.filter((item) => item.id !== job.id)]);
              }}
              refreshAvailability={refreshAgentAvailability}
              setNotice={setNotice}
            />
          ) : null}

          {activeView === "settings" ? (
            <SettingsView
              state={state}
              commit={commit}
              status={secretStatus}
              setStatus={setSecretStatus}
              setNotice={setNotice}
              googleStatus={googleStatus}
              setGoogleStatus={setGoogleStatus}
              connectGoogle={connectGoogle}
              localStatus={localStatus}
              refreshLocalStatus={async () => setLocalStatus(await window.hayato.getLocalStatus())}
              knowledgeStatus={knowledgeStatus}
              setKnowledgeStatus={setKnowledgeStatus}
              playFishVoiceTest={playFishVoiceTest}
            />
          ) : null}
        </div>
      </main>

      {pendingAction ? (
        <div className="confirmation-backdrop"><section className="confirmation-dialog panel" role="dialog" aria-modal="true" aria-labelledby="agent-confirm-title">
          <h2 id="agent-confirm-title">AIへの引き継ぎを確認</h2>
          <p>まだ起動・実行していません。下記の内容・会話と、ナレッジ検索で見つかる関連ノート最大5件を依頼Markdownに保存し、選んだAIへ渡します。契約の利用枠を消費し、制作・実装では作業フォルダ内のファイルが変更される場合があります。</p>
          <label>実行先<select autoFocus disabled={confirmationBusy} value={pendingAction.request.provider} onChange={(event) => setPendingAction({ ...pendingAction, request: { ...pendingAction.request, provider: event.target.value as AgentProvider } })}><option value="codex">Codex</option><option value="claude">Claude Code</option></select></label>
          <p>操作：{pendingAction.kind === "terminal" ? "ターミナルを開き、会話をファイルで引き継ぐ" : pendingAction.request.mode === "implement" ? "制作・実装を開始" : "壁打ち作業を開始"}</p>
          <p className="confirmation-path">作業先：{pendingAction.request.projectPath || `${agentAvailability.defaultWorkspacePath || "Documents/AI-NORIKO-Workspaces"} 内に新規作成`}</p>
          <label>依頼内容<textarea disabled={confirmationBusy} rows={4} value={pendingAction.request.prompt} onChange={(event) => setPendingAction({ ...pendingAction, request: { ...pendingAction.request, prompt: event.target.value } })} /></label>
          <label>引き継ぐ会話（不要な個人情報は削除できます）<textarea disabled={confirmationBusy} rows={7} value={pendingAction.request.conversation || ""} onChange={(event) => setPendingAction({ ...pendingAction, request: { ...pendingAction.request, conversation: event.target.value } })} /></label>
          {confirmationError ? <p role="alert" className="agent-form-error">{confirmationError}</p> : null}
          <div className="confirmation-actions"><button className="secondary-button" disabled={confirmationBusy} onClick={() => setPendingAction(null)} type="button">キャンセル</button><button className="primary-button" disabled={confirmationBusy || !pendingAction.request.prompt.trim()} onClick={() => void confirmAction()} type="button">{confirmationBusy ? "実行中…" : "内容を確認して開始"}</button></div>
        </section></div>
      ) : null}
      {pendingNote ? (
        <div className="confirmation-backdrop"><section className="confirmation-dialog panel" role="dialog" aria-modal="true" aria-labelledby="note-confirm-title">
          <h2 id="note-confirm-title">Obsidianへの記録を確認</h2>
          <p className="confirmation-path">保存先：{knowledgeStatus.path || state.preferences.obsidianKnowledgePath || "未設定（設定画面でフォルダを選んでください）"}</p>
          <p>既存ノートは上書きせず、新しいMarkdownを作ります。AIの提案は本人の確定方針として保存しません。</p>
          <label>タイトル<input autoFocus disabled={confirmationBusy} value={pendingNote.title} onChange={(event) => setPendingNote({ ...pendingNote, title: event.target.value })} /></label>
          <label>本人の発言・事実<textarea disabled={confirmationBusy} rows={6} value={pendingNote.userText} onChange={(event) => setPendingNote({ ...pendingNote, userText: event.target.value })} /></label>
          <label>AIの回答・提案（未承認）<textarea disabled={confirmationBusy} rows={6} value={pendingNote.assistantText} onChange={(event) => setPendingNote({ ...pendingNote, assistantText: event.target.value })} /></label>
          {confirmationError ? <p role="alert" className="agent-form-error">{confirmationError}</p> : null}
          <div className="confirmation-actions"><button className="secondary-button" disabled={confirmationBusy} onClick={() => setPendingNote(null)} type="button">キャンセル</button><button className="primary-button" disabled={confirmationBusy || !pendingNote.userText.trim()} onClick={() => void confirmKnowledgeNote()} type="button">{confirmationBusy ? "保存中…" : "内容を確認して保存"}</button></div>
        </section></div>
      ) : null}
      {notice ? <div className="toast">{notice}</div> : null}
    </div>
  );
}

function Dashboard({
  state,
  mode,
  todayTasks,
  todaySales,
  chat,
  command,
  setCommand,
  commandRef,
  runCommand,
  consultationMode,
  setConsultationMode,
  commandBusy,
  newConsultation,
  toggleMicrophone,
  commit,
  setActiveView,
  googleStatus,
  googleSchedule,
  googleSyncing,
  syncGoogle,
  completeGoogleTask,
  researchResult,
}: {
  state: AppState;
  mode: AssistantMode;
  todayTasks: TaskItem[];
  todaySales: number;
  chat: ChatEntry[];
  command: string;
  setCommand: (value: string) => void;
  commandRef: React.RefObject<HTMLInputElement | null>;
  runCommand: (value: string) => Promise<void>;
  consultationMode: boolean;
  setConsultationMode: (value: boolean) => void;
  commandBusy: boolean;
  newConsultation: () => void;
  toggleMicrophone: () => void;
  commit: (updater: (current: AppState) => AppState) => void;
  setActiveView: (view: ViewName) => void;
  googleStatus: GoogleAccountStatus;
  googleSchedule: GoogleTodaySchedule | null;
  googleSyncing: boolean;
  syncGoogle: () => Promise<GoogleTodaySchedule | null>;
  completeGoogleTask: (task: GoogleTaskItem) => Promise<void>;
  researchResult: ResearchResult | null;
}) {
  const recentChat = chat.slice(-4);
  const dueGoogleTasks = googleSchedule?.tasks || [];
  const followUpTasks = dueGoogleTasks.filter((task) => /顧客|お客様|フォロー|連絡|返信|架電|電話/.test(`${task.listTitle}${task.title}`));
  const showingLatestNews = Boolean(
    researchResult?.sources.length
    && researchResult.sources.every((source) => source.kind === "news"),
  );
  return (
    <div className="dashboard-grid">
      <section className="command-center panel">
        <div className="panel-caption"><span>VOICE COMMAND</span><i /></div>
        <HayatoCharacter mode={mode} name={state.preferences.assistantName} />
        <p className="command-prompt">
          {mode === "listening"
            ? "お話しください"
            : mode === "thinking"
              ? "情報を分析しています"
              : mode === "speaking"
                ? "お答えしています"
                : "何を確認しますか？"}
        </p>
        <div className="conversation-controls">
          <div className="segmented" role="group" aria-label="会話モード">
            <button className={consultationMode ? "active" : ""} onClick={() => setConsultationMode(true)} type="button">相談モード</button>
            <button className={!consultationMode ? "active" : ""} onClick={() => setConsultationMode(false)} type="button">操作モード</button>
          </div>
          <button className="text-button" disabled={commandBusy} onClick={newConsultation} type="button">新しい相談</button>
        </div>
        <p className="conversation-hint">{consultationMode ? "相談を続けます。予定確認などの操作は「操作モード」へ。直近12メッセージを参照します（終了時に履歴は消えます）。" : "予定の確認や各機能の操作ができます。「相談です」で継続相談へ切り替わります。"}</p>
        <form
          className="command-input"
          onSubmit={(event) => {
            event.preventDefault();
            void runCommand(command);
          }}
        >
          <input
            ref={commandRef}
            value={command}
            onChange={(event) => setCommand(event.target.value)}
            placeholder={consultationMode ? "例：その場合、予算は5万円です" : "例：相談です。明日の勉強会の準備を整理したいです"}
            aria-label="NORIKOへのメッセージ"
          />
          <button className={`mic-button ${mode === "listening" ? "is-live" : ""}`} type="button" onClick={toggleMicrophone}>
            {mode === "listening" ? "■" : "●"}
          </button>
          <button className="send-button" disabled={commandBusy} type="submit">{commandBusy ? "応答中…" : "送信"}</button>
        </form>
        <div className="quick-commands">
          {["今日の状況を報告して", "今週のスケジュールを見せて", "顧客フォローを教えて"].map((item) => (
            <button key={item} disabled={commandBusy || consultationMode} onClick={() => void runCommand(item)} type="button">{item}</button>
          ))}
        </div>
      </section>

      <section className="metrics-grid">
        <MetricCard
          label="TODAY'S TASKS"
          value={`${googleStatus.connected ? googleSchedule ? dueGoogleTasks.length : "—" : todayTasks.length}`}
          detail={googleStatus.connected ? googleSchedule ? `Google Tasks · 期限超過 ${dueGoogleTasks.filter((task) => task.overdue).length}件` : "Google Tasksは未確認" : `端末内 未完了${state.tasks.filter((task) => !task.completed).length}件`}
          onClick={() => setActiveView("tasks")}
        />
        <MetricCard
          label={state.preferences.revenueEnabled ? "TODAY'S REVENUE" : "LIVE CAMERAS"}
          value={state.preferences.revenueEnabled ? formatCurrency(todaySales) : `${state.cameras.length}`}
          detail={state.preferences.revenueEnabled ? `明細 ${state.revenue.filter((entry) => entry.date === japanToday()).length}件` : "登録済みの公開ライブ地点"}
          accent="gold"
          onClick={() => setActiveView(state.preferences.revenueEnabled ? "revenue" : "cameras")}
        />
        <MetricCard
          label="GOOGLE SCHEDULE"
          value={googleStatus.connected ? `${googleSchedule?.events.length ?? "—"}` : "—"}
          detail={googleStatus.connected ? `${googleSchedule ? scheduleDateLabel(googleSchedule.date) : "未確認"} · Tasks ${googleSchedule?.tasks.length ?? "—"}件` : "Google未接続"}
          accent="violet"
          onClick={() => setActiveView("schedule")}
        />
      </section>

      <section className="tasks-panel panel">
        <div className="section-heading">
          <div><span>PRIORITY QUEUE</span><h2>本日のタスク</h2></div>
          <button className="text-button" onClick={() => setActiveView("tasks")} type="button">すべて表示 →</button>
        </div>
        <div className="task-list compact">
          {googleStatus.connected
            ? dueGoogleTasks.slice(0, 4).map((task) => (
                <GoogleTaskRow key={`${task.taskListId}-${task.id}`} task={task} compact onComplete={() => void completeGoogleTask(task)} />
              ))
            : todayTasks.slice(0, 4).map((task) => (
                <TaskRow
                  key={task.id}
                  task={task}
                  onToggle={() => commit((current) => ({
                    ...current,
                    tasks: current.tasks.map((item) => item.id === task.id ? { ...item, completed: !item.completed } : item),
                  }))}
                />
              ))}
          {googleStatus.connected && !dueGoogleTasks.length ? <div className="empty-state">{googleSchedule ? "本日までのGoogle Tasksはありません。" : "Google Tasksは未確認です。"}</div> : null}
          {!googleStatus.connected && !todayTasks.length ? <div className="empty-state">本日対応するタスクはありません。</div> : null}
        </div>
      </section>

      <section className="schedule-preview panel">
        <div className="section-heading">
          <div><span>GOOGLE DAY PLAN</span><h2>{googleSchedule ? `${scheduleDateLabel(googleSchedule.date)}のスケジュール` : "スケジュール"}</h2></div>
          <div className="heading-actions">
            {googleStatus.connected ? <button className="text-button" disabled={googleSyncing} onClick={() => void syncGoogle()} type="button">{googleSyncing ? "同期中…" : "更新"}</button> : null}
            <button className="text-button" onClick={() => setActiveView("schedule")} type="button">詳細 →</button>
          </div>
        </div>
        {googleStatus.connected ? (
          <div className="schedule-preview-grid">
            {googleSchedule?.events.slice(0, 4).map((event) => (
              <article className="mini-event" key={event.id}>
                <span>{eventTimeLabel(event)}</span>
                <strong>{event.title}</strong>
                <small>{event.location || (event.meetUrl ? "オンライン" : event.calendarName || "Google Calendar")}</small>
              </article>
            ))}
            {googleSchedule && !googleSchedule.events.length ? <div className="empty-state small">{scheduleDateLabel(googleSchedule.date)}のカレンダー予定はありません。</div> : null}
            {!googleSchedule ? <div className="empty-state small">{googleSyncing ? "Googleカレンダーを同期しています。" : "予定は未確認です。更新して再取得してください。"}</div> : null}
          </div>
        ) : (
          <button className="google-connect-prompt" onClick={() => setActiveView("schedule")} type="button">
            <span>G</span><div><strong>Googleアカウントを接続</strong><small>今日のカレンダーとGoogle Tasksを表示します</small></div>
          </button>
        )}
      </section>

      <section className="follow-up-panel panel">
        <div className="section-heading">
          <div><span>CUSTOMER FOLLOW-UP</span><h2>顧客フォローのリマインド</h2></div>
          <button className="text-button" onClick={() => setActiveView("tasks")} type="button">タスクへ →</button>
        </div>
        <div className="task-list follow-up-list">
          {followUpTasks.slice(0, 5).map((task) => (
            <GoogleTaskRow key={`${task.taskListId}-${task.id}`} task={task} compact onComplete={() => void completeGoogleTask(task).catch(() => undefined)} />
          ))}
          {!followUpTasks.length ? <div className="empty-state small">{googleSchedule ? "本日までの顧客フォローはありません。" : "Googleの顧客フォローは未確認です。"}</div> : null}
        </div>
      </section>

      <section className="camera-preview panel">
        <div className="section-heading">
          <div><span>LIVE INTELLIGENCE</span><h2>ライブモニター</h2></div>
          <button className="text-button" onClick={() => setActiveView("cameras")} type="button">地点を管理 →</button>
        </div>
        <div className="camera-grid preview-grid">
          {state.cameras.slice(0, 2).map((camera) => (
            <CameraPlayer
              camera={camera}
              key={camera.id}
              onOpen={() => void window.hayato.openExternal(camera.url)}
            />
          ))}
          {state.cameras.length === 0 ? <EmptyCamera onSearch={() => setActiveView("cameras")} /> : null}
        </div>
      </section>

      <section className="briefing-panel panel">
        <div className="section-heading"><div><span>ACTIVITY LOG</span><h2>会話ログ</h2></div></div>
        <div className="chat-log">
          {recentChat.map((entry) => (
            <div className={`chat-line ${entry.role}`} key={entry.id}>
              <span>{entry.role === "assistant" ? state.preferences.assistantName : state.preferences.userName}</span>
              <p>{entry.text}</p>
              {entry.sources?.length ? (
                <small className="chat-sources">OBSIDIAN · {entry.sources.slice(0, 3).join(" · ")}</small>
              ) : null}
            </div>
          ))}
        </div>
      </section>

      {researchResult ? (
        <section className={`research-panel panel ${showingLatestNews ? "latest-news-panel" : ""}`}>
          <div className="section-heading">
            <div>
              <span>{showingLatestNews ? "LIVE NEWS FEED" : "FREE LOCAL RESEARCH"}</span>
              <h2>{showingLatestNews ? "最新ニュース" : "調査レポート"}</h2>
            </div>
            <div className="research-heading-actions">
              <small>{new Date(researchResult.searchedAt).toLocaleString("ja-JP")}</small>
              <button
                className="text-button"
                onClick={() => document.querySelector<HTMLElement>(".view-scroll")?.scrollTo({ top: 0, behavior: "smooth" })}
                type="button"
              >↑ 画面上部へ</button>
            </div>
          </div>
          <h3>{researchResult.query}</h3>
          <p className="research-summary">{researchResult.summary}</p>
          <div className="research-sources">
            {researchResult.sources.map((source, index) => (
              <button
                className={source.kind === "news" ? "news-source" : ""}
                key={`${source.url}-${index}`}
                onClick={() => void window.hayato.openInChrome(source.url)}
                type="button"
              >
                <span>
                  [{index + 1}] {source.kind === "news" ? `NEWS${source.sourceName ? ` · ${source.sourceName}` : ""}` : source.kind === "reference" ? "REFERENCE" : "WEB"}
                </span>
                <strong>{source.title}</strong>
                {source.snippet ? <small>{source.snippet}</small> : null}
                {source.publishedAt ? <time>{new Date(source.publishedAt).toLocaleString("ja-JP")}</time> : null}
              </button>
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

function ScheduleView({
  status,
  schedule,
  selectedDate,
  syncing,
  connect,
  sync,
  disconnect,
  openSettings,
}: {
  status: GoogleAccountStatus;
  schedule: GoogleTodaySchedule | null;
  selectedDate: string;
  syncing: boolean;
  connect: () => Promise<void>;
  sync: (date?: string) => Promise<GoogleTodaySchedule | null>;
  disconnect: () => Promise<void>;
  openSettings: () => void;
}) {
  if (!status.configured) {
    return (
      <section className="panel google-onboarding">
        <span className="google-mark">G</span>
        <div className="section-heading"><div><span>GOOGLE CONNECTION</span><h1>Googleアカウントを連携</h1></div></div>
        <p>GoogleカレンダーとGoogle Tasksを連携し、予定確認・タスク登録・完了・朝の報告をNORIKOへ統合します。</p>
        <div className="permission-chips"><span>カレンダー：読取のみ</span><span>Google Tasks：登録・完了</span><span>Gmail本文：アクセスなし</span></div>
        <button className="primary-button" onClick={openSettings} type="button">設定手順へ進む</button>
      </section>
    );
  }

  if (!status.connected) {
    return (
      <section className="panel google-onboarding">
        <span className="google-mark">G</span>
        <div className="section-heading"><div><span>READY TO AUTHORIZE</span><h1>Googleでログイン</h1></div></div>
        <p>ブラウザでGoogleの認証画面が開きます。予定を管理しているGmailアカウントを選択してください。</p>
        <div className="permission-chips"><span>Calendar読取・Tasks登録/完了</span><span>パスワード保存なし</span><span>いつでも解除可能</span></div>
        <button className="google-button" onClick={() => void connect()} type="button"><b>G</b> Googleアカウントで接続</button>
      </section>
    );
  }

  const overdueCount = schedule?.tasks.filter((task) => task.overdue).length || 0;
  const selectedDateLabel = scheduleDateLabel(selectedDate);
  return (
    <div className="schedule-layout">
      <section className="panel schedule-header-panel">
        <div>
          <span className="eyebrow">GOOGLE DAY PLAN</span>
          <h1>{selectedDateLabel}のスケジュール</h1>
          <p>{status.email} · {schedule ? `${new Date(schedule.syncedAt).toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })} 同期` : syncing ? "同期中" : "未確認"}</p>
        </div>
        <div className="heading-actions">
          <button className="text-button" disabled={syncing} onClick={() => void sync(shiftJapanDate(selectedDate, -1))} type="button">← 前日</button>
          <button className="text-button" disabled={syncing} onClick={() => void sync(japanToday())} type="button">今日</button>
          <button className="text-button" disabled={syncing} onClick={() => void sync(shiftJapanDate(selectedDate, 1))} type="button">翌日 →</button>
          <button className="secondary-button" disabled={syncing} onClick={() => void sync(selectedDate)} type="button">{syncing ? "同期中…" : "再同期"}</button>
          {!status.tasksWritable ? <button className="google-button compact" onClick={() => void connect()} type="button"><b>G</b> Tasks権限を更新</button> : null}
          <button className="text-button danger-text" onClick={() => void disconnect()} type="button">連携解除</button>
        </div>
      </section>

      <section className="metrics-grid schedule-metrics">
        <MetricCard label="CALENDAR" value={`${schedule?.events.length ?? "—"}`} detail={`${selectedDateLabel}の予定`} />
        <MetricCard label="GOOGLE TASKS" value={`${schedule?.tasks.length ?? "—"}`} detail={`${selectedDateLabel}までの期限分`} accent="violet" />
        <MetricCard label="OVERDUE" value={`${schedule ? overdueCount : "—"}`} detail="期限超過タスク" accent="gold" />
      </section>

      <section className="panel day-timeline-panel">
        <div className="section-heading"><div><span>CALENDAR TIMELINE</span><h2>Googleカレンダー</h2></div></div>
        <div className="day-timeline">
          {schedule?.events.map((event) => (
            <article className="timeline-event" key={event.id}>
              <div className="timeline-time"><strong>{eventTimeLabel(event)}</strong><i /></div>
              <div className="timeline-card">
                <strong>{event.title}</strong>
                <span>{event.location || (event.meetUrl ? "オンライン会議" : event.calendarName || "Google Calendar")}</span>
                <div className="event-actions">
                  {event.meetUrl ? <button className="secondary-button" onClick={() => void window.hayato.openExternal(event.meetUrl!)} type="button">会議に参加</button> : null}
                  {event.url ? <button className="text-button" onClick={() => void window.hayato.openExternal(event.url!)} type="button">カレンダーで開く</button> : null}
                </div>
              </div>
            </article>
          ))}
          {schedule && !schedule.events.length ? <div className="empty-state">{selectedDateLabel}のカレンダー予定はありません。</div> : null}
          {!schedule ? <div className="empty-state">{syncing ? "Googleから予定を同期しています。" : "予定は未確認です。再同期を押してください。"}</div> : null}
        </div>
      </section>

      <section className="panel google-tasks-panel">
        <div className="section-heading"><div><span>DUE TASKS</span><h2>Google Tasks</h2></div></div>
        <div className="google-task-list">
          {schedule?.tasks.map((task) => (
            <article className={task.overdue ? "overdue" : ""} key={`${task.listTitle}-${task.id}`}>
              <span className="google-task-dot" />
              <div><strong>{task.title}</strong><span>{task.listTitle} · {task.overdue ? `期限超過 ${formatShortDate(task.due)}` : `期限 ${formatShortDate(task.due)}`}</span>{task.notes ? <small>{task.notes}</small> : null}</div>
              {task.url ? <button className="text-button" onClick={() => void window.hayato.openExternal(task.url!)} type="button">開く</button> : null}
            </article>
          ))}
          {schedule && !schedule.tasks.length ? <div className="empty-state">{selectedDateLabel}までに期限を迎えるGoogle Tasksはありません。</div> : null}
          {!schedule ? <div className="empty-state">{syncing ? "Google Tasksを同期しています。" : "Google Tasksは未確認です。再同期を押してください。"}</div> : null}
        </div>
      </section>
    </div>
  );
}

function WeekView({
  status,
  schedule,
  syncing,
  sync,
  completeTask,
  openSettings,
}: {
  status: GoogleAccountStatus;
  schedule: GoogleWeekSchedule | null;
  syncing: boolean;
  sync: (date?: string) => Promise<GoogleWeekSchedule | null>;
  completeTask: (task: GoogleTaskItem) => Promise<void>;
  openSettings: () => void;
}) {
  if (!status.connected) {
    return (
      <section className="panel google-onboarding">
        <span className="google-mark">G</span>
        <div className="section-heading"><div><span>WEEKLY CONTROL</span><h1>今週のスケジュール</h1></div></div>
        <p>GoogleカレンダーとGoogle Tasksを接続すると、1週間の予定・期限タスク・顧客フォローをまとめて表示します。</p>
        <button className="primary-button" onClick={openSettings} type="button">Google設定を開く</button>
      </section>
    );
  }

  const startDate = schedule?.startDate || japanWeekStart(japanToday());
  const endDate = schedule?.endDate || shiftJapanDate(startDate, 6);
  const days = Array.from({ length: 7 }, (_, index) => shiftJapanDate(startDate, index));
  const overdueTasks = schedule?.tasks.filter((task) => task.due && task.due < startDate) || [];
  const currentWeekTasks = schedule?.tasks.filter((task) => task.due && task.due >= startDate && task.due <= endDate) || [];

  return (
    <div className="week-layout">
      <section className="panel schedule-header-panel">
        <div>
          <span className="eyebrow">WEEKLY OPERATIONS</span>
          <h1>{formatShortDate(startDate)}〜{formatShortDate(endDate)}のスケジュール</h1>
          <p>{status.email} · {schedule ? `${new Date(schedule.syncedAt).toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })} 同期` : "同期準備中"}</p>
        </div>
        <div className="heading-actions">
          {!status.tasksWritable ? <button className="google-button compact" onClick={openSettings} type="button"><b>G</b> Tasks権限を更新</button> : null}
          <button className="text-button" disabled={syncing} onClick={() => void sync(shiftJapanDate(startDate, -7))} type="button">← 前週</button>
          <button className="text-button" disabled={syncing} onClick={() => void sync(japanToday())} type="button">今週</button>
          <button className="text-button" disabled={syncing} onClick={() => void sync(shiftJapanDate(startDate, 7))} type="button">翌週 →</button>
          <button className="secondary-button" disabled={syncing} onClick={() => void sync(startDate)} type="button">{syncing ? "同期中…" : "再同期"}</button>
        </div>
      </section>

      <section className="metrics-grid week-metrics">
        <MetricCard label="WEEK EVENTS" value={`${schedule?.events.length ?? "—"}`} detail="Googleカレンダー予定" />
        <MetricCard label="DUE TASKS" value={`${schedule ? currentWeekTasks.length : "—"}`} detail="今週期限のGoogle Tasks" accent="violet" />
        <MetricCard label="OVERDUE" value={`${schedule ? overdueTasks.length : "—"}`} detail="期限超過・要確認" accent="gold" />
      </section>

      {overdueTasks.length ? (
        <section className="panel overdue-strip">
          <div><span>期限超過</span><strong>{overdueTasks.length}件のタスクを確認してください</strong></div>
          <div className="overdue-strip-items">
            {overdueTasks.slice(0, 5).map((task) => (
              <button disabled={!status.tasksWritable} key={`${task.taskListId}-${task.id}`} onClick={() => void completeTask(task).catch(() => undefined)} type="button">
                {task.title} · {formatShortDate(task.due)}
              </button>
            ))}
          </div>
        </section>
      ) : null}

      <section className="week-board">
        {days.map((date) => {
          const events = schedule?.events.filter((event) => event.start.slice(0, 10) === date) || [];
          const tasks = currentWeekTasks.filter((task) => task.due === date);
          const isToday = date === japanToday();
          return (
            <article className={`week-day panel ${isToday ? "is-today" : ""}`} key={date}>
              <header><span>{new Intl.DateTimeFormat("ja-JP", { weekday: "short", timeZone: "Asia/Tokyo" }).format(new Date(`${date}T12:00:00+09:00`))}</span><strong>{Number(date.slice(8, 10))}</strong><small>{Number(date.slice(5, 7))}月</small></header>
              <div className="week-day-items">
                {events.map((event) => (
                  <button className="week-item event" key={`${event.id}-${event.start}`} onClick={() => event.url && void window.hayato.openExternal(event.url)} type="button">
                    <span>{eventTimeLabel(event)}</span><strong>{event.title}</strong><small>{event.calendarName || "Google Calendar"}</small>
                  </button>
                ))}
                {tasks.map((task) => (
                  <div className="week-item task" key={`${task.taskListId}-${task.id}`}>
                    <span>TASK · {task.listTitle}</span><strong>{task.title}</strong>
                    <button disabled={!status.tasksWritable} onClick={() => void completeTask(task).catch(() => undefined)} type="button">{status.tasksWritable ? "完了" : "権限更新"}</button>
                  </div>
                ))}
                {!events.length && !tasks.length ? <div className="week-empty">{schedule ? "予定なし" : syncing ? "取得中" : "未確認"}</div> : null}
              </div>
            </article>
          );
        })}
      </section>
    </div>
  );
}

function TasksView({
  state,
  commit,
  googleStatus,
  googleTasks,
  syncing,
  syncGoogleTasks,
  createGoogleTask,
  completeGoogleTask,
  openSettings,
  addProject,
  rescanProject,
  removeProject,
}: {
  state: AppState;
  commit: (updater: (current: AppState) => AppState) => void;
  googleStatus: GoogleAccountStatus;
  googleTasks: GoogleTaskCollection | null;
  syncing: boolean;
  syncGoogleTasks: () => Promise<GoogleTaskCollection | null>;
  createGoogleTask: (request: GoogleTaskCreateRequest) => Promise<GoogleTaskItem>;
  completeGoogleTask: (task: GoogleTaskItem) => Promise<void>;
  openSettings: () => void;
  addProject: () => Promise<void>;
  rescanProject: (path: string) => Promise<void>;
  removeProject: (id: string) => void;
}) {
  const [localTitle, setLocalTitle] = useState("");
  const [localDueDate, setLocalDueDate] = useState("");
  const [title, setTitle] = useState("");
  const [dueDate, setDueDate] = useState(japanToday());
  const [taskKind, setTaskKind] = useState<"normal" | "followup">("normal");
  const [filter, setFilter] = useState<"all" | "today" | "week" | "followup">("all");
  const [submitting, setSubmitting] = useState(false);
  const [formMessage, setFormMessage] = useState("");
  const weekEnd = shiftJapanDate(japanWeekStart(japanToday()), 6);
  const visibleGoogleTasks = (googleTasks?.tasks || []).filter((task) => {
    if (filter === "today") return Boolean(task.due && task.due <= japanToday());
    if (filter === "week") return Boolean(task.due && task.due >= japanToday() && task.due <= weekEnd);
    if (filter === "followup") return /顧客|お客様|フォロー|連絡|返信|架電|電話/.test(`${task.listTitle}${task.title}`);
    return true;
  });
  const localTasks = state.tasks;

  function addLocalTask(event: FormEvent) {
    event.preventDefault();
    if (!localTitle.trim()) return;
    const task: TaskItem = {
      id: uid("task"), title: localTitle.trim(), completed: false, priority: "medium",
      source: "manual", ...(localDueDate ? { dueDate: localDueDate } : {}),
    };
    commit((current) => ({ ...current, tasks: [...current.tasks, task] }));
    setLocalTitle("");
    setFormMessage(`「${task.title}」を端末内の手動タスクに追加しました。Googleには送信しません。`);
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!title.trim() || !googleStatus.connected || !googleStatus.tasksWritable) return;
    setSubmitting(true);
    setFormMessage("");
    try {
      const created = await createGoogleTask({
        title: title.trim(),
        due: dueDate,
        listTitle: taskKind === "followup" ? "顧客フォロー" : undefined,
        notes: "AI NORIKOから登録",
      });
      setTitle("");
      setFormMessage(`「${created.title}」をGoogle Tasksへ登録しました。`);
    } catch (error) {
      setFormMessage(String(error));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="content-layout">
      <section className="panel wide-panel">
        <div className="section-heading"><div><span>LOCAL TASKS</span><h1>手動タスク（Googleなしで使えます）</h1></div></div>
        <form className="inline-form task-form local-task-form" onSubmit={addLocalTask}>
          <input aria-label="手動タスク名" value={localTitle} onChange={(event) => setLocalTitle(event.target.value)} placeholder="例：練習：説明書を読む" required maxLength={300} />
          <input aria-label="手動タスクの期限（任意）" type="date" value={localDueDate} onChange={(event) => setLocalDueDate(event.target.value)} />
          <button className="primary-button" type="submit">端末内に追加</button>
        </form>
        <div className="task-list full-list local-manual-tasks">
          {localTasks.filter((task) => task.source === "manual").map((task) => (
            <TaskRow task={task} key={task.id} onToggle={() => commit((current) => ({ ...current, tasks: current.tasks.map((item) => item.id === task.id ? { ...item, completed: !item.completed } : item) }))} />
          ))}
          {!localTasks.some((task) => task.source === "manual") ? <p className="support-copy">まず練習タスクを1件追加し、左の丸を押して完了にしてください。</p> : null}
        </div>
        <div className="section-heading">
          <div><span>GOOGLE TASK CONTROL · OPTIONAL</span><h2>Googleタスク・顧客フォロー</h2></div>
          <div className="segmented">
            {(["all", "today", "week", "followup"] as const).map((item) => (
              <button className={filter === item ? "active" : ""} onClick={() => setFilter(item)} key={item} type="button">
                {item === "all" ? "すべて" : item === "today" ? "今日まで" : item === "week" ? "今週" : "顧客フォロー"}
              </button>
            ))}
          </div>
        </div>
        {!googleStatus.connected ? (
          <div className="task-permission-card"><p>上の手動タスクはGoogleなしで利用できます。Google Tasksも使う場合だけ、本人のアカウントを接続してください。</p><button className="primary-button" onClick={openSettings} type="button">Google設定を開く</button></div>
        ) : !googleStatus.tasksWritable ? (
          <div className="task-permission-card warning"><p>既存の連携は閲覧専用です。書き込み権限を一度だけ追加してください。</p><button className="google-button compact" onClick={openSettings} type="button"><b>G</b> Google権限を更新</button></div>
        ) : (
          <form className="inline-form task-form google-task-form" onSubmit={submit}>
            <input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="新しいタスク、または顧客名とフォロー内容" />
            <input type="date" value={dueDate} onChange={(event) => setDueDate(event.target.value)} />
            <select value={taskKind} onChange={(event) => setTaskKind(event.target.value as "normal" | "followup")}>
              <option value="normal">通常タスク</option><option value="followup">顧客フォロー</option>
            </select>
            <button className="primary-button" disabled={submitting} type="submit">{submitting ? "登録中…" : "Googleへ追加"}</button>
          </form>
        )}
        {formMessage ? <p className="form-message">{formMessage}</p> : null}
        <div className="task-toolbar"><span>{googleTasks?.tasks.length ?? "—"} OPEN TASKS</span><button className="text-button" disabled={syncing || !googleStatus.connected} onClick={() => void syncGoogleTasks()} type="button">{syncing ? "同期中…" : "更新"}</button></div>
        <div className="task-list full-list google-master-list">
          {visibleGoogleTasks.map((task) => (
            <GoogleTaskRow task={task} key={`${task.taskListId}-${task.id}`} onComplete={() => void completeGoogleTask(task).catch((error) => setFormMessage(String(error)))} />
          ))}
          {googleStatus.connected && googleTasks && !visibleGoogleTasks.length ? <div className="empty-state">該当するGoogle Taskはありません。</div> : null}
          {googleStatus.connected && !googleTasks ? <div className="empty-state">{syncing ? "Google Tasksを同期しています。" : "Google Tasksは未確認です。更新して再取得してください。"}</div> : null}
        </div>
      </section>

      <section className="panel side-panel-content">
        <div className="section-heading"><div><span>LOCAL PROJECTS</span><h2>パソコン内のTODO</h2></div></div>
        <p className="support-copy">登録したフォルダ内のTODO.md、TASKS.md、README.mdからチェックボックスを読み取ります。</p>
        <button className="primary-button full-button" onClick={() => void addProject()} type="button">＋ フォルダを登録</button>
        <div className="project-list">
          {state.projects.map((project) => (
            <article className="project-card" key={project.id}>
              <div><strong>{project.name}</strong><span>{project.gitSummary}</span></div>
              <small>{project.tasks.length} tasks · {new Date(project.scannedAt).toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}</small>
              <div className="project-actions">
                <button className="text-button" onClick={() => void rescanProject(project.path)} type="button">再読込</button>
                <button className="text-button danger-text" onClick={() => removeProject(project.id)} type="button">解除</button>
              </div>
            </article>
          ))}
          {!state.projects.length ? <div className="empty-state small">登録フォルダはありません。</div> : null}
        </div>
        {localTasks.some((task) => task.source === "project") ? (
          <div className="local-task-summary">
            <span>PROJECT TODO</span>
            {localTasks.filter((task) => task.source === "project" && !task.completed).map((task) => (
              <TaskRow
                task={task}
                key={task.id}
                onToggle={() => commit((current) => ({ ...current, tasks: current.tasks.map((item) => item.id === task.id ? { ...item, completed: true } : item) }))}
              />
            ))}
          </div>
        ) : null}
      </section>
    </div>
  );
}

function RevenueView({
  state,
  commit,
  importRevenue,
}: {
  state: AppState;
  commit: (updater: (current: AppState) => AppState) => void;
  importRevenue: () => Promise<void>;
}) {
  const [date, setDate] = useState(japanToday());
  const [label, setLabel] = useState("");
  const [source, setSource] = useState("手入力");
  const [amount, setAmount] = useState("");

  const lastSevenDays = useMemo(() => {
    return Array.from({ length: 7 }, (_, index) => {
      const dateValue = new Date();
      dateValue.setDate(dateValue.getDate() - (6 - index));
      const key = new Intl.DateTimeFormat("sv-SE", { year: "numeric", month: "2-digit", day: "2-digit" }).format(dateValue);
      return {
        key,
        label: new Intl.DateTimeFormat("ja-JP", { weekday: "short" }).format(dateValue),
        amount: state.revenue.filter((entry) => entry.date === key).reduce((sum, entry) => sum + entry.amount, 0),
      };
    });
  }, [state.revenue]);
  const maxAmount = Math.max(...lastSevenDays.map((item) => item.amount), 1);
  const total = state.revenue.reduce((sum, entry) => sum + entry.amount, 0);
  const currentMonth = monthKeyFromOffset(0);
  const previousMonth = monthKeyFromOffset(-1);
  const monthTotal = monthlyRevenue(state, currentMonth);
  const previousMonthTotal = monthlyRevenue(state, previousMonth);
  const monthEntries = state.revenue.filter((entry) => entry.date.startsWith(`${currentMonth}-`));
  const sourceTotals = [...new Set(monthEntries.map((entry) => entry.source))]
    .map((entrySource) => ({
      source: entrySource,
      amount: monthEntries.filter((entry) => entry.source === entrySource).reduce((sum, entry) => sum + entry.amount, 0),
    }))
    .sort((a, b) => b.amount - a.amount);

  function submit(event: FormEvent) {
    event.preventDefault();
    const numeric = Number(amount.replace(/[¥￥,\s]/g, ""));
    if (!label.trim() || !Number.isFinite(numeric)) return;
    const entry: RevenueEntry = { id: uid("revenue"), date, label: label.trim(), source: source.trim() || "手入力", amount: numeric };
    commit((current) => ({ ...current, revenue: [entry, ...current.revenue] }));
    setLabel(""); setAmount("");
  }

  return (
    <div className="revenue-layout">
      <section className="metrics-grid revenue-metrics">
        <MetricCard label="TODAY" value={formatCurrency(dailyRevenue(state))} detail="本日の登録売上" accent="gold" />
        <MetricCard label="THIS MONTH" value={formatCurrency(monthTotal)} detail={`${monthEntries.length}件 · 前月 ${formatCurrency(previousMonthTotal)}`} />
        <MetricCard label="ALL DATA" value={formatCurrency(total)} detail={`${state.revenue.length}件の合計`} accent="violet" />
      </section>
      <section className="panel chart-panel">
        <div className="section-heading">
          <div><span>7 DAY SIGNAL</span><h1>売上推移</h1></div>
          <button className="secondary-button" onClick={() => void importRevenue()} type="button">CSVを読み込む</button>
        </div>
        <div className="bar-chart">
          {lastSevenDays.map((item) => (
            <div className="bar-column" key={item.key}>
              <span>{item.amount ? formatCurrency(item.amount) : "—"}</span>
              <div className="bar-track"><i style={{ height: `${Math.max(item.amount ? 8 : 2, (item.amount / maxAmount) * 100)}%` }} /></div>
              <small>{item.label}</small>
            </div>
          ))}
        </div>
      </section>
      <section className="panel revenue-report-panel">
        <div className="section-heading"><div><span>DAILY / MONTHLY REPORT</span><h2>売上報告</h2></div></div>
        <div className="revenue-report-copy">
          <article><span>本日</span><strong>{formatCurrency(dailyRevenue(state))}</strong><small>{state.revenue.filter((entry) => entry.date === japanToday()).length}件</small></article>
          <article><span>{Number(currentMonth.slice(5, 7))}月累計</span><strong>{formatCurrency(monthTotal)}</strong><small>前月 {formatCurrency(previousMonthTotal)}</small></article>
        </div>
        <div className="source-breakdown">
          <span>今月の媒体・区分別</span>
          {sourceTotals.map((item) => <div key={item.source}><strong>{item.source}</strong><b>{formatCurrency(item.amount)}</b></div>)}
          {!sourceTotals.length ? <small>今月の売上明細はまだありません。</small> : null}
        </div>
        <p className="support-copy">「今日の売上を報告して」「今月の売上を報告して」と話しかけると音声でも確認できます。</p>
      </section>
      <section className="panel revenue-entry-panel">
        <div className="section-heading"><div><span>MANUAL INPUT</span><h2>売上を追加</h2></div></div>
        <form className="stack-form" onSubmit={submit}>
          <label>日付<input type="date" value={date} onChange={(event) => setDate(event.target.value)} /></label>
          <label>項目<input value={label} onChange={(event) => setLabel(event.target.value)} placeholder="コンサル売上" /></label>
          <label>金額<input inputMode="numeric" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="128000" /></label>
          <label>媒体・区分<input value={source} onChange={(event) => setSource(event.target.value)} /></label>
          <button className="primary-button" type="submit">売上を登録</button>
        </form>
      </section>
      <section className="panel revenue-table-panel">
        <div className="section-heading"><div><span>TRANSACTIONS</span><h2>売上明細</h2></div></div>
        <div className="data-table">
          {state.revenue.slice(0, 30).map((entry) => (
            <div className="data-row" key={entry.id}>
              <span>{entry.date}</span><strong>{entry.label}</strong><span>{entry.source}</span><b>{formatCurrency(entry.amount)}</b>
              <button className="icon-button danger" onClick={() => commit((current) => ({ ...current, revenue: current.revenue.filter((item) => item.id !== entry.id) }))} type="button">×</button>
            </div>
          ))}
          {!state.revenue.length ? <div className="empty-state">売上データはありません。CSVまたは手入力で登録してください。</div> : null}
        </div>
      </section>
    </div>
  );
}

function CamerasView({
  state,
  commit,
  query,
  setQuery,
  results,
  searching,
  search,
  addResult,
}: {
  state: AppState;
  commit: (updater: (current: AppState) => AppState) => void;
  query: string;
  setQuery: (value: string) => void;
  results: YouTubeLiveResult[];
  searching: boolean;
  search: (query?: string) => Promise<void>;
  addResult: (result: YouTubeLiveResult) => void;
}) {
  const [manualName, setManualName] = useState("");
  const [manualLocation, setManualLocation] = useState("");
  const [manualUrl, setManualUrl] = useState("");

  function addManual(event: FormEvent) {
    event.preventDefault();
    const videoId = extractYouTubeId(manualUrl);
    if (!manualName.trim() || !videoId) return;
    const camera: CameraItem = {
      id: uid("camera"), name: manualName.trim(), location: manualLocation.trim() || "登録地点", url: manualUrl.trim(), videoId,
    };
    commit((current) => ({ ...current, cameras: [camera, ...current.cameras.filter((item) => item.videoId !== videoId)] }));
    setManualName(""); setManualLocation(""); setManualUrl("");
  }

  return (
    <div className="camera-layout">
      <section className="panel camera-control-panel">
        <div className="section-heading"><div><span>PUBLIC LIVE FEEDS</span><h1>全国ライブモニター</h1></div><span className="youtube-attribution">Powered by YouTube</span></div>
        <form className="camera-search" onSubmit={(event) => { event.preventDefault(); void search(); }}>
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="羽田空港 ライブカメラ" />
          <button className="primary-button" type="submit" disabled={searching}>{searching ? "検索中…" : "ライブを検索"}</button>
          <button className="secondary-button" type="button" onClick={() => void window.hayato.openExternal(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`)}>YouTubeで探す</button>
        </form>
        <div className="quick-locations">
          {["福岡 天神", "東京ドーム", "大阪 道頓堀", "羽田空港", "渋谷", "札幌駅", "新宿", "富士山"].map((place) => (
            <button key={place} onClick={() => { setQuery(`${place} ライブカメラ`); void search(`${place} ライブカメラ`); }} type="button">{place}</button>
          ))}
        </div>
      </section>

      {results.length ? (
        <section className="panel search-results-panel">
          <div className="section-heading"><div><span>SEARCH RESULTS</span><h2>配信中の候補</h2></div></div>
          <div className="youtube-results">
            {results.map((result) => (
              <article key={result.id}>
                {result.thumbnail ? <img src={result.thumbnail} alt="" /> : <div className="result-placeholder" />}
                <div><strong>{result.title}</strong><span>{result.channelTitle}</span></div>
                <button className="secondary-button" onClick={() => addResult(result)} type="button">＋ 登録</button>
              </article>
            ))}
          </div>
        </section>
      ) : null}

      <section className="saved-camera-section">
        <div className="section-heading"><div><span>FAVORITE LOCATIONS</span><h2>登録地点</h2></div><span>{state.cameras.length} LOCATIONS</span></div>
        <div className="camera-grid full-camera-grid">
          {state.cameras.map((camera) => (
            <CameraPlayer
              key={camera.id}
              camera={camera}
              onOpen={() => void window.hayato.openExternal(camera.url)}
              onRemove={() => commit((current) => ({ ...current, cameras: current.cameras.filter((item) => item.id !== camera.id) }))}
            />
          ))}
          {!state.cameras.length ? <EmptyCamera onSearch={() => document.querySelector<HTMLInputElement>(".camera-search input")?.focus()} /> : null}
        </div>
      </section>

      <section className="panel manual-camera-panel">
        <div className="section-heading"><div><span>MANUAL REGISTRATION</span><h2>YouTube URLを登録</h2></div></div>
        <form className="inline-form camera-manual-form" onSubmit={addManual}>
          <input value={manualLocation} onChange={(event) => setManualLocation(event.target.value)} placeholder="地域（羽田空港）" />
          <input value={manualName} onChange={(event) => setManualName(event.target.value)} placeholder="表示名" />
          <input value={manualUrl} onChange={(event) => setManualUrl(event.target.value)} placeholder="https://www.youtube.com/watch?v=..." />
          <button className="primary-button" type="submit">登録</button>
        </form>
        <p className="support-copy">公開ライブを公式YouTubeプレイヤーで表示します。映像の保存や自動録画は行いません。</p>
      </section>
    </div>
  );
}

function AgentWorkView({
  availability,
  jobs,
  startJob,
  openTerminal,
  cancelJob,
  refreshAvailability,
  setNotice,
}: {
  availability: AgentAvailability;
  jobs: AgentJob[];
  startJob: (request: Omit<AgentStartRequest, "confirmed">) => Promise<void>;
  openTerminal: (job: AgentJob) => void;
  cancelJob: (jobId: string) => Promise<void>;
  refreshAvailability: () => Promise<AgentAvailability>;
  setNotice: (message: string) => void;
}) {
  const [provider, setProvider] = useState<AgentProvider>("codex");
  const [jobMode, setJobMode] = useState<AgentJobMode>("brainstorm");
  const [title, setTitle] = useState("");
  const [prompt, setPrompt] = useState("");
  const [projectPath, setProjectPath] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const activeCount = jobs.filter((job) => job.status === "queued" || job.status === "running").length;

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!prompt.trim()) {
      setFormError("AIへ渡す内容を入力してください。");
      return;
    }
    setSubmitting(true);
    setFormError("");
    try {
      await startJob({
        provider,
        mode: jobMode,
        title: title.trim() || prompt.trim().slice(0, 50),
        prompt: prompt.trim(),
        projectPath: projectPath || undefined,
      });
    } catch (error) {
      setFormError(String(error));
    } finally {
      setSubmitting(false);
    }
  }

  async function chooseProject() {
    const selected = await window.hayato.selectAgentProject();
    if (selected) setProjectPath(selected);
  }

  function providerCard(kind: AgentProvider) {
    const status = availability[kind];
    return (
      <button
        className={`agent-provider-card ${provider === kind ? "selected" : ""} ${status.loggedIn ? "ready" : ""}`}
        onClick={() => setProvider(kind)}
        type="button"
      >
        <i />
        <span><strong>{kind === "codex" ? "CODEX" : "CLAUDE CODE"}</strong><small>{status.loggedIn ? "ログイン済み" : status.installed ? "ログインが必要" : "未インストール"}</small></span>
        <b>{status.version || "—"}</b>
      </button>
    );
  }

  return (
    <div className="agent-work-layout">
      <section className="panel agent-launch-panel">
        <div className="section-heading">
          <div><span>BACKGROUND AI WORK</span><h1>AI作業を依頼</h1></div>
          <button className="text-button" onClick={() => void refreshAvailability().then(() => setNotice("AIの接続状態を更新しました。"))} type="button">接続を再確認</button>
        </div>
        <p className="support-copy">NORIKOとの会話を続けながら、CodexまたはClaude Codeへ壁打ち・制作を任せられます。完了通知は画面だけに表示します。</p>
        <div className="agent-provider-grid">{providerCard("codex")}{providerCard("claude")}</div>
        <form className="agent-job-form" onSubmit={submit}>
          <div className="agent-mode-switch" role="group" aria-label="作業種別">
            <button className={jobMode === "brainstorm" ? "active" : ""} onClick={() => setJobMode("brainstorm")} type="button"><strong>壁打ち</strong><small>考えを整理し、案を別ファイルへ保存</small></button>
            <button className={jobMode === "implement" ? "active" : ""} onClick={() => setJobMode("implement")} type="button"><strong>制作・実装</strong><small>選んだ作業フォルダ内だけを編集</small></button>
          </div>
          <label>作業名<input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="例：新サービスの構成案" /></label>
          <label>依頼内容<textarea value={prompt} onChange={(event) => setPrompt(event.target.value)} placeholder="考えたいこと、作りたいもの、条件をそのまま入力してください。" rows={7} /></label>
          <label>作業フォルダ（任意）
            <div className="agent-path-picker">
              <input readOnly value={projectPath} placeholder={`未選択なら新規作成：${availability.defaultWorkspacePath || "壁打ちプロジェクト"}`} />
              <button className="secondary-button" onClick={() => void chooseProject()} type="button">選択</button>
              {projectPath ? <button className="text-button" onClick={() => setProjectPath("")} type="button">新規に戻す</button> : null}
            </div>
          </label>
          {formError ? <p className="agent-form-error">{formError}</p> : null}
          <div className="agent-safety-note"><span>SUBSCRIPTION ONLY</span><p>APIキーは渡さず、ログイン済みの契約枠を使用します。危険な権限スキップ、外部公開、git push、予約・納期変更は行いません。</p></div>
          <button className="primary-button agent-start-button" disabled={submitting || !availability[provider].loggedIn || activeCount >= 2} type="submit">
            {submitting ? "引き渡し中…" : activeCount >= 2 ? "同時実行は2件まで" : `${provider === "codex" ? "Codex" : "Claude Code"}へ依頼する`}
          </button>
        </form>
      </section>

      <section className="panel agent-jobs-panel">
        <div className="section-heading"><div><span>JOB MONITOR</span><h2>作業状況</h2></div><span>{activeCount} RUNNING</span></div>
        <div className="agent-job-list">
          {jobs.map((job) => (
            <article className={`agent-job-card status-${job.status}`} key={job.id}>
              <div className="agent-job-head">
                <span className="agent-status-dot"><i />{job.status === "queued" ? "準備中" : job.status === "running" ? "作業中" : job.status === "completed" ? "完了" : job.status === "cancelled" ? "中止" : "要確認"}</span>
                <small>{job.provider === "claude" ? "CLAUDE CODE" : "CODEX"} · {job.mode === "implement" ? "制作・実装" : "壁打ち"}</small>
              </div>
              <strong>{job.title}</strong>
              <p>{job.status === "failed" ? job.error : job.summary || (job.status === "running" ? "バックグラウンドで作業しています。NORIKOはそのまま利用できます。" : job.prompt)}</p>
              <span className="agent-job-path">{job.outputPath || job.projectPath}</span>
              <div className="agent-job-actions">
                {job.status === "completed" && job.outputPath ? <button className="primary-button" onClick={() => void window.hayato.openAgentResult(job.outputPath!)} type="button">結果を開く</button> : null}
                <button className="secondary-button" onClick={() => openTerminal(job)} type="button">引き継ぎを確認して開く</button>
                {(job.status === "queued" || job.status === "running") ? <button className="text-button danger-text" onClick={() => void cancelJob(job.id).catch((error) => setNotice(String(error)))} type="button">中止</button> : null}
              </div>
            </article>
          ))}
          {!jobs.length ? <div className="empty-state">まだAI作業はありません。上のフォーム、または「Codexで壁打ちして」とNORIKOへ話しかけて開始できます。</div> : null}
        </div>
      </section>
    </div>
  );
}

function SettingsView({
  state,
  commit,
  status,
  setStatus,
  setNotice,
  googleStatus,
  setGoogleStatus,
  connectGoogle,
  localStatus,
  refreshLocalStatus,
  knowledgeStatus,
  setKnowledgeStatus,
  playFishVoiceTest,
}: {
  state: AppState;
  commit: (updater: (current: AppState) => AppState) => void;
  status: SecretStatus;
  setStatus: (status: SecretStatus) => void;
  setNotice: (message: string) => void;
  googleStatus: GoogleAccountStatus;
  setGoogleStatus: (status: GoogleAccountStatus) => void;
  connectGoogle: () => Promise<void>;
  localStatus: LocalSystemStatus;
  refreshLocalStatus: () => Promise<void>;
  knowledgeStatus: ObsidianKnowledgeStatus;
  setKnowledgeStatus: (status: ObsidianKnowledgeStatus) => void;
  playFishVoiceTest: () => ReturnType<typeof window.hayato.speak>;
}) {
  const [openaiKey, setOpenaiKey] = useState("");
  const [fishKey, setFishKey] = useState("");
  const [fishReferenceId, setFishReferenceId] = useState("");
  const [fishVoices, setFishVoices] = useState<FishVoiceModel[]>([]);
  const [fishVoiceLoading, setFishVoiceLoading] = useState(false);
  const [fishTesting, setFishTesting] = useState(false);
  const [youtubeKey, setYoutubeKey] = useState("");
  const [knowledgeTesting, setKnowledgeTesting] = useState(false);
  const [knowledgeTestQuery, setKnowledgeTestQuery] = useState("企画では対象者と目的を先に明確にする");
  const [knowledgeSearchMessage, setKnowledgeSearchMessage] = useState("");
  const [starterProfile, setStarterProfile] = useState<Awaited<ReturnType<typeof window.hayato.getStarterProfile>> | null>(null);
  const [profileError, setProfileError] = useState("");
  useEffect(() => {
    let active = true;
    window.hayato.getStarterProfile().then((profile) => {
      if (active) setStarterProfile(profile);
    }).catch(() => {
      if (active) setProfileError("保存先を確認できませんでした。旧版の画面が残っていないか確認し、アプリを再起動してください。");
    });
    return () => { active = false; };
  }, []);

  async function loadFishVoices() {
    setFishVoiceLoading(true);
    try {
      const result = await window.hayato.listFishVoices(fishKey);
      if (result.needsKey) {
        setNotice("Fish Audio APIキーを入力してから、ボイスを取得してください。");
        return;
      }
      setFishVoices(result.items);
      const firstVoice = result.items[0];
      if (firstVoice) {
        setFishReferenceId(firstVoice.id);
        setNotice(`${result.items.length}件のボイスを取得しました。「${firstVoice.title}」を仮選択しています。必要なら一覧から変更してください。`);
      } else {
        setNotice("このAPIキーのアカウントにボイスが見つかりませんでした。課金・作成したアカウントと同じか確認してください。");
      }
    } catch (error) {
      setNotice(`Fish Audioのボイスを取得できません: ${String(error)}`);
    } finally {
      setFishVoiceLoading(false);
    }
  }

  async function testFishVoice() {
    setFishTesting(true);
    try {
      const volume = voiceOutputLevel(state.preferences);
      if (volume <= 0) {
        setNotice("AI NORIKOの音声はミュート中です。音量を上げてからテストしてください。");
        return;
      }
      const result = await playFishVoiceTest();
      if (!result.audio) {
        const reason = result.reason === "disabled"
          ? "「Fish Audioのクローン音声を使用」をオンにしてください。"
          : "APIキーと使用するボイスを取得して、安全に保存してください。";
        setNotice(reason);
        return;
      }
      setNotice(`Fish Audio ${result.model || ""} からテスト音声を再生しています。`);
    } catch (error) {
      setNotice(`Fish Audio接続テストに失敗しました: ${String(error)}`);
    } finally {
      setFishTesting(false);
    }
  }

  async function saveSecrets(event: FormEvent) {
    event.preventDefault();
    try {
      const next = await window.hayato.saveSecrets({
        openaiApiKey: openaiKey,
        fishApiKey: fishKey,
        fishReferenceId,
        youtubeApiKey: youtubeKey,
      });
      setStatus(next);
      setOpenaiKey(""); setFishKey(""); setFishReferenceId(""); setYoutubeKey("");
      setNotice("API設定を端末の暗号化ストレージに保存しました。");
    } catch (error) {
      setNotice(String(error));
    }
  }

  async function importGoogleOauth() {
    try {
      const result = await window.hayato.importGoogleCredentials();
      if (!result) return;
      setStatus(result.status);
      setGoogleStatus(result.google);
      setNotice(`${result.filename}を暗号化保存しました。続けてGoogleアカウントへ接続してください。`);
    } catch (error) {
      setNotice(`Google OAuth設定を読み込めません: ${String(error)}`);
    }
  }

  async function selectKnowledgeFolder() {
    try {
      const next = await window.hayato.selectKnowledgeFolder();
      if (!next) return;
      setKnowledgeStatus(next);
      commit((current) => ({
        ...current,
        preferences: { ...current.preferences, obsidianKnowledgePath: next.path },
      }));
      setNotice(next.available
        ? `Obsidianナレッジ${next.noteCount}件へ接続しました。`
        : `フォルダを読み込めませんでした。${next.error || ""}`);
    } catch (error) {
      setNotice(`Obsidianフォルダを設定できません: ${String(error)}`);
    }
  }

  async function refreshKnowledgeStatus() {
    try {
      const next = await window.hayato.getKnowledgeStatus();
      setKnowledgeStatus(next);
      setNotice(next.available
        ? `Obsidianナレッジ${next.noteCount}件を確認しました。`
        : `Obsidianナレッジを確認できません。${next.error || ""}`);
    } catch (error) {
      setNotice(`Obsidian接続を確認できません: ${String(error)}`);
    }
  }

  async function testKnowledgeSearch() {
    if (!knowledgeTestQuery.trim()) return;
    setKnowledgeTesting(true);
    setKnowledgeSearchMessage("");
    try {
      const result = await window.hayato.searchKnowledge(knowledgeTestQuery.trim());
      setKnowledgeStatus(result.status);
      setKnowledgeSearchMessage(result.sources.length
        ? `検索結果：${result.sources.map((source) => `${source.title}（${source.relativePath}）`).join("、")}`
        : "フォルダは接続できましたが、この検索文に合うナレッジはありません。ノート内の言葉で試してください。");
    } catch (error) {
      setKnowledgeSearchMessage(`Obsidian検索テストに失敗しました: ${String(error)}`);
    } finally {
      setKnowledgeTesting(false);
    }
  }

  return (
    <div className="settings-layout">
      <section className="panel settings-panel instance-profile-panel">
        <div className="section-heading"><div><span>SEPARATE WORKSPACE / v1.2</span><h2>このAI NORIKOの保存先</h2></div></div>
        <p className="support-copy">別の本体フォルダに展開したキットとは、設定・タスク・認証情報・標準ナレッジを分けて保存します。同じフォルダでの再起動は引き継がれます。</p>
        {starterProfile ? <dl className="instance-profile-list">
          <dt>環境ID</dt><dd><code>{starterProfile.instanceId}</code></dd>
          <dt>本体フォルダ</dt><dd><code>{starterProfile.projectPath}</code></dd>
          <dt>設定・タスク・認証</dt><dd><code>{starterProfile.userDataPath}</code></dd>
          <dt>標準ナレッジ</dt><dd><code>{starterProfile.knowledgePath}</code></dd>
          <dt>AI作業の保存先</dt><dd><code>{starterProfile.agentWorkspacePath}</code></dd>
        </dl> : <p className="support-copy" role="status">{profileError || "保存先を確認しています…"}</p>}
        <p className="support-copy">初回起動後は本体フォルダ名・場所を変えないでください。変えると別環境になり、元のデータは削除されず残ります。旧版の設定は自動で移しません。</p>
        <p className="support-copy">同じGoogleアカウントや同じObsidianフォルダを選ぶと、その連携先は共有されます。お客様には未使用の配布ZIPを渡し、ご本人の連携先を設定してください。</p>
      </section>
      <section className="panel settings-panel">
        <div className="section-heading"><div><span>PERSONA</span><h1>基本設定</h1></div></div>
        <div className="stack-form">
          <label className="toggle-row free-mode-toggle"><span><strong>会話AIはローカルモード</strong><small>{state.preferences.freeMode !== false ? "OpenAI APIを呼び出さず、このパソコンのOllamaで処理します。音声APIは別設定です。" : "OpenAI APIモード：相談・履歴・関連ノートをOpenAIへ送信します。API料金が発生する場合があります。"}</small></span><input type="checkbox" checked={state.preferences.freeMode !== false} onChange={(event) => commit((current) => ({ ...current, preferences: { ...current.preferences, freeMode: event.target.checked } }))} /></label>
          <label>あなたの呼び名<input value={state.preferences.userName} onChange={(event) => commit((current) => ({ ...current, preferences: { ...current.preferences, userName: event.target.value } }))} /></label>
          <label>アシスタント名<input value={state.preferences.assistantName} onChange={(event) => commit((current) => ({ ...current, preferences: { ...current.preferences, assistantName: event.target.value } }))} /></label>
          <label>ローカルAIモデル<input value={state.preferences.localAIModel} onChange={(event) => commit((current) => ({ ...current, preferences: { ...current.preferences, localAIModel: event.target.value } }))} /></label>
          <label className="toggle-row"><span><strong>自動読み上げ</strong><small>報告をFish Audioまたは端末音声で再生</small></span><input type="checkbox" checked={state.preferences.autoSpeak} onChange={(event) => commit((current) => ({ ...current, preferences: { ...current.preferences, autoSpeak: event.target.checked } }))} /></label>
          <div className="voice-volume-control">
            <div className="voice-volume-copy">
              <span><strong>AI NORIKOの音量</strong><small>Fish Audio・端末音声・音声通知に共通。Zoom中はミュートできます。</small></span>
              <output>{voiceOutputLevel(state.preferences) <= 0 ? "ミュート" : `${Math.round(voiceOutputLevel(state.preferences) * 100)}%`}</output>
            </div>
            <div className="voice-volume-actions">
              <button
                className={voiceOutputLevel(state.preferences) <= 0 ? "secondary-button muted" : "secondary-button"}
                onClick={() => commit((current) => {
                  const currentlyMuted = voiceOutputLevel(current.preferences) <= 0;
                  return {
                    ...current,
                    preferences: {
                      ...current.preferences,
                      voiceMuted: !currentlyMuted,
                      voiceVolume: currentlyMuted && Number(current.preferences.voiceVolume) <= 0
                        ? 0.8
                        : current.preferences.voiceVolume,
                    },
                  };
                })}
                type="button"
              >
                {voiceOutputLevel(state.preferences) <= 0 ? "音声を再開" : "ミュート"}
              </button>
              <input
                aria-label="AI NORIKOの音量"
                max="100"
                min="0"
                onChange={(event) => {
                  const nextVolume = Number(event.target.value) / 100;
                  commit((current) => ({
                    ...current,
                    preferences: {
                      ...current.preferences,
                      voiceVolume: nextVolume,
                      voiceMuted: nextVolume <= 0,
                    },
                  }));
                }}
                step="1"
                type="range"
                value={Math.round((Number.isFinite(Number(state.preferences.voiceVolume)) ? Number(state.preferences.voiceVolume) : 0.8) * 100)}
              />
            </div>
          </div>
          <label className="toggle-row"><span><strong>毎朝の自動報告</strong><small>設定時刻を過ぎてAI NORIKOが起動している時、予定・タスク・売上・顧客フォローを報告</small></span><input type="checkbox" checked={state.preferences.morningReportEnabled !== false} onChange={(event) => commit((current) => ({ ...current, preferences: { ...current.preferences, morningReportEnabled: event.target.checked } }))} /></label>
          <label>朝の報告時刻<input type="time" value={state.preferences.morningReportTime || "08:00"} onChange={(event) => commit((current) => ({ ...current, preferences: { ...current.preferences, morningReportTime: event.target.value, lastMorningReportDate: undefined } }))} /></label>
          <label className="toggle-row fish-voice-toggle"><span><strong>Fish Audioのクローン音声を使用</strong><small>読み上げ時にFish Audio APIを呼び出します（選択モデルの料金が適用）</small></span><input type="checkbox" checked={state.preferences.fishVoiceEnabled === true} onChange={(event) => commit((current) => ({ ...current, preferences: { ...current.preferences, fishVoiceEnabled: event.target.checked } }))} /></label>
          <label>Fish Audio APIモデル
            <select value={state.preferences.fishVoiceModel || "s2.1-pro-free"} onChange={(event) => commit((current) => ({ ...current, preferences: { ...current.preferences, fishVoiceModel: event.target.value as AppState["preferences"]["fishVoiceModel"] } }))}>
              <option value="s2.1-pro-free">S2.1 Pro Free（無料提供中）</option>
              <option value="s2-pro">S2 Pro（有料・従量課金）</option>
            </select>
          </label>
        </div>
      </section>

      <section className="panel settings-panel api-panel">
        <div className="section-heading"><div><span>OPTIONAL PAID SERVICES</span><h2>外部AI・音声API（任意）</h2></div></div>
        <p className="support-copy">会話AIの無料モードとFish Audio音声は別々に設定できます。APIキーはこの端末の暗号化ストレージだけに保存します。</p>
        <p className="support-copy api-cost-warning">S2.1 Pro Freeは現在無料提供中です。有料モデルを選ぶ場合、Fish Audio Plusの利用料とAPI従量料金は別です。</p>
        <form className="stack-form" onSubmit={saveSecrets}>
          <label>OpenAI APIキー<span className={`field-status ${status.openai ? "ok" : ""}`}>{status.openai ? "設定済み" : "未設定"}</span><input type="password" value={openaiKey} onChange={(event) => setOpenaiKey(event.target.value)} placeholder={status.openai ? "変更する場合のみ入力" : "sk-..."} /></label>
          <label>Fish Audio APIキー<span className={`field-status ${status.fish ? "ok" : ""}`}>{status.fish ? "設定済み" : "未設定"}</span><input type="password" value={fishKey} onChange={(event) => setFishKey(event.target.value)} placeholder={status.fish ? "保存済みのキーを使う場合は空欄" : "Fish API key"} /></label>
          <div className="api-helper-actions">
            <button className="secondary-button" onClick={() => void window.hayato.openExternal("https://fish.audio/app/api-keys/")} type="button">APIキーを作成</button>
            <button className="secondary-button" disabled={fishVoiceLoading} onClick={() => void loadFishVoices()} type="button">{fishVoiceLoading ? "取得中…" : "自分のボイスを取得"}</button>
          </div>
          {fishVoices.length ? (
            <label>使用するFish Audioボイス<span className={`field-status ${fishReferenceId ? "ok" : ""}`}>{fishReferenceId ? "選択済み" : "未選択"}</span>
              <select value={fishReferenceId} onChange={(event) => setFishReferenceId(event.target.value)}>
                <option value="">ボイスを選択してください</option>
                {fishVoices.map((voice) => <option key={voice.id} value={voice.id}>{voice.title} · {voice.visibility === "private" ? "非公開" : voice.visibility}</option>)}
              </select>
            </label>
          ) : (
            <label>Fish Audio Voice ID<span className={`field-status ${status.fishVoice ? "ok" : ""}`}>{status.fishVoice ? "設定済み" : "ボイス取得で自動入力"}</span><input type="password" value={fishReferenceId} onChange={(event) => setFishReferenceId(event.target.value)} placeholder="reference_id（通常は自動取得）" /></label>
          )}
          <label>YouTube Data APIキー<span className={`field-status ${status.youtube ? "ok" : ""}`}>{status.youtube ? "設定済み" : "未設定"}</span><input type="password" value={youtubeKey} onChange={(event) => setYoutubeKey(event.target.value)} placeholder={status.youtube ? "変更する場合のみ入力" : "AIza..."} /></label>
          <button className="primary-button" type="submit">安全に保存</button>
          <button className="secondary-button" disabled={fishTesting} onClick={() => void testFishVoice()} type="button">{fishTesting ? "Fish Audioへ接続中…" : "保存済みのボイスを接続テスト"}</button>
        </form>
      </section>

      <section className="panel business-feature-panel">
        <div className="section-heading"><div><span>ADD-ON FEATURES</span><h2>機能を追加</h2></div></div>
        <p className="support-copy">基本画面は予定・タスク・会話に集中し、業種によって必要な機能だけを後から追加できます。</p>
        <label className="toggle-row business-feature-toggle">
          <span><strong>売上管理（事業者向け）</strong><small>CSV・手入力、日次／月次集計、音声報告を追加。有効にすると左メニューに「売上」が表示されます。</small></span>
          <input
            type="checkbox"
            checked={state.preferences.revenueEnabled === true}
            onChange={(event) => {
              const enabled = event.target.checked;
              commit((current) => ({
                ...current,
                preferences: { ...current.preferences, revenueEnabled: enabled },
              }));
              setNotice(enabled ? "売上管理を追加しました。左メニューから開けます。" : "売上管理を非表示にしました。登録済みデータは削除されません。");
            }}
          />
        </label>
        <p className="feature-privacy-note">追加料金・API契約は不要です。登録データはこのパソコン内に保存されます。</p>
      </section>

      <section className="panel local-ai-panel">
        <div className="section-heading">
          <div><span>ZERO COST LOCAL CORE</span><h2>無料ローカルAI</h2></div>
          <button className="secondary-button" onClick={() => void refreshLocalStatus()} type="button">状態を再確認</button>
        </div>
        <div className="local-status-grid">
          <article className={localStatus.ollama ? "ready" : ""}><i /><div><strong>OLLAMA ENGINE</strong><span>{localStatus.ollama ? "起動中" : "停止中"}</span></div></article>
          <article className={localStatus.model ? "ready" : ""}><i /><div><strong>QWEN 3.5</strong><span>{localStatus.model ? `${localStatus.modelName} 準備完了` : "モデル未検出"}</span></div></article>
          <article className={localStatus.whisper ? "ready" : ""}><i /><div><strong>LOCAL SPEECH</strong><span>{localStatus.whisper ? "日本語音声認識 準備完了" : "音声モデル未検出"}</span></div></article>
          <article className="ready"><i /><div><strong>DEVICE VOICE</strong><span>標準読み上げ・課金なし</span></div></article>
        </div>
        <p className="support-copy local-note">緑色の4項目がそろえば、AI回答・音声認識・読み上げを従量課金なしで利用できます。</p>
      </section>

      <section className="panel knowledge-settings-panel">
        <div className="section-heading">
          <div><span>LOCAL KNOWLEDGE</span><h2>Obsidianナレッジ</h2></div>
          <span className={`field-status static-status ${knowledgeStatus.available ? "ok" : ""}`}>
            {knowledgeStatus.available ? `${knowledgeStatus.noteCount}件 接続済み` : "未接続"}
          </span>
        </div>
        <p className="support-copy">相談の関連Markdownは、ローカルモードでは端末のOllamaへ、OpenAI APIモードではOpenAIへ渡します。Codex／Claude Codeへの作業・起動は確認画面で承認してから、会話と関連上位5件の抜粋を引き継ぎます。秘密情報を含むフォルダは選ばないでください。</p>
        <div className="knowledge-path-card">
          <span>KNOWLEDGE FOLDER</span>
          <strong>{knowledgeStatus.path || "フォルダ未設定"}</strong>
          <small>{knowledgeStatus.available ? `Markdown ${knowledgeStatus.noteCount}件を検索可能` : knowledgeStatus.error || "Obsidian内のAI NORIKOナレッジフォルダを選択してください。"}</small>
        </div>
        <label className="knowledge-test-query">検索テストの言葉<input value={knowledgeTestQuery} onChange={(event) => setKnowledgeTestQuery(event.target.value)} placeholder="例：構造化思考、企画の対象者" /></label>
        <div className="knowledge-actions">
          <button className="secondary-button" onClick={() => void selectKnowledgeFolder()} type="button">フォルダを変更</button>
          <button className="secondary-button" onClick={() => void refreshKnowledgeStatus()} type="button">件数を再確認</button>
          <button className="secondary-button" disabled={!knowledgeStatus.available || knowledgeTesting || !knowledgeTestQuery.trim()} onClick={() => void testKnowledgeSearch()} type="button">
            {knowledgeTesting ? "検索中…" : "ナレッジ検索をテスト"}
          </button>
        </div>
        {knowledgeSearchMessage ? <p className="support-copy" role="status">{knowledgeSearchMessage}</p> : null}
      </section>

      <section className="panel google-settings-panel">
        <div className="section-heading">
          <div><span>GOOGLE WORKSPACE</span><h2>スケジュール連携</h2></div>
          <span className={`field-status static-status ${googleStatus.connected ? "ok" : ""}`}>{googleStatus.connected ? `${googleStatus.email} 接続済み` : status.googleClient ? "認証設定済み" : "未設定"}</span>
        </div>
        <p className="support-copy">個人用のGoogle Cloud OAuth設定を使い、カレンダーは閲覧、Google Tasksは登録・完了・閲覧に利用します。Gmail本文は読みません。</p>
        <ol className="setup-steps">
          <li>Google CloudでCalendar APIとTasks APIを有効化</li>
          <li>OAuth同意画面を設定し、自分のGmailをテストユーザーへ追加</li>
          <li>「デスクトップアプリ」のOAuthクライアントを作成してJSONをダウンロード</li>
        </ol>
        <div className="google-settings-actions">
          <button className="secondary-button" onClick={() => void window.hayato.openExternal("https://console.cloud.google.com/apis/credentials")} type="button">Google Cloudを開く</button>
          <button className="secondary-button" onClick={() => void importGoogleOauth()} type="button">OAuth JSONを読み込む</button>
          {status.googleClient && !googleStatus.connected ? <button className="google-button compact" onClick={() => void connectGoogle()} type="button"><b>G</b> Googleで接続</button> : null}
          {status.googleClient && googleStatus.connected ? <button className="google-button compact" onClick={() => void connectGoogle()} type="button"><b>G</b> {googleStatus.tasksWritable ? "Google権限を再確認" : "Google権限を更新"}</button> : null}
        </div>
      </section>

      <section className="panel security-note">
        <span className="shield-mark">◇</span>
        <div><strong>LOCAL-FIRST CONTROL</strong><p>認証トークンはOSの暗号化ストレージに保存します。Google連携はカレンダー閲覧とTasksの登録・完了だけに使用し、メール送信・削除・予定変更は行いません。</p></div>
      </section>
    </div>
  );
}

export default App;
