import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import { readFileSync } from "node:fs";
import crypto from "node:crypto";
import os from "node:os";
import path from "node:path";
import vm from "node:vm";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const sourcePath = fileURLToPath(new URL("../electron/main.cjs", import.meta.url));
const backendRequire = createRequire(sourcePath);
const source = readFileSync(sourcePath, "utf8");

// Execute the actual backend for multiple copies, sharing only a disposable OS
// home. Electron, network and OS credentials are never opened by this suite.
async function fixture(t) {
  const temporary = await fs.mkdtemp(path.join(os.tmpdir(), "noriko-instance-test-"));
  t.after(() => fs.rm(temporary, { recursive: true, force: true }));
  const basePaths = Object.fromEntries(["appData", "documents", "home", "temp", "desktop"]
    .map((key) => [key, path.join(temporary, key)]));
  await Promise.all(Object.values(basePaths).map((directory) => fs.mkdir(directory, { recursive: true })));
  const kitA = path.join(temporary, "キット A ' !");
  const kitB = path.join(temporary, "キット B ' !");
  await Promise.all([kitA, kitB].map((directory) => fs.mkdir(path.join(directory, "electron"), { recursive: true })));
  const locks = new Set();
  const key = crypto.randomBytes(32);
  const observedReads = [];
  const legacyNames = ["AI NORIKO Starter", "AI HAYATO Starter", "ai-hayato-starter-kit", "ai-hayato"];
  const legacyFiles = [];
  for (const name of legacyNames) {
    const directory = path.join(basePaths.appData, name);
    await fs.mkdir(directory, { recursive: true });
    for (const filename of ["hayato-data.json", "hayato-secrets.bin", "hayato-agent-jobs.json"]) {
      const file = path.join(directory, filename);
      const content = Buffer.from(`LEGACY_SENTINEL:${name}:${filename}`);
      await fs.writeFile(file, content);
      legacyFiles.push({ file, content });
    }
  }
  const encryptedStorage = {
    isEncryptionAvailable: () => true,
    encryptString(value) {
      const iv = crypto.randomBytes(12);
      const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
      const ciphertext = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
      return Buffer.concat([iv, cipher.getAuthTag(), ciphertext]);
    },
    decryptString(value) {
      const decipher = crypto.createDecipheriv("aes-256-gcm", key, value.subarray(0, 12));
      decipher.setAuthTag(value.subarray(12, 28));
      return Buffer.concat([decipher.update(value.subarray(28)), decipher.final()]).toString("utf8");
    },
  };
  function open(kitRoot, { documentsOverride } = {}) {
    const paths = { ...basePaths };
    const order = [];
    const ipc = new Map();
    const events = new Map();
    let quit = false;
    let ownsLock = false;
    const electron = {
      app: {
        getPath: (name) => { assert.ok(paths[name], `unexpected app path ${name}`); return paths[name]; },
        setPath: (name, value) => { order.push(name); paths[name] = value; },
        setName() {}, setAppUserModelId() {},
        on: (name, handler) => events.set(name, handler),
        whenReady: () => { order.push("whenReady"); return { then() {} }; },
        requestSingleInstanceLock: () => {
          order.push("lock");
          if (locks.has(paths.userData)) return false;
          locks.add(paths.userData); ownsLock = true; return true;
        },
        quit: () => { quit = true; },
      },
      ipcMain: { handle: (name, handler) => ipc.set(name, handler) },
      safeStorage: encryptedStorage,
    };
    const sandbox = {
      require: (specifier) => {
        if (specifier === "electron") return electron;
        if (specifier === "node:fs/promises") return {
          ...fs, readFile: (...args) => { observedReads.push(String(args[0])); return fs.readFile(...args); },
        };
        return backendRequire(specifier);
      },
      process: { platform: process.platform, env: documentsOverride ? { NORIKO_DOCUMENTS_DIR: documentsOverride } : {}, pid: process.pid },
      Buffer, URL, URLSearchParams, AbortSignal, setTimeout, clearTimeout, console,
      __dirname: path.join(kitRoot, "electron"),
      fetch: async () => { throw new Error("Network disabled in profile tests"); },
    };
    vm.createContext(sandbox);
    vm.runInContext(`${source}\nglobalThis.api = {
      instanceProfile, readState, writeState, readSecrets, writeSecrets,
      readAgentJobs, writeAgentJobs, initializeStarterFolders,
      getStarterProfile, defaultKnowledgePath, defaultAgentWorkspacePath,
      saveObsidianKnowledge, searchObsidianKnowledge, registerIpc,
    };`, sandbox, { filename: sourcePath });
    return {
      api: sandbox.api, paths, order, ipc, events, quit,
      close: () => { if (ownsLock) { locks.delete(paths.userData); ownsLock = false; } },
    };
  }
  return { temporary, basePaths, kitA, kitB, open, observedReads, legacyFiles };
}

test("two copies isolate actual backend state, encrypted secrets, jobs, knowledge, workspaces and session storage across restart", async (t) => {
  const f = await fixture(t);
  const a = f.open(f.kitA);
  const b = f.open(f.kitB);
  assert.equal(a.quit, false);
  assert.equal(b.quit, false);
  for (const instance of [a, b]) {
    assert.deepEqual(instance.order, ["userData", "sessionData", "lock", "whenReady"]);
    assert.equal((await fs.stat(instance.paths.sessionData)).isDirectory(), true);
  }
  const directories = {};
  for (const [label, instance] of [["A", a], ["B", b]]) {
    assert.deepEqual(JSON.parse(JSON.stringify(await instance.api.readSecrets())), {});
    assert.equal((await instance.api.readAgentJobs()).length, 0);
    const state = await instance.api.readState();
    assert.equal(state.preferences.onboardingCompleted, false);
    const folders = await instance.api.initializeStarterFolders();
    directories[label] = folders;
    state.preferences.userName = `fixture-user-${label}`;
    state.preferences.onboardingCompleted = true;
    state.preferences.obsidianKnowledgePath = folders.knowledgePath;
    state.tasks = [{ id: `task-${label}`, title: `task-${label}`, completed: label === "B", source: "manual" }];
    await instance.api.writeState(state);
    await instance.api.writeSecrets({ fishApiKey: `fixture-secret-${label}`, googleRefreshToken: `fixture-refresh-${label}` });
    await instance.api.writeAgentJobs([{ id: `job-${label}`, status: "completed" }]);
    await instance.api.saveObsidianKnowledge({ confirmed: true, title: `note-${label}`, userText: `相談の記録${label}専用です。` });
    await fs.writeFile(path.join(folders.agentWorkspacePath, "fixture-work.txt"), `work-${label}`);
    await fs.writeFile(path.join(instance.paths.sessionData, "fixture-session.txt"), `session-${label}`);
    const encoded = await fs.readFile(path.join(instance.paths.userData, "hayato-secrets.bin"));
    assert.equal(encoded.includes(Buffer.from(`fixture-secret-${label}`)), false);
  }
  for (const key of ["instanceId", "userDataPath", "sessionDataPath", "knowledgePath", "agentWorkspacePath"]) {
    assert.notEqual(directories.A[key], directories.B[key], key);
  }
  a.close(); b.close();
  for (const [label, kit] of [["A", f.kitA], ["B", f.kitB]]) {
    const restarted = f.open(kit);
    t.after(() => restarted.close());
    const state = await restarted.api.readState();
    assert.equal(state.preferences.userName, `fixture-user-${label}`);
    assert.equal(state.tasks.length, 1);
    assert.equal(state.tasks[0].id, `task-${label}`);
    assert.equal((await restarted.api.readSecrets()).fishApiKey, `fixture-secret-${label}`);
    assert.equal((await restarted.api.readSecrets()).googleRefreshToken, `fixture-refresh-${label}`);
    assert.equal((await restarted.api.readAgentJobs())[0].id, `job-${label}`);
    assert.equal(state.preferences.obsidianKnowledgePath, directories[label].knowledgePath);
    const notes = await restarted.api.searchObsidianKnowledge(`相談の記録${label}専用`);
    assert.ok(notes.sources.some((note) => note.title === `note-${label}`));
    assert.ok(notes.sources.every((note) => note.title !== `note-${label === "A" ? "B" : "A"}`));
    assert.equal((await fs.readdir(path.join(directories[label].knowledgePath, "AI-NORIKO-Records"))).length, 1);
    assert.equal(await fs.readFile(path.join(directories[label].agentWorkspacePath, "fixture-work.txt"), "utf8"), `work-${label}`);
    assert.equal(await fs.readFile(path.join(restarted.paths.sessionData, "fixture-session.txt"), "utf8"), `session-${label}`);
  }
  for (const { file, content } of f.legacyFiles) {
    assert.equal(f.observedReads.includes(file), false, "legacy profile must not be read");
    assert.deepEqual(await fs.readFile(file), content, "legacy profile must remain unchanged");
  }
});

test("profile IPC is read-only, exposes only paths, and document overrides remain instance-specific", async (t) => {
  const f = await fixture(t);
  const documentsOverride = path.join(f.temporary, "override documents");
  const a = f.open(f.kitA, { documentsOverride });
  const b = f.open(f.kitB, { documentsOverride });
  t.after(() => { a.close(); b.close(); });
  a.api.registerIpc();
  const profile = await a.ipc.get("starter:profile")();
  assert.deepEqual(Object.keys(profile).sort(), ["instanceId", "projectPath", "userDataPath", "sessionDataPath", "knowledgePath", "agentWorkspacePath"].sort());
  assert.equal(profile.projectPath, await fs.realpath(f.kitA));
  assert.equal(profile.knowledgePath, path.join(documentsOverride, "AI-NORIKO-Instances", profile.instanceId, "Knowledge"));
  assert.equal(profile.agentWorkspacePath, path.join(documentsOverride, "AI-NORIKO-Instances", profile.instanceId, "Workspaces"));
  await assert.rejects(fs.stat(documentsOverride), { code: "ENOENT" });
  assert.deepEqual(await fs.readdir(a.paths.userData), ["session"]);
  await Promise.all([a.api.initializeStarterFolders(), b.api.initializeStarterFolders()]);
  assert.notEqual(a.api.defaultKnowledgePath(), b.api.defaultKnowledgePath());
  assert.notEqual(a.api.defaultAgentWorkspacePath(), b.api.defaultAgentWorkspacePath());
  assert.deepEqual(await fs.readdir(f.basePaths.documents), []);
});

test("same folder uses one profile/lock even through a symlink; separate copies can run together", async (t) => {
  const f = await fixture(t);
  const a = f.open(f.kitA);
  const b = f.open(f.kitB);
  t.after(() => { a.close(); b.close(); });
  const duplicate = f.open(f.kitA);
  assert.equal(duplicate.quit, true);
  assert.equal(duplicate.paths.userData, a.paths.userData);
  const alias = path.join(f.temporary, "alias");
  try { await fs.symlink(f.kitA, alias, process.platform === "win32" ? "junction" : "dir"); }
  catch (error) { if (error.code === "EPERM") { t.diagnostic("symlink privilege unavailable; direct duplicate lock verified"); return; } throw error; }
  const viaAlias = f.open(alias);
  assert.equal(viaAlias.quit, true);
  assert.equal(viaAlias.paths.userData, a.paths.userData);
  assert.equal(viaAlias.api.getStarterProfile().projectPath, await fs.realpath(f.kitA));
});
