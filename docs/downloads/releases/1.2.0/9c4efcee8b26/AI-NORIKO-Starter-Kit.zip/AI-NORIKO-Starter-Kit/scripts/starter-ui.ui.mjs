import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';

// Optional integration suite. Run after npm run build, with Playwright supplied
// by the test environment. Isolated browser, fake bridge, external traffic denied.
// Never launches the installed app, real AI processes, or authenticated services.
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.NORIKO_PLAYWRIGHT_PATH || 'playwright');
const root = fileURLToPath(new URL('..', import.meta.url));
const prompts = JSON.parse(await fs.readFile(path.join(root, 'course/prompts.json'), 'utf8')).prompts;
const dist = path.join(root, 'dist');
const server = http.createServer(async (req, res) => {
  const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  const file = path.resolve(dist, `.${pathname === '/' ? '/index.html' : pathname}`);
  if (!file.startsWith(`${dist}${path.sep}`)) { res.writeHead(403); res.end(); return; }
  try {
    const body = await fs.readFile(file);
    const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.png': 'image/png' };
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
    res.end(body);
  } catch { res.writeHead(404); res.end(); }
});
await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
const origin = `http://127.0.0.1:${server.address().port}`;
function fixture({ connected }) {
  const calls = { ask: [], job: [], terminal: [], note: [], search: [], day: [], unexpected: [] };
  let failure = '';
  let revision = 1;
  const dateKey = () => new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Tokyo', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  const state = JSON.parse(localStorage.getItem('offline-fixture-state') || 'null') || {
    tasks: [], projects: [], revenue: [], cameras: [], cameraPackVersion: 1,
    preferences: { onboardingCompleted: true, userName: '架空ユーザー', assistantName: 'NORIKO',
      autoSpeak: false, voiceMuted: true, voiceVolume: 0, morningReportEnabled: false, revenueEnabled: false,
      freeMode: true, localAIModel: 'fake', obsidianKnowledgePath: '/virtual-vault', shortcut: '' },
  };
  const status = { configured: connected, connected, tasksWritable: connected, email: 'fake@example.test' };
  const knowledge = { configured: true, available: true, path: '/virtual-vault', noteCount: 1, checkedAt: '2026-09-18' };
  const agents = { codex: { installed: true, loggedIn: true }, claude: { installed: true, loggedIn: true }, defaultWorkspacePath: '/virtual-workspaces', checkedAt: '' };
  const fail = () => { if (failure) throw new Error(failure); };
  const bridge = {
    getState: async () => state,
    getStarterProfile: async () => ({ instanceId: 'fixture-instance-id', projectPath: '/virtual-project', userDataPath: '/virtual-profile', sessionDataPath: '/virtual-session', knowledgePath: '/virtual-vault', agentWorkspacePath: '/virtual-workspaces' }),
    saveState: async (next) => { localStorage.setItem('offline-fixture-state', JSON.stringify(next)); return { ok: true }; },
    getConfigStatus: async () => ({ openai: false, fish: false, fishVoice: false, youtube: false, googleClient: connected }),
    getGoogleStatus: async () => status,
    getLocalStatus: async () => ({ ollama: true, model: true, whisper: false, modelName: 'fake' }),
    getKnowledgeStatus: async () => knowledge,
    searchKnowledge: async (query) => { calls.search.push(query); return { query, status: knowledge, sources: [{ title: '架空の構造化思考', relativePath: '架空サンプル/構造化思考.md', excerpt: '目的と対象者を分ける', score: 1 }] }; },
    getAgentStatus: async () => agents,
    listAgentJobs: async () => [],
    onAssistantFocus: () => () => {}, onAgentJobUpdated: () => () => {},
    showNotification: async () => ({ ok: true }),
    askAI: async (request) => { calls.ask.push(request); return { text: `回答${calls.ask.length}：先に対象者と目的を決めましょう。`, knowledgeSources: [{ relativePath: '架空サンプル.md' }] }; },
    startAgentJob: async (request) => { calls.job.push(request); return { ...request, id: 'fake-job', projectPath: '/virtual-workspaces/test', status: 'running', createdAt: new Date().toISOString() }; },
    openAgentTerminal: async (request) => { calls.terminal.push(request); return { ok: true, projectPath: '/virtual-workspaces/test', requestPath: '/virtual-workspaces/test/REQUEST.md' }; },
    saveKnowledge: async (request) => { calls.note.push(request); return { ok: true, title: request.title, path: '/virtual-vault/AI-NORIKO-Records/test.md', relativePath: 'AI-NORIKO-Records/test.md', savedAt: new Date().toISOString() }; },
    syncGoogleToday: async (date = dateKey()) => { calls.day.push(date); fail(); return { email: status.email, date, syncedAt: new Date().toISOString(), events: [{ id: date, title: `${date}の架空予定v${revision}`, start: `${date}T10:00:00+09:00`, end: `${date}T11:00:00+09:00`, allDay: false }], tasks: [] }; },
    syncGoogleWeek: async (date = dateKey()) => { fail(); return { email: status.email, startDate: date, endDate: date, events: [], tasks: [], syncedAt: new Date().toISOString() }; },
    listGoogleTasks: async () => { fail(); return { email: status.email, tasks: [], syncedAt: new Date().toISOString() }; },
    connectGoogle: async () => { failure = ''; return { status: { ...status, reauthRequired: false } }; },
    disconnectGoogle: async () => ({ configured: true, connected: false, tasksWritable: false }),
  };
  window.hayato = new Proxy(bridge, { get(target, key) {
    if (key in target) return target[key];
    return () => { calls.unexpected.push(String(key)); throw new Error(`Unexpected bridge action: ${String(key)}`); };
  } });
  window.testFixture = { calls, fail: (message) => { failure = message; }, revision: (value) => { revision = value; } };
}
async function eventually(check, message) {
  const deadline = Date.now() + 5000;
  do { if (await check()) return; await delay(20); } while (Date.now() < deadline);
  assert.fail(message);
}
let browser;
let passed = 0;
try {
  browser = await chromium.launch({ headless: true, channel: process.env.NORIKO_TEST_BROWSER_CHANNEL || undefined });
  async function scenario(name, fn, connected = false, start = '2026-09-18T12:00:00+09:00') {
    const context = await browser.newContext({ viewport: { width: 1360, height: 1000 }, timezoneId: 'Asia/Tokyo', serviceWorkers: 'block' });
    const blocked = [], errors = [];
    await context.route('**/*', route => {
      if (new URL(route.request().url()).origin === origin) return route.continue();
      blocked.push(route.request().url()); return route.abort();
    });
    await context.addInitScript(fixture, { connected });
    const page = await context.newPage();
    page.setDefaultTimeout(5000);
    page.on('pageerror', error => errors.push(error.message));
    await page.clock.install({ time: new Date(start) });
    await page.clock.pauseAt(new Date(start));
    try {
      await page.goto(origin);
      await page.getByLabel('NORIKOへのメッセージ').waitFor();
      await fn(page);
      assert.deepEqual(errors, [], `${name}: browser exceptions`);
      assert.deepEqual(blocked, [], `${name}: external requests`);
      assert.deepEqual(await page.evaluate(() => window.testFixture.calls.unexpected), [], `${name}: unmocked bridge calls`);
      if (process.env.NORIKO_UI_EVIDENCE_DIR) {
        await fs.mkdir(process.env.NORIKO_UI_EVIDENCE_DIR, { recursive: true });
        await page.screenshot({ path: path.join(process.env.NORIKO_UI_EVIDENCE_DIR, `starter-ui-${passed + 1}.png`), fullPage: true });
      }
      console.log(`PASS ${name}`); passed += 1;
    } finally { await context.close(); }
  }
  const nav = (page, name) => page.locator('nav button').filter({ hasText: name }).click();
  async function send(page, text) {
    await nav(page, '司令室');
    const before = await page.locator('.chat-line.assistant').last().textContent().catch(() => '');
    await page.getByLabel('NORIKOへのメッセージ').fill(text);
    await page.getByRole('button', { name: '送信', exact: true }).click();
    await eventually(async () => {
      if (await page.getByRole('dialog').count()) return true;
      if (!await page.locator('.chat-line.assistant').count()) await nav(page, '司令室');
      return await page.locator('.chat-line.assistant').last().textContent() !== before;
    }, 'command completed');
  }
  await scenario('Googleなしの手動タスク追加・完了・再読み込み後の保持', async page => {
    await nav(page, 'タスク');
    await page.getByLabel('手動タスク名', { exact: true }).fill('練習：説明書を読む');
    await page.getByRole('button', { name: '端末内に追加' }).click();
    const row = page.locator('.local-manual-tasks .task-row').filter({ hasText: '練習：説明書を読む' });
    await row.locator('button').click();
    await eventually(() => row.getAttribute('class').then(value => value.includes('is-complete')), 'task completed');
    await page.reload();
    await nav(page, 'タスク');
    assert.match(await row.getAttribute('class'), /is-complete/);
    assert.equal(await page.evaluate(() => window.testFixture.calls.day.length), 0);
  });
  await scenario('P06/P11全文は相談へ・追加質問に会話を渡す・新規相談で履歴クリア', async page => {
    await send(page, prompts.find(p => p.id === 'P06').text);
    await send(page, '対象者は初心者です。予算は5万円です。');
    await send(page, prompts.find(p => p.id === 'P11').text);
    const calls = await page.evaluate(() => window.testFixture.calls);
    assert.equal(calls.ask.length, 3);
    assert.equal(calls.job.length + calls.terminal.length, 0);
    assert(calls.ask[1].history.some(item => item.role === 'user' && item.content.includes('相談です')));
    assert(calls.ask[2].history.some(item => item.content.includes('予算は5万円')));
    await page.getByRole('button', { name: '新しい相談', exact: true }).click();
    await send(page, '相談です。別の企画を考えたいです。');
    assert.deepEqual(await page.evaluate(() => window.testFixture.calls.ask.at(-1).history), []);
  });
  await scenario('Codex起動は確認前ゼロ・キャンセルゼロ・会話を承認後引継ぎ', async page => {
    await send(page, '相談です。初心者向け講座の企画を考えたいです。');
    await send(page, 'Codexを開いて');
    assert.equal(await page.evaluate(() => window.testFixture.calls.terminal.length), 0);
    assert.match(await page.getByLabel('引き継ぐ会話（不要な個人情報は削除できます）').inputValue(), /初心者向け講座/);
    await page.getByRole('button', { name: 'キャンセル', exact: true }).click();
    assert.equal(await page.evaluate(() => window.testFixture.calls.terminal.length), 0);
    await send(page, 'Codexを開いて');
    await page.getByRole('button', { name: '内容を確認して開始' }).click();
    await eventually(() => page.evaluate(() => window.testFixture.calls.terminal.length === 1), 'terminal confirmed');
    const request = await page.evaluate(() => window.testFixture.calls.terminal[0]);
    assert.equal(request.confirmed, true); assert.match(request.conversation, /初心者向け講座/);
  });
  await scenario('Claude制作も確認後のみ・編集した引継ぎ内容を渡す', async page => {
    await send(page, 'Claude Codeで講座ページを作って');
    assert.equal(await page.evaluate(() => window.testFixture.calls.job.length), 0);
    await page.getByLabel('引き継ぐ会話（不要な個人情報は削除できます）').fill('');
    await page.getByRole('button', { name: '内容を確認して開始' }).click();
    await eventually(() => page.evaluate(() => window.testFixture.calls.job.length === 1), 'job confirmed');
    const request = await page.evaluate(() => window.testFixture.calls.job[0]);
    assert.equal(request.confirmed, true); assert.equal(request.provider, 'claude'); assert.equal(request.conversation, '');
  });
  await scenario('AI作業フォームでも承認前は実行しない', async page => {
    await nav(page, 'AI作業');
    await page.getByLabel('作業名', { exact: true }).fill('架空講座の企画');
    await page.getByLabel('依頼内容', { exact: true }).fill('架空の初心者講座を企画してください。');
    await page.getByRole('button', { name: 'Codexへ依頼する', exact: true }).click();
    await page.getByRole('dialog').waitFor();
    assert.equal(await page.evaluate(() => window.testFixture.calls.job.length), 0);
    await page.getByRole('button', { name: 'キャンセル', exact: true }).click();
    assert.equal(await page.evaluate(() => window.testFixture.calls.job.length), 0);
  });
  await scenario('Obsidian記録はプレビュー後保存・本人とAIを区別し実パスを表示', async page => {
    await send(page, '相談です。企画では対象者を先に決めます。');
    await send(page, '今の相談をObsidianに記録して');
    assert.equal(await page.evaluate(() => window.testFixture.calls.note.length), 0);
    assert.match(await page.getByLabel('本人の発言・事実').inputValue(), /対象者/);
    assert.match(await page.getByLabel('AIの回答・提案（未承認）').inputValue(), /回答1/);
    await page.getByRole('button', { name: '内容を確認して保存' }).click();
    await eventually(() => page.evaluate(() => window.testFixture.calls.note.length === 1), 'note confirmed');
    assert.equal(await page.evaluate(() => window.testFixture.calls.note[0].confirmed), true);
    await eventually(() => page.locator('.chat-line.assistant').last().textContent().then(text => text.includes('/virtual-vault/AI-NORIKO-Records/test.md')), 'saved note path shown');
  });
  await scenario('設定で環境ID・本体フォルダ・分離された保存先を確認できる', async page => {
    await nav(page, '設定');
    const panel = page.locator('.instance-profile-panel');
    await panel.getByRole('heading', { name: 'このAI NORIKOの保存先', exact: true }).waitFor();
    await panel.getByText('fixture-instance-id', { exact: true }).waitFor();
    assert.deepEqual(await panel.locator('dt').allTextContents(), [
      '環境ID', '本体フォルダ', '設定・タスク・認証', '標準ナレッジ', 'AI作業の保存先',
    ]);
    assert.deepEqual(await panel.locator('dd').allTextContents(), [
      'fixture-instance-id', '/virtual-project', '/virtual-profile', '/virtual-vault', '/virtual-workspaces',
    ]);
    assert.match(await panel.textContent(), /旧版の設定は自動で移しません/);
    assert.match(await panel.textContent(), /同じGoogleアカウントや同じObsidianフォルダ/);
  });
  await scenario('NORIKOナレッジ検索語を指定し参照ファイルを確認できる', async page => {
    await nav(page, '設定');
    await page.getByLabel('検索テストの言葉').fill('構造化思考');
    await page.getByRole('button', { name: 'ナレッジ検索をテスト', exact: true }).click();
    await eventually(() => page.locator('.knowledge-settings-panel [role="status"]').textContent().then(text => text.includes('架空サンプル/構造化思考.md')), 'search result path visible');
    assert.deepEqual(await page.evaluate(() => window.testFixture.calls.search), ['構造化思考']);
  });
  await scenario('明日閲覧後も司令室は今日・同期失敗で古い予定を返さない', async page => {
    await eventually(() => page.locator('.schedule-preview').textContent().then(text => text.includes('2026-09-18の架空予定')), 'today loaded');
    await send(page, '明日の予定を教えて');
    await nav(page, '司令室');
    assert.match(await page.locator('.schedule-preview').textContent(), /2026-09-18の架空予定/);
    await page.evaluate(() => window.testFixture.fail('offline'));
    await send(page, '今日の予定を教えて');
    await nav(page, '司令室');
    assert.match(await page.locator('.chat-line.assistant').last().textContent(), /未確認/);
    assert.doesNotMatch(await page.locator('.schedule-preview').textContent(), /架空予定/);
  }, true);
  await scenario('日付またぎ・失敗後再試行・フォーカス復帰の再同期', async page => {
    await eventually(() => page.evaluate(() => window.testFixture.calls.day.includes('2026-09-18')), 'old day loaded');
    await page.evaluate(() => window.testFixture.fail('offline'));
    await page.clock.runFor(31_000);
    await eventually(() => page.evaluate(() => window.testFixture.calls.day.includes('2026-09-19')), 'midnight requested new day');
    assert.doesNotMatch(await page.locator('.schedule-preview').textContent(), /2026-09-18の架空予定/);
    await page.evaluate(() => window.testFixture.fail(''));
    await page.clock.runFor(75_000);
    await eventually(() => page.locator('.schedule-preview').textContent().then(text => text.includes('2026-09-19の架空予定v1')), 'failed day retried');
    await page.evaluate(() => { window.testFixture.revision(2); window.dispatchEvent(new Event('focus')); });
    await eventually(() => page.locator('.schedule-preview').textContent().then(text => text.includes('v2')), 'resume refreshed');
  }, true, '2026-09-18T23:59:30+09:00');
  await scenario('認証切れを未確認にして再接続バナーを保持', async page => {
    await page.evaluate(() => { window.testFixture.fail('GOOGLE_REAUTH_REQUIRED'); window.dispatchEvent(new Event('focus')); });
    await page.getByRole('button', { name: 'Googleを再接続', exact: true }).waitFor();
    await page.clock.runFor(10_000);
    assert.equal(await page.locator('.google-reauth-banner').count(), 1);
    assert.doesNotMatch(await page.locator('.schedule-preview').textContent(), /架空予定/);
    await page.getByRole('button', { name: 'Googleを再接続', exact: true }).click();
    await eventually(() => page.locator('.schedule-preview').textContent().then(text => text.includes('2026-09-18の架空予定')), 'reconnected');
  }, true);
  console.log(`${passed} offline UI scenarios passed; no real accounts, paid APIs, or installed app accessed.`);
} finally {
  await browser?.close();
  await new Promise(resolve => server.close(resolve));
}
