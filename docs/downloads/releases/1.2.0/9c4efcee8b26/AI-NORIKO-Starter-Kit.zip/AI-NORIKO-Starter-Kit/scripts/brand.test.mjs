import assert from 'node:assert/strict';
import path from 'node:path';
import test from 'node:test';
import instanceProfiles from '../electron/instance-profile.cjs';

const { createInstanceProfile } = instanceProfiles;

const fixtures = [
  {
    platform: 'darwin',
    pathApi: path.posix,
    kitRoot: '/example/Course/AI-NORIKO-Starter-Kit',
    appDataPath: '/example/Application Support',
    documentsPath: '/example/Documents',
    instanceId: 'c5faa8b82c3df7d9703a',
  },
  {
    platform: 'linux',
    pathApi: path.posix,
    kitRoot: '/example/Course/AI-NORIKO-Starter-Kit',
    appDataPath: '/example/.config',
    documentsPath: '/example/Documents',
    instanceId: 'c5faa8b82c3df7d9703a',
  },
  {
    platform: 'win32',
    pathApi: path.win32,
    kitRoot: 'c:\\course\\ai-noriko-starter-kit',
    appDataPath: 'C:\\Example\\AppData\\Roaming',
    documentsPath: 'C:\\Example\\Documents',
    instanceId: '4a1adfa3874bff626304',
  },
];

for (const fixture of fixtures) {
  test(`${fixture.platform}: branded storage is scoped to the kit instance`, () => {
    const { pathApi, kitRoot, appDataPath, documentsPath, instanceId } = fixture;
    const profile = createInstanceProfile(fixture);
    const userDataPath = pathApi.join(appDataPath, 'AI NORIKO Starter', 'instances', instanceId);
    const documentsRoot = pathApi.join(documentsPath, 'AI-NORIKO-Instances', instanceId);

    assert.deepEqual(profile, {
      instanceId,
      kitRoot,
      userDataPath,
      sessionDataPath: pathApi.join(userDataPath, 'session'),
      knowledgePath: pathApi.join(documentsRoot, 'Knowledge'),
      agentWorkspacePath: pathApi.join(documentsRoot, 'Workspaces'),
    });
    assert.match(profile.instanceId, /^[a-f0-9]{20}$/);
    for (const oldDirectory of ['AI NORIKO Starter', 'AI HAYATO Starter', 'ai-hayato-starter-kit']) {
      assert.notEqual(profile.userDataPath, pathApi.join(appDataPath, oldDirectory));
    }
    assert.notEqual(profile.knowledgePath, pathApi.join(documentsPath, 'AI-NORIKO-Knowledge'));
    assert.notEqual(profile.agentWorkspacePath, pathApi.join(documentsPath, 'AI-NORIKO-Workspaces'));
  });

  test(`${fixture.platform}: restarting the same kit preserves its profile`, () => {
    const first = createInstanceProfile(fixture);
    const second = createInstanceProfile({ ...fixture });
    assert.deepEqual(second, first);

    const normalizedAlias = createInstanceProfile({
      ...fixture,
      kitRoot: `${fixture.kitRoot}${fixture.pathApi.sep}child${fixture.pathApi.sep}..${fixture.pathApi.sep}`,
    });
    assert.deepEqual(normalizedAlias, first);
  });

  test(`${fixture.platform}: a different kit folder receives separate storage`, () => {
    const original = createInstanceProfile(fixture);
    const copy = createInstanceProfile({ ...fixture, kitRoot: `${fixture.kitRoot}-copy` });
    for (const key of ['instanceId', 'userDataPath', 'sessionDataPath', 'knowledgePath', 'agentWorkspacePath']) {
      assert.notEqual(copy[key], original[key], key);
    }
  });

  test(`${fixture.platform}: storage roots do not change the kit identity`, () => {
    const original = createInstanceProfile(fixture);
    const relocatedStorage = createInstanceProfile({
      ...fixture,
      appDataPath: fixture.pathApi.join(fixture.appDataPath, 'alternate'),
      documentsPath: fixture.pathApi.join(fixture.documentsPath, 'alternate'),
    });
    assert.equal(relocatedStorage.instanceId, original.instanceId);
    for (const key of ['userDataPath', 'sessionDataPath', 'knowledgePath', 'agentWorkspacePath']) {
      assert.notEqual(relocatedStorage[key], original[key], key);
    }
  });

  test(`${fixture.platform}: relative kit paths are rejected`, () => {
    assert.throws(() => createInstanceProfile({ ...fixture, kitRoot: 'AI-NORIKO-Starter-Kit' }));
  });
}

test('Windows path spelling and case normalize to the same instance', () => {
  const fixture = fixtures.find(({ platform }) => platform === 'win32');
  const canonical = createInstanceProfile(fixture);
  const alias = createInstanceProfile({
    ...fixture,
    kitRoot: 'C:/Course/unused/../AI-NORIKO-Starter-Kit/',
  });
  assert.equal(alias.instanceId, canonical.instanceId);
  for (const key of ['userDataPath', 'sessionDataPath', 'knowledgePath', 'agentWorkspacePath']) {
    assert.equal(alias[key], canonical[key], key);
  }
});

test('POSIX kit paths retain case-sensitive identity', () => {
  for (const fixture of fixtures.filter(({ platform }) => platform !== 'win32')) {
    const original = createInstanceProfile(fixture);
    const differentCase = createInstanceProfile({ ...fixture, kitRoot: fixture.kitRoot.toLowerCase() });
    assert.notEqual(differentCase.instanceId, original.instanceId);
  }
});

test('omitting platform uses the current operating system', () => {
  const args = {
    kitRoot: path.resolve('example', 'AI-NORIKO-Starter-Kit'),
    appDataPath: path.resolve('example', 'AppData'),
    documentsPath: path.resolve('example', 'Documents'),
  };
  assert.deepEqual(createInstanceProfile(args), createInstanceProfile({ ...args, platform: process.platform }));
});
