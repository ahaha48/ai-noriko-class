import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import profiles from '../electron/instance-profile.cjs';

// Optional real-Electron integration check: node scripts/instance-electron.ui.mjs
// No BrowserWindow, user profile, OS credential lookup, account or network call.
// Temporary fixture code only tests Electron's actual path and process-lock APIs;
// instance-profile.test.mjs separately executes the complete production backend.
const require = createRequire(import.meta.url);
const electronExecutable = require('electron');
const modulePath = fileURLToPath(new URL('../electron/instance-profile.cjs', import.meta.url));
const temporary = await fs.realpath(await fs.mkdtemp(path.join(os.tmpdir(), 'noriko-electron-profile-')));
const fixturePath = path.join(temporary, 'fixture.cjs');
const appDataPath = path.join(temporary, 'AppData');
const documentsPath = path.join(temporary, 'Documents');
const children = new Set();
const marker = 'NORIKO_PROFILE_TEST ';
const fixtureSource = String.raw`
const { app, session } = require('electron');
const fs = require('node:fs');
const path = require('node:path');
const [modulePath, temporary, suppliedRoot] = process.argv.slice(2);
const { createInstanceProfile } = require(modulePath);
const profile = createInstanceProfile({
  kitRoot: fs.realpathSync.native(suppliedRoot),
  appDataPath: path.join(temporary, 'AppData'),
  documentsPath: path.join(temporary, 'Documents'),
});
for (const name of ['temp', 'crashDumps', 'logs']) {
  const directory = path.join(profile.userDataPath, name);
  fs.mkdirSync(directory, { recursive: true });
  if (name === 'logs') app.setAppLogsPath(directory);
  else app.setPath(name, directory);
}
fs.mkdirSync(profile.sessionDataPath, { recursive: true });
app.setPath('appData', path.join(temporary, 'AppData'));
app.setPath('documents', path.join(temporary, 'Documents'));
app.setPath('userData', profile.userDataPath);
app.setPath('sessionData', profile.sessionDataPath);
app.setName('AI NORIKO Profile Test');
app.commandLine.appendSwitch('disable-background-networking');
app.commandLine.appendSwitch('use-mock-keychain');
app.disableHardwareAcceleration();
const report = (value) => process.stdout.write('NORIKO_PROFILE_TEST ' + JSON.stringify(value) + '\n');
if (!app.requestSingleInstanceLock()) {
  report({ state: 'duplicate', instanceId: profile.instanceId });
  app.quit();
} else {
  app.whenReady().then(() => {
    app.dock?.hide();
    const storagePath = session.defaultSession.getStoragePath();
    session.defaultSession.webRequest.onBeforeRequest((_request, callback) => callback({ cancel: true }));
    const markerFile = path.join(storagePath, 'fixture-marker.txt');
    const previousMarker = fs.existsSync(markerFile) ? fs.readFileSync(markerFile, 'utf8') : null;
    fs.writeFileSync(markerFile, profile.instanceId, 'utf8');
    report({ state: 'ready', profile, storagePath, previousMarker });
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', (data) => { if (data.includes('quit')) app.quit(); });
    process.stdin.resume();
  }).catch((error) => { report({ state: 'error', message: error.message }); app.exit(1); });
}
`;

async function launch(kitRoot) {
  const profile = profiles.createInstanceProfile({ kitRoot: await fs.realpath(kitRoot), appDataPath, documentsPath });
  await fs.mkdir(profile.userDataPath, { recursive: true });
  const env = { ...process.env };
  delete env.ELECTRON_RUN_AS_NODE;
  const child = spawn(electronExecutable, [
    fixturePath, modulePath, temporary, kitRoot,
    `--user-data-dir=${profile.userDataPath}`, '--use-mock-keychain', '--disable-background-networking',
  ], { env, stdio: ['pipe', 'pipe', 'pipe'] });
  children.add(child);
  let stdout = '', stderr = '';
  const exited = new Promise((resolve) => child.once('exit', (code, signal) => {
    children.delete(child); resolve({ code, signal });
  }));
  child.stderr.on('data', (chunk) => { stderr = (stderr + chunk).slice(-8000); });
  const result = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Electron fixture timed out: ${stderr}`)), 20000);
    const finish = (fn, value) => { clearTimeout(timer); fn(value); };
    child.once('error', (error) => finish(reject, error));
    child.once('exit', (code) => {
      if (!stdout.includes(marker)) finish(reject, new Error(`Electron exited ${code}: ${stderr}`));
    });
    child.stdout.on('data', (chunk) => {
      stdout += chunk.toString('utf8');
      for (const line of stdout.split(/\r?\n/)) {
        if (!line.startsWith(marker)) continue;
        try { finish(resolve, JSON.parse(line.slice(marker.length))); } catch { /* Wait for a complete line. */ }
      }
    });
  });
  return { child, result, exited };
}

async function stop(run) {
  if (!children.has(run.child)) return;
  run.child.stdin.write('quit\n');
  const timer = setTimeout(() => run.child.kill('SIGKILL'), 5000);
  const exit = await run.exited;
  clearTimeout(timer);
  assert.equal(exit.code, 0, `Electron should quit normally (${exit.signal || 'no signal'})`);
}

try {
  await fs.mkdir(appDataPath);
  await fs.mkdir(documentsPath);
  await fs.writeFile(fixturePath, fixtureSource, 'utf8');
  const kitA = path.join(temporary, "キット A ' !");
  const kitB = path.join(temporary, "キット B ' !");
  await fs.mkdir(kitA); await fs.mkdir(kitB);
  const a = await launch(kitA);
  const b = await launch(kitB);
  for (const run of [a, b]) {
    assert.equal(run.result.state, 'ready');
    assert.equal(run.result.previousMarker, null);
    assert.equal(run.result.storagePath, run.result.profile.sessionDataPath);
    assert.ok(run.result.storagePath.startsWith(temporary + path.sep));
  }
  assert.notEqual(a.result.storagePath, b.result.storagePath);
  assert.notEqual(a.result.profile.userDataPath, b.result.profile.userDataPath);
  const duplicate = await launch(kitA);
  assert.equal(duplicate.result.state, 'duplicate');
  assert.equal(duplicate.result.instanceId, a.result.profile.instanceId);
  assert.equal((await duplicate.exited).code, 0);
  await stop(a);
  const restarted = await launch(kitA);
  assert.equal(restarted.result.state, 'ready');
  assert.equal(restarted.result.profile.instanceId, a.result.profile.instanceId);
  assert.equal(restarted.result.storagePath, a.result.storagePath);
  assert.equal(restarted.result.previousMarker, a.result.profile.instanceId);
  assert.equal(await fs.readFile(path.join(b.result.storagePath, 'fixture-marker.txt'), 'utf8'), b.result.profile.instanceId);
  await stop(restarted); await stop(b);
  console.log('PASS real Electron: separate concurrent profiles/session storage; same-folder duplicate rejected; restart retains its own storage.');
} finally {
  await Promise.all([...children].map((child) => new Promise((resolve) => {
    child.once('exit', resolve); child.kill('SIGKILL');
  })));
  await fs.rm(temporary, { recursive: true, force: true });
}
