# 最初にここを読んでください

更新日：2026年9月19日／本体v1.2.0／共通導入・個人活用・企業活用版

このキットは、Mac・Windowsに導入するAI NORIKOの共通の土台です。まず1人で起動・基本操作を確認し、「個人のAI秘書」「社長の判断基準を参照するAI相談役」へ育てます。

企業の社員ログイン、閲覧権限、承認フローは未実装です。会社コースは責任者が架空データで試すところから始めます。社員へそのまま配布しないでください。

## 1. 準備する

1. 最新版の未使用ZIPを展開し、AI-NORIKO-Starter-Kitフォルダを表示します。既存環境を残す場合は別の場所へ展開し、上書きしません。
2. [OpenAI公式アプリ案内](https://learn.chatgpt.com/docs/app)で自分のOSのデスクトップアプリを確認し、ログインしてCodexを選びます。画面名・提供状況が異なる場合は講師に確認します。
3. Codexでこのフォルダをプロジェクトとして開きます。ZIPや親フォルダは選びません。
4. Node.js 24 LTSを準備します（24.14.0で検証。最低条件は22.12.0以上）。未導入なら[公式ページ](https://nodejs.org/en/download)から本人が導入します。Node 20は対象外です。

資料専用の `AI-NORIKO-Learning-Guide` では起動できません。本体フォルダに `package.json` があることも確認します。

本体フォルダの場所ごとに別環境になります。名前・保存場所は初回起動前に決め、その後は安易に移動・名前変更しません。`(1)`付きで別に展開されたフォルダも別環境です。詳しくは [別環境の導入](docs/MULTIPLE_INSTALLS.md) を確認してください。

## 2. Codexへ依頼する

[CODEX_SETUP_PROMPT.md](CODEX_SETUP_PROMPT.md)をコピーし、このフォルダを開いているCodexのタスクに送ります。APIキーや認証JSONの中身はチャットへ貼りません。

## 3. 起動する

- Mac：START-MAC.command
- Windows：START-WINDOWS.bat

OSの警告が出た場合は、内容を講師へ見せます。セキュリティ保護を無効にしないでください。

初回画面で呼び名・秘書名を設定します。音声と朝の報告は最初はオフでも構いません。売上管理は非表示のままです。

作成される標準フォルダ（`<環境ID>` は本体の場所から自動生成される20文字）：

- OSのappData / `AI NORIKO Starter/instances/<環境ID>`：設定・認証等
- Documents（書類）/ `AI-NORIKO-Instances/<環境ID>/Knowledge`：本人のMarkdownナレッジ
- Documents（書類）/ `AI-NORIKO-Instances/<環境ID>/Workspaces`：明示的に依頼したAI作業

同じ本体フォルダからの再起動では保存が残ります。v1.1以前の共有設定は自動取り込みせず、旧データは残したまま新規環境になります。移行したい場合は講師へ確認してください。個人用AI NORIKOは変更しません。

## 4. できた状態

最小の合格は「起動し、Google未接続のままローカルの手動タスクを1件作成・完了できた」です。

自由な相談には会話AIが必要です。外部APIを使わない場合はOllamaとモデルを準備します。さらにサンプルのナレッジ1件を保存し、相談で参照・追加質問・確認付き記録ができれば共通の相談基盤まで完了です。

「のりこの考え方」も使いたい人は、共通導入後に [NORIKOナレッジの導入](docs/NORIKO_KNOWLEDGE_SETUP.md) とP21へ進みます。思考パックは主催者から提供される別教材です。キャラクターが表示されても、思考ノートの導入は別です。現パックは本人確認用の先行版なので提供条件を確認してください。

## 5. 次に読む

1. [共通導入の詳細](docs/COURSE_GUIDE.md)
2. [送信先付きプロンプト集](docs/PROMPTS.md)
3. [機能と実装状況](docs/FEATURE_CATALOG.md)
4. [個人のAI秘書](docs/PERSONAL_PLAYBOOK.md)
5. [会社のAI相談役](docs/TEAM_PLAYBOOK.md)
6. [導入支援のサービス設計](docs/SERVICE_DESIGN.md)
7. [NORIKOナレッジの導入・確認・戻し方](docs/NORIKO_KNOWLEDGE_SETUP.md)
8. [別環境の導入・フォルダ移動時の注意](docs/MULTIPLE_INSTALLS.md)

機能を変える依頼は、キットを開いているCodexへ送ります。NORIKOへの普段の相談だけで、機能が自動追加されるわけではありません。
