#!/bin/zsh
set -e

cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.jsのLTS版が必要です。https://nodejs.org/ からインストールしてください。"
  read "?Enterキーで閉じます。"
  exit 1
fi

npm run setup
if ! node -e "require.resolve('vite'); require.resolve('electron')" >/dev/null 2>&1; then
  npm ci
fi
npm run start
