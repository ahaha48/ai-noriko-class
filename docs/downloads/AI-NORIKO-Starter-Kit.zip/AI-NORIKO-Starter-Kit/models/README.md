# ローカル音声認識モデル

音声モデルはサイズが大きいため同梱していません。whisper.cppを使う場合は `ggml-small.bin` をこのフォルダへ置くか、環境変数 `NORIKO_WHISPER_MODEL` で保存先を指定します。
