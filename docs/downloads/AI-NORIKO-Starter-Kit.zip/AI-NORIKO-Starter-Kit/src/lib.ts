import type { AppState, RevenueEntry } from "./types";

export function uid(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export function japanToday() {
  return new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

export function formatCurrency(amount: number) {
  return new Intl.NumberFormat("ja-JP", {
    style: "currency",
    currency: "JPY",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatShortDate(value?: string) {
  if (!value) return "期限なし";
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("ja-JP", { month: "short", day: "numeric" }).format(date);
}

export function extractYouTubeId(url: string) {
  const trimmed = url.trim();
  const patterns = [
    /youtu\.be\/([\w-]{6,})/,
    /[?&]v=([\w-]{6,})/,
    /youtube\.com\/(?:embed|live|shorts)\/([\w-]{6,})/,
  ];
  for (const pattern of patterns) {
    const match = trimmed.match(pattern);
    if (match) return match[1];
  }
  return "";
}

function splitCsvLine(line: string, delimiter: string) {
  const values: string[] = [];
  let current = "";
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (character === '"') {
      if (quoted && line[index + 1] === '"') {
        current += '"';
        index += 1;
      } else quoted = !quoted;
    } else if (character === delimiter && !quoted) {
      values.push(current.trim());
      current = "";
    } else current += character;
  }
  values.push(current.trim());
  return values;
}

function normalizeDate(value: string) {
  const trimmed = value.trim();
  if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(trimmed)) {
    const [year, month, day] = trimmed.split("-");
    return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
  }
  if (/^\d{4}[\/.]\d{1,2}[\/.]\d{1,2}$/.test(trimmed)) {
    const [year, month, day] = trimmed.split(/[\/.]/);
    return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
  }
  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) return japanToday();
  return parsed.toISOString().slice(0, 10);
}

export function parseRevenueCsv(content: string, fallbackSource: string): RevenueEntry[] {
  const lines = content.replace(/^\uFEFF/, "").split(/\r?\n/).filter((line) => line.trim());
  if (lines.length === 0) return [];
  const delimiter = lines[0].includes("\t") ? "\t" : ",";
  const first = splitCsvLine(lines[0], delimiter).map((value) => value.toLowerCase());
  const hasHeader = first.some((value) => /date|日付|amount|金額|売上|label|項目/.test(value));
  const headers = hasHeader ? first : ["date", "label", "amount", "source"];
  const dataLines = hasHeader ? lines.slice(1) : lines;
  const findIndex = (patterns: RegExp[], fallback: number) => {
    const index = headers.findIndex((header) => patterns.some((pattern) => pattern.test(header)));
    return index >= 0 ? index : fallback;
  };
  const dateIndex = findIndex([/date/, /日付/, /日時/], 0);
  const labelIndex = findIndex([/label/, /item/, /項目/, /商品/, /内容/], 1);
  const amountIndex = findIndex([/amount/, /revenue/, /sales/, /金額/, /売上/], 2);
  const sourceIndex = findIndex([/source/, /channel/, /媒体/, /区分/], 3);

  return dataLines
    .map((line, index) => {
      const values = splitCsvLine(line, delimiter);
      const amount = Number((values[amountIndex] || "").replace(/[¥￥,\s]/g, ""));
      if (!Number.isFinite(amount)) return null;
      return {
        id: uid(`csv-${index}`),
        date: normalizeDate(values[dateIndex] || japanToday()),
        label: values[labelIndex] || "売上",
        amount,
        source: values[sourceIndex] || fallbackSource.replace(/\.(csv|tsv)$/i, ""),
      } satisfies RevenueEntry;
    })
    .filter((entry): entry is RevenueEntry => Boolean(entry));
}

export function dailyRevenue(state: AppState, date = japanToday()) {
  return state.revenue
    .filter((entry) => entry.date === date)
    .reduce((total, entry) => total + entry.amount, 0);
}

export function monthlyRevenue(state: AppState, month = japanToday().slice(0, 7)) {
  return state.revenue
    .filter((entry) => entry.date.startsWith(`${month}-`))
    .reduce((total, entry) => total + entry.amount, 0);
}

export function buildBriefing(state: AppState) {
  const today = japanToday();
  const incomplete = state.tasks.filter((task) => !task.completed);
  const dueToday = incomplete.filter((task) => task.dueDate === today);
  const revenue = dailyRevenue(state, today);
  const taskSummary = dueToday.length
    ? `本日の未完了タスクは${dueToday.length}件です。最優先は「${dueToday[0].title}」です。`
    : incomplete.length
      ? `未完了タスクは${incomplete.length}件あります。本日期限のタスクはありません。`
      : "未完了タスクはありません。";
  const revenueSummary = state.preferences.revenueEnabled
    ? state.revenue.length
      ? `本日の登録売上は${formatCurrency(revenue)}です。`
      : "売上管理は有効ですが、データはまだ登録されていません。"
    : "";
  const cameraSummary = state.cameras.length
    ? `ライブカメラは${state.cameras.length}地点を呼び出せます。`
    : "ライブカメラはまだ登録されていません。";
  return `${taskSummary}${revenueSummary}${cameraSummary}`;
}
