export type Priority = "high" | "medium" | "low";
export type AssistantMode = "idle" | "listening" | "thinking" | "speaking";
export type ViewName = "dashboard" | "schedule" | "week" | "tasks" | "revenue" | "cameras" | "agents" | "settings";

export type AgentProvider = "codex" | "claude";
export type AgentJobMode = "brainstorm" | "implement";
export type AgentJobStatus = "queued" | "running" | "completed" | "failed" | "cancelled";

export interface AgentProviderStatus {
  installed: boolean;
  loggedIn: boolean;
  version?: string;
  error?: string;
}

export interface AgentAvailability {
  codex: AgentProviderStatus;
  claude: AgentProviderStatus;
  defaultWorkspacePath: string;
  checkedAt: string;
}

export interface AgentJob {
  id: string;
  provider: AgentProvider;
  mode: AgentJobMode;
  title: string;
  prompt: string;
  projectPath: string;
  requestPath?: string;
  status: AgentJobStatus;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  outputPath?: string;
  summary?: string;
  error?: string;
  logTail?: string;
}

export interface AgentStartRequest {
  confirmed: true;
  provider: AgentProvider;
  mode: AgentJobMode;
  title: string;
  prompt: string;
  conversation?: string;
  projectPath?: string;
}

export interface ConversationMessage {
  role: "user" | "assistant";
  content: string;
}

export interface KnowledgeSaveRequest {
  confirmed: true;
  title?: string;
  userText: string;
  assistantText?: string;
}

export interface KnowledgeSaveResult {
  ok: true;
  path: string;
  relativePath: string;
  title: string;
  savedAt: string;
}

export interface TaskItem {
  id: string;
  title: string;
  completed: boolean;
  priority: Priority;
  dueDate?: string;
  source: "manual" | "project";
  projectName?: string;
  sourceFile?: string;
}

export interface ProjectInfo {
  id: string;
  name: string;
  path: string;
  gitSummary: string;
  scannedAt: string;
  tasks: TaskItem[];
}

export interface RevenueEntry {
  id: string;
  date: string;
  label: string;
  amount: number;
  source: string;
}

export interface CameraItem {
  id: string;
  name: string;
  location: string;
  url: string;
  videoId: string;
  channelTitle?: string;
}

export interface Preferences {
  onboardingCompleted: boolean;
  userName: string;
  assistantName: string;
  openAIModel: string;
  localAIModel: string;
  freeMode: boolean;
  fishVoiceEnabled: boolean;
  fishVoiceModel: "s2.1-pro-free" | "s2-pro";
  autoSpeak: boolean;
  voiceVolume: number;
  voiceMuted: boolean;
  morningReportEnabled: boolean;
  morningReportTime: string;
  revenueEnabled: boolean;
  lastMorningReportDate?: string;
  lastDeadlineRiskAlertKey?: string;
  obsidianKnowledgePath: string;
  shortcut: string;
}

export interface ObsidianKnowledgeStatus {
  configured: boolean;
  available: boolean;
  path: string;
  noteCount: number;
  checkedAt: string;
  error?: string;
}

export interface ObsidianKnowledgeSource {
  title: string;
  relativePath: string;
  score: number;
  excerpt: string;
}

export interface ObsidianKnowledgeSearchResult {
  query: string;
  status: ObsidianKnowledgeStatus;
  sources: ObsidianKnowledgeSource[];
}

export interface AppState {
  tasks: TaskItem[];
  projects: ProjectInfo[];
  revenue: RevenueEntry[];
  cameras: CameraItem[];
  cameraPackVersion: number;
  preferences: Preferences;
}

export interface SecretStatus {
  openai: boolean;
  fish: boolean;
  fishVoice: boolean;
  youtube: boolean;
  googleClient: boolean;
}

export interface FishVoiceModel {
  id: string;
  title: string;
  state: string;
  visibility: "public" | "unlist" | "private" | string;
  updatedAt?: string;
}

export interface LocalSystemStatus {
  ollama: boolean;
  model: boolean;
  whisper: boolean;
  modelName: string;
}

export interface GoogleAccountStatus {
  configured: boolean;
  connected: boolean;
  reauthRequired?: boolean;
  tasksWritable: boolean;
  email?: string;
}

export interface GoogleCalendarEvent {
  id: string;
  title: string;
  start: string;
  end: string;
  allDay: boolean;
  location?: string;
  url?: string;
  meetUrl?: string;
  calendarName?: string;
}

export interface GoogleTaskItem {
  id: string;
  title: string;
  due?: string;
  overdue: boolean;
  notes?: string;
  taskListId: string;
  listTitle: string;
  url?: string;
}

export interface GoogleTodaySchedule {
  email: string;
  date: string;
  events: GoogleCalendarEvent[];
  tasks: GoogleTaskItem[];
  syncedAt: string;
}

export interface GoogleTaskCollection {
  email: string;
  tasks: GoogleTaskItem[];
  syncedAt: string;
}

export interface GoogleWeekSchedule {
  email: string;
  startDate: string;
  endDate: string;
  calendarCount: number;
  events: GoogleCalendarEvent[];
  tasks: GoogleTaskItem[];
  syncedAt: string;
}

export interface GoogleTaskCreateRequest {
  title: string;
  due?: string;
  notes?: string;
  listTitle?: string;
}

export interface GoogleCalendarSearchRequest {
  query?: string;
  startDate: string;
  endDate: string;
  order?: "asc" | "desc" | "nearest";
  limit?: number;
}

export interface GoogleCalendarSearchResult {
  email: string;
  query: string;
  startDate: string;
  endDate: string;
  calendarCount: number;
  events: GoogleCalendarEvent[];
  syncedAt: string;
}

export interface YouTubeLiveResult {
  id: string;
  title: string;
  channelTitle: string;
  thumbnail?: string;
  publishedAt: string;
  url: string;
}

export interface ResearchSource {
  title: string;
  url: string;
  kind: "web" | "reference" | "news";
  publishedAt?: string;
  snippet?: string;
  sourceName?: string;
}

export interface ResearchResult {
  query: string;
  summary: string;
  sources: ResearchSource[];
  searchedAt: string;
  provider: "free-local";
}

export interface WeatherResult {
  location: string;
  current: {
    observedAt?: string;
    condition: string;
    temperature?: number;
    apparentTemperature?: number;
    humidity?: number;
    precipitation?: number;
    windSpeed?: number;
  };
  daily: Array<{
    date: string;
    condition: string;
    high?: number;
    low?: number;
    precipitationProbability?: number;
  }>;
  provider: "Open-Meteo";
}

export interface ChatEntry {
  id: string;
  role: "user" | "assistant" | "system";
  text: string;
  createdAt: string;
  sources?: string[];
}
