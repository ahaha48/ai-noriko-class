import type {
  AgentAvailability,
  AgentJob,
  AgentProvider,
  AgentStartRequest,
  AppState,
  ConversationMessage,
  FishVoiceModel,
  GoogleAccountStatus,
  GoogleCalendarSearchRequest,
  GoogleCalendarSearchResult,
  GoogleTaskCollection,
  GoogleTaskCreateRequest,
  GoogleTaskItem,
  GoogleTodaySchedule,
  GoogleWeekSchedule,
  LocalSystemStatus,
  KnowledgeSaveRequest,
  KnowledgeSaveResult,
  ObsidianKnowledgeSearchResult,
  ObsidianKnowledgeStatus,
  ProjectInfo,
  ResearchResult,
  SecretStatus,
  WeatherResult,
  YouTubeLiveResult,
} from "./types";

interface HayatoBridge {
  initializeStarter(): Promise<{
    platform: string;
    platformLabel: string;
    knowledgePath: string;
    agentWorkspacePath: string;
  }>;
  getState(): Promise<AppState>;
  saveState(state: AppState): Promise<{ ok: boolean }>;
  getConfigStatus(): Promise<SecretStatus>;
  getLocalStatus(): Promise<LocalSystemStatus>;
  getKnowledgeStatus(): Promise<ObsidianKnowledgeStatus>;
  selectKnowledgeFolder(): Promise<ObsidianKnowledgeStatus | null>;
  searchKnowledge(query: string): Promise<ObsidianKnowledgeSearchResult>;
  saveKnowledge(request: KnowledgeSaveRequest): Promise<KnowledgeSaveResult>;
  getAgentStatus(): Promise<AgentAvailability>;
  listAgentJobs(): Promise<AgentJob[]>;
  startAgentJob(request: AgentStartRequest): Promise<AgentJob>;
  cancelAgentJob(jobId: string): Promise<AgentJob>;
  selectAgentProject(): Promise<string | null>;
  openAgentResult(filePath: string): Promise<{ ok: boolean }>;
  openAgentTerminal(request: { provider: AgentProvider; projectPath?: string; conversation?: string; confirmed: true }): Promise<{ ok: boolean; projectPath: string; requestPath?: string }>;
  onAgentJobUpdated(callback: (job: AgentJob) => void): () => void;
  saveSecrets(patch: Record<string, string>): Promise<SecretStatus>;
  listFishVoices(apiKey?: string): Promise<{
    needsKey?: boolean;
    items: FishVoiceModel[];
  }>;
  makeFishVoicePrivate(): Promise<FishVoiceModel>;
  importGoogleCredentials(): Promise<{
    filename: string;
    status: SecretStatus;
    google: GoogleAccountStatus;
  } | null>;
  importLatestGoogleCredentials(): Promise<{
    filename: string;
    status: SecretStatus;
    google: GoogleAccountStatus;
  }>;
  getGoogleStatus(): Promise<GoogleAccountStatus>;
  connectGoogle(): Promise<{ needsConfig?: boolean; status?: GoogleAccountStatus }>;
  beginGoogleConnect(): Promise<{ needsConfig?: boolean; authorizationUrl?: string }>;
  completeGoogleConnect(): Promise<{ status: GoogleAccountStatus }>;
  syncGoogleToday(date?: string): Promise<GoogleTodaySchedule>;
  syncGoogleWeek(date?: string): Promise<GoogleWeekSchedule>;
  listGoogleTasks(): Promise<GoogleTaskCollection>;
  createGoogleTask(request: GoogleTaskCreateRequest): Promise<GoogleTaskItem>;
  completeGoogleTask(request: { taskListId: string; taskId: string }): Promise<{ ok: boolean }>;
  searchGoogleCalendar(request: GoogleCalendarSearchRequest): Promise<GoogleCalendarSearchResult>;
  disconnectGoogle(): Promise<GoogleAccountStatus>;
  selectProject(): Promise<string | null>;
  scanProject(projectPath: string): Promise<ProjectInfo>;
  importRevenueCsv(): Promise<{ filename: string; content: string } | null>;
  searchYouTubeLive(query: string): Promise<{
    needsKey?: boolean;
    items: YouTubeLiveResult[];
  }>;
  researchWeb(query: string): Promise<ResearchResult>;
  getLatestNews(topic?: string): Promise<ResearchResult>;
  getWeather(location: string): Promise<WeatherResult>;
  askAI(request: {
    prompt: string;
    context: unknown;
    history?: ConversationMessage[];
  }): Promise<{ needsKey?: boolean; localUnavailable?: boolean; error?: string; text?: string; provider?: "local" | "openai"; knowledgeSources?: ObsidianKnowledgeSearchResult["sources"] }>;
  transcribeAudio(request: {
    bytes: number[];
    mimeType: string;
  }): Promise<{ needsKey?: boolean; localUnavailable?: boolean; text?: string; provider?: "local" | "openai" }>;
  speak(text: string): Promise<{
    fallback?: boolean;
    audio?: string;
    mimeType?: string;
    provider?: "system" | "fish";
    reason?: "disabled" | "missingConfig";
    model?: string;
  }>;
  showNotification(request: { title: string; body: string; silent?: boolean }): Promise<{ ok: boolean }>;
  openExternal(url: string): Promise<{ ok: boolean }>;
  openInChrome(url: string): Promise<{ ok: boolean; browser: "chrome" | "default" }>;
  onAssistantFocus(callback: () => void): () => void;
}

interface SpeechRecognitionEventLike extends Event {
  results: {
    [index: number]: {
      [index: number]: { transcript: string };
    };
  };
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: Event & { error?: string }) => void) | null;
  onend: (() => void) | null;
  start(): void;
  stop(): void;
}

interface SpeechRecognitionConstructor {
  new (): SpeechRecognitionLike;
}

declare global {
  interface Window {
    hayato: HayatoBridge;
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  }
}

export {};
