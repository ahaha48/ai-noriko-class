/** Conservative routing: reference text and discussion must never launch an agent. */
export function isDiscussionRequest(text: string) {
  return /相談|壁打ちしたい|アドバイス|文案|下書き|依頼文|設計だけ|設計まで|案だけ|質問です/.test(text)
    || /(?:しないで|しない|せず|行わず|行わない|起動しない|実行しない|まだ行|まだ実|確認するまで|確認させて|勝手に)/.test(text);
}

export function isKnowledgeRecordRequest(text: string) {
  return !isDiscussionRequest(text.replace(/今の相談|この相談|相談内容/g, "会話"))
    && /(?:Obsidian|オブシディアン|ナレッジ|今日の記録)/i.test(text)
    && /(?:記録して|記録しといて|保存して|保存しといて|追加して)/.test(text);
}

export function directAgentRequest(text: string) {
  if (isDiscussionRequest(text)) return null;
  const codex = /Codex|コーデックス/i.test(text);
  const claude = /Claude\s*Code|クロードコード|クラウドコード/i.test(text);
  if (codex === claude) return null; // Both names requires a human choice, not ordering bias.
  const provider = claude ? "claude" as const : "codex" as const;
  if (/(?:開いて|起動して|呼んで|読んできて)[。！!\s]*$/.test(text)) return { provider, kind: "terminal" as const };
  if (/(?:作って|作り込んで|実装して|修正して|直して|落とし込んで|制作して|壁打ちして|考えて|まとめて)(?:ください|ほしい)?[。！!\s]*$/.test(text)) {
    return { provider, kind: "job" as const };
  }
  return null;
}
