import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export function supportedNode(version) {
  const match = /^(\d+)\.(\d+)\.(\d+)$/.exec(version);
  if (!match) return false;
  const [, major, minor] = match.map(Number);
  return major > 22 || (major === 22 && minor >= 12);
}

export function doctorInvocation(executable = process.execPath) {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
  // Invoke JavaScript through Node itself: .cmd shims do not support direct
  // spawn on Windows. Paths remain separate arguments, including spaces.
  return { command: executable, args: [resolve(root, "scripts", "doctor.mjs")], cwd: root };
}
