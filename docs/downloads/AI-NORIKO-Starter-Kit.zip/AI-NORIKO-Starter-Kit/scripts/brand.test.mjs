import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const source=readFileSync(new URL('../electron/main.cjs',import.meta.url),'utf8');
const fn=source.match(/function resolveStarterUserData\([\s\S]*?\n\}/)?.[0];
assert.ok(fn);
const resolve=vm.runInNewContext(`(${fn})`,{path});
for(const base of ['/example/Application Support', 'C:\\Example\\AppData\\Roaming']) {
  assert.equal(resolve(base,()=>false),path.join(base,'AI NORIKO Starter'));
  const legacy=path.join(base,'AI HAYATO Starter','hayato-data.json');
  assert.equal(resolve(base,p=>p===legacy),path.dirname(legacy));
  const older=path.join(base,'ai-hayato-starter-kit','hayato-secrets.bin');
  assert.equal(resolve(base,p=>p===older),path.dirname(older));
  const current=path.join(base,'AI NORIKO Starter','hayato-data.json');
  assert.equal(resolve(base,p=>p===current||p===legacy),path.dirname(current));
}
console.log('Brand rename: new and existing starter storage selection passed; no real user data accessed.');
