import { spawn } from "node:child_process";
import electronPath from "electron";
import { createServer } from "vite";

const debugPort = process.env.NORIKO_DEBUG_PORT || "9222";
const debug = process.argv.includes("--debug") || Boolean(process.env.NORIKO_DEBUG_PORT);
const server = await createServer();
await server.listen();
const address = server.httpServer?.address();
const port = typeof address === "object" && address ? address.port : 5173;
const devServerUrl = `http://127.0.0.1:${port}`;

const electronArgs = debug
  ? [`--remote-debugging-port=${debugPort}`, "--remote-allow-origins=http://127.0.0.1", "."]
  : ["."];

const electron = spawn(electronPath, electronArgs, {
  stdio: "inherit",
  env: { ...process.env, VITE_DEV_SERVER_URL: devServerUrl },
});

const shutdown = async (code = 0) => {
  await server.close();
  process.exit(code);
};

electron.on("exit", (code) => void shutdown(code ?? 0));
process.on("SIGINT", () => electron.kill("SIGINT"));
process.on("SIGTERM", () => electron.kill("SIGTERM"));
