import { existsSync, readFileSync, readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const indexPath = join(root, "dist", "index.html");
if (!existsSync(indexPath)) throw new Error("distがありません。先に npm run build を実行してください。");
const html = readFileSync(indexPath, "utf8");
if (!html.includes("<div id=\"root\"></div>")) throw new Error("ビルド結果にReactのルートがありません。");
const assets = readdirSync(join(root, "dist", "assets"));
if (!assets.some((name) => name.endsWith(".js")) || !assets.some((name) => name.endsWith(".css"))) {
  throw new Error("JavaScriptまたはCSSの成果物がありません。");
}
for (const file of ["START-MAC.command", "START-WINDOWS.bat", "AGENTS.md", "START_HERE.md"]) {
  if (!existsSync(join(root, file))) throw new Error(`${file}がありません。`);
}
const mainSource = readFileSync(join(root, "electron", "main.cjs"), "utf8");
for (const marker of ['process.platform === "win32"', '"powershell.exe"', '"where.exe"', 'process.env.APPDATA']) {
  if (!mainSource.includes(marker)) throw new Error(`Windows対応コードが不足しています: ${marker}`);
}
// Detect embedded personal home paths without shipping a real person's name.
if (/["'](?:\/(?:Users|home)\/[^/\s"']+|[a-z]:\\+Users\\+)/i.test(mainSource)) {
  throw new Error("個人のホームフォルダへの固定パスが残っています。");
}
console.log(JSON.stringify({
  ok: true,
  scope: "static-build-and-source-checks-only",
  buildAssets: assets.length,
  launcherFilesPresent: ["Mac", "Windows"],
  windowsCodeMarkersPresent: true,
  embeddedHomePathInMainSource: false,
  note: "実画面、Windows実機、外部連携、秘密情報の全体検査は別途必要です。",
}, null, 2));
