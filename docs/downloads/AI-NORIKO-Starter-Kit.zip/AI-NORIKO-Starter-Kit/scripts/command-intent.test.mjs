import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../src/command-intent.ts', import.meta.url), 'utf8');
// This helper has only string parameter annotations and literal assertions.
// Remove those annotations without depending on a particular TS compiler API.
const compiled = source.replace(/: string\b/g, '').replace(/\s+as const\b/g, '');
const { directAgentRequest, isDiscussionRequest, isKnowledgeRecordRequest } = await import(`data:text/javascript;base64,${Buffer.from(compiled).toString('base64')}`);
const prompts = JSON.parse(fs.readFileSync(new URL('../course/prompts.json', import.meta.url), 'utf8')).prompts;

for (const id of ['P06', 'P11', 'P15']) {
  test(`${id} exact teaching prompt remains discussion and never launches an agent`, () => {
    const prompt = prompts.find((item) => item.id === id).text;
    assert.equal(isDiscussionRequest(prompt), true);
    assert.equal(directAgentRequest(prompt), null);
    assert.equal(isKnowledgeRecordRequest(prompt), false);
  });
}
test('negated instructions, draft-only requests, and ambiguous providers are never agent commands', () => {
  for (const text of ['Codexを起動しないで', 'Claude Codeで実装しないでください', 'Codexで作ってほしいけど今回は文案だけ', 'CodexまたはClaude Codeで作って', '予定を変更せず相談したい']) {
    assert.equal(directAgentRequest(text), null, text);
  }
});
test('direct agent requests become confirmation candidates, never execution here', () => {
  assert.deepEqual(directAgentRequest('Codexを開いて'), { provider: 'codex', kind: 'terminal' });
  assert.deepEqual(directAgentRequest('Claude Codeで企画を作って'), { provider: 'claude', kind: 'job' });
});
test('knowledge record request is explicit and respects negation', () => {
  assert.equal(isKnowledgeRecordRequest('今の相談をObsidianに記録して'), true);
  assert.equal(isKnowledgeRecordRequest('これを今日の記録としてObsidianに保存して'), true);
  assert.equal(isKnowledgeRecordRequest('Obsidianに記録しないで'), false);
  assert.equal(isKnowledgeRecordRequest('保存せず、Obsidianに保存してもいいか相談です'), false);
});
