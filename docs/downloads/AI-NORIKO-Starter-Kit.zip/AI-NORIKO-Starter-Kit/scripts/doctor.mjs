import { spawnSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { supportedNode } from "./runtime-support.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const platformLabel = process.platform === "darwin" ? "Mac" : process.platform === "win32" ? "Windows" : process.platform;
const requiredFiles = ["AGENTS.md", "START_HERE.md", "electron/main.cjs", "src/App.tsx", "package.json"];
const packageInfo = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));

function findCommand(command) {
  const locator = process.platform === "win32" ? "where.exe" : "which";
  const result = spawnSync(locator, [command], { encoding: "utf8", windowsHide: true });
  return result.status === 0 ? result.stdout.split(/\r?\n/).map((line) => line.trim()).find(Boolean) : "";
}

const nodeSupported = supportedNode(process.versions.node);
const missing = requiredFiles.filter((file) => !existsSync(join(root, file)));
const checks = [
  ["OS", `${platformLabel} (${process.arch})`, true],
  ["Node.js", `${process.versions.node}（22.12.0以上必須／講義の検証環境は24.14.0）`, nodeSupported],
  ["npm", findCommand("npm") || "未検出", Boolean(findCommand("npm"))],
  ["必須ファイル", missing.length ? `不足: ${missing.join(", ")}` : "揃っています", missing.length === 0],
];

console.log(`AI NORIKO Starter Kit ${packageInfo.version} 診断\n`);
for (const [label, value, ok] of checks) console.log(`${ok ? "✓" : "✗"} ${label}: ${value}`);
console.log("\n任意機能");
for (const [label, command] of [["Codex CLI", "codex"], ["Claude Code CLI", "claude"], ["Ollama", "ollama"], ["FFmpeg", "ffmpeg"], ["whisper.cpp", "whisper-cli"]]) {
  console.log(`${findCommand(command) ? "✓" : "–"} ${label}: ${findCommand(command) || "未設定（アプリ起動には不要）"}`);
}

if (checks.some(([, , ok]) => !ok)) {
  console.error("\n必須項目に問題があります。START_HERE.mdを確認してください。");
  process.exit(1);
}
console.log("\n必須項目は準備できています。外部連携はアプリ起動後に必要なものだけ設定できます。");
