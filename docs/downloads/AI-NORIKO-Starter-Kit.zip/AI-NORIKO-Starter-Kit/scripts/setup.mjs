import { spawnSync } from "node:child_process";
import { doctorInvocation } from "./runtime-support.mjs";

const doctor = doctorInvocation();
const result = spawnSync(doctor.command, doctor.args, { cwd: doctor.cwd, stdio: "inherit" });
if (result.error) {
  console.error(`診断を開始できませんでした: ${result.error.message}`);
  process.exit(1);
}
if (result.status !== 0) process.exit(result.status ?? 1);

console.log("\nセットアップ診断が完了しました。次に npm run start でAI NORIKOを起動できます。");
console.log("初回画面で呼び名と秘書名を設定してください。Googleや外部APIは後から追加できます。");
