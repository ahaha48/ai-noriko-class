import test from "node:test";
import assert from "node:assert/strict";
import { existsSync } from "node:fs";
import { doctorInvocation, supportedNode } from "./runtime-support.mjs";

test("Node diagnostic agrees with locked dependency minimum", () => {
  for (const version of ["18.20.0", "20.19.0", "22.0.0", "22.11.9", "not-a-version"]) {
    assert.equal(supportedNode(version), false, version);
  }
  for (const version of ["22.12.0", "22.13.0", "24.14.0"]) {
    assert.equal(supportedNode(version), true, version);
  }
});

test("setup runs the doctor with Node, with no shell or npm.cmd", () => {
  const windows = doctorInvocation("C:\\Program Files\\nodejs\\node.exe");
  assert.equal(windows.command, "C:\\Program Files\\nodejs\\node.exe");
  assert.equal(windows.args.length, 1);
  assert.ok(windows.args[0].endsWith("doctor.mjs"));
  assert.ok(existsSync(windows.args[0]));
  assert.equal(windows.shell, undefined);
  assert.equal(doctorInvocation().command, process.execPath);
});
