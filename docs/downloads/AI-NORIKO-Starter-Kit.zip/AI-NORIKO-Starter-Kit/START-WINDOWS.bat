@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js LTS is required. Install it from https://nodejs.org/
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo npm was not found. Please reinstall Node.js.
  pause
  exit /b 1
)

call npm run setup
if errorlevel 1 goto :error

node -e "require.resolve('vite'); require.resolve('electron')" >nul 2>nul
if errorlevel 1 (
  call npm ci
  if errorlevel 1 goto :error
)

call npm run start
if errorlevel 1 goto :error
exit /b 0

:error
echo.
echo Startup failed. Send the error shown above to Codex.
pause
exit /b 1
